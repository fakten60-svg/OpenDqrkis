package xyz.dqrkis.module.setting;

import net.minecraft.class_1792;

public final class ItemSetting extends Setting<ItemSetting> {
    private class_1792 value;
    private final class_1792 defaultValue;

    public ItemSetting(CharSequence name, class_1792 defaultValue) {
        super(name);
        this.value = defaultValue;
        this.defaultValue = defaultValue;
    }

    public class_1792 getItem() {
        return value;
    }

    public void setItem(class_1792 value) {
        this.value = value;
    }

    public class_1792 getDefaultValue() {
        return defaultValue;
    }
}