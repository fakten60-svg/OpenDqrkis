package xyz.dqrkis.module.modules.client;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.ButtonListener;
import xyz.dqrkis.event.events.HudListener;
import xyz.dqrkis.managers.FriendManager;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;
import xyz.dqrkis.utils.WorldUtils;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import net.minecraft.class_3966;

public final class Friends extends Module implements ButtonListener, AttackListener, HudListener {
    private final KeybindSetting addFriendKey = new KeybindSetting("Friend Key", GLFW.GLFW_MOUSE_BUTTON_MIDDLE, false)
            .setDescription("Key to add/remove friends");
    public final BooleanSetting antiAttack = new BooleanSetting("Anti-Attack", false)
            .setDescription("Doesn't let you hit friends");
    public final BooleanSetting disableAimAssist = new BooleanSetting("Anti-Aim", false)
            .setDescription("Disables aim assist for friends");
    public final BooleanSetting friendStatus = new BooleanSetting("Friend Status", false)
            .setDescription("Tells you if you're aiming at a friend or not");

    private FriendManager manager;

    public Friends() {
        super("Friends", "This module makes it so you can't do certain stuff if you have a player friended!", -1, Category.CLIENT);
        addSettings(addFriendKey, antiAttack, disableAimAssist, friendStatus);
        setKey(-1);
    }

    @Override
    public void onEnable() {
        manager = Dqrkis.INSTANCE.getFriendManager();

        eventManager.add(ButtonListener.class, this);
        eventManager.add(AttackListener.class, this);
        eventManager.add(HudListener.class, this);

        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(ButtonListener.class, this);
        eventManager.remove(AttackListener.class, this);
        eventManager.remove(HudListener.class, this);

        super.onDisable();
    }

    @Override
    public void onButtonPress(ButtonEvent event) {
        if(mc.field_1724 == null)
            return;

        if(mc.field_1755 != null)
            return;

        if(mc.field_1765 instanceof class_3966 hitResult) {
            class_1297 entity = hitResult.method_17782();

            if(entity instanceof class_1657 player) {
                if (event.button == addFriendKey.getKey() && event.action == GLFW.GLFW_PRESS) {
                    if(!manager.isFriend(player))
                        manager.addFriend(player);
                    else manager.removeFriend(player);
                }
            }
        }
    }

    @Override
    public void onAttack(AttackEvent event) {
        if(!antiAttack.getValue())
            return;

        if(manager.isAimingOverFriend())
            event.cancel();
    }

    @Override
    public void onRenderHud(HudEvent event) {
        if(!friendStatus.getValue())
            return;

        class_332 context = event.context;
        RenderUtils.unscaledProjection(context);
        if(WorldUtils.getHitResult(100) instanceof class_3966 hitResult) {
            class_1297 entity = hitResult.method_17782();

            if(entity instanceof class_1657 player) {
                if(manager.isFriend(player)) {
                    TextRenderer.drawCenteredString("Player is friend", context, (mc.method_22683().method_4480() / 2), (mc.method_22683().method_4507() / 2) + 25, Color.GREEN.getRGB());
                }
            }
        }
        RenderUtils.scaledProjection(context);
    }
}
