package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.CameraUpdateListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.KeyBindingAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import org.lwjgl.glfw.GLFW;


public final class Freecam extends Module implements TickListener, CameraUpdateListener {
	private final NumberSetting speed = new NumberSetting("Speed", 1, 10, 1, 1);
	public class_243 oldPos;
	public class_243 pos;

	public Freecam() {
		super("Freecam",
				"Lets you move freely around the world without actually moving",
				-1,
				Category.MISC);
		addSettings(speed);

		oldPos = class_243.field_1353;
		pos = class_243.field_1353;
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(CameraUpdateListener.class, this);
		if (mc.field_1687 != null) {
			this.oldPos = this.pos = mc.field_1724.method_33571();
		}

		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(CameraUpdateListener.class, this);

		if (mc.field_1687 != null) {
			mc.field_1724.method_18799(class_243.field_1353);
			mc.field_1769.method_3279();
		}
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null)
			return;

		mc.field_1690.field_1904.method_23481(false);
		mc.field_1690.field_1886.method_23481(false);
		mc.field_1690.field_1894.method_23481(false);
		mc.field_1690.field_1881.method_23481(false);
		mc.field_1690.field_1913.method_23481(false);
		mc.field_1690.field_1849.method_23481(false);
		mc.field_1690.field_1903.method_23481(false);
		mc.field_1690.field_1832.method_23481(false);

		float f = (float) Math.PI / 180;
		float f2 = (float) Math.PI;
		class_243 vec3d = new class_243(-class_3532.method_15374(-mc.field_1724.method_36454() * f - f2), 0.0, -class_3532.method_15362(-mc.field_1724.method_36454() * f - f2));
		class_243 vec3d2 = new class_243(0.0, 1.0, 0.0);
		class_243 vec3d3 = vec3d2.method_1036(vec3d);
		class_243 vec3d4 = vec3d.method_1036(vec3d2);
		class_243 vec3d5 = class_243.field_1353;
		class_304 keyBinding = mc.field_1690.field_1894;

		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding).getBoundKey().method_1444()) == GLFW.GLFW_PRESS) {
			vec3d5 = vec3d5.method_1019(vec3d);
		}

		class_304 keyBinding2 = mc.field_1690.field_1881;
		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding2).getBoundKey().method_1444()) == GLFW.GLFW_PRESS) {
			vec3d5 = vec3d5.method_1020(vec3d);
		}

		class_304 keyBinding3 = mc.field_1690.field_1913;
		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding3).getBoundKey().method_1444()) == GLFW.GLFW_PRESS) {
			vec3d5 = vec3d5.method_1019(vec3d3);
		}

		class_304 keyBinding4 = mc.field_1690.field_1849;
		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding4).getBoundKey().method_1444()) == GLFW.GLFW_PRESS) {
			vec3d5 = vec3d5.method_1019(vec3d4);
		}

		class_304 keyBinding5 = mc.field_1690.field_1903;
		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding5).getBoundKey().method_1444()) == GLFW.GLFW_PRESS) {
			vec3d5 = vec3d5.method_1031(0.0, speed.getValue(), 0.0);
		}

		class_304 keyBinding6 = mc.field_1690.field_1832;
		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding6).getBoundKey().method_1444()) == GLFW.GLFW_PRESS) {
			vec3d5 = vec3d5.method_1031(0.0, -speed.getValue(), 0.0);
		}

		class_304 keyBinding7 = mc.field_1690.field_1867;
		vec3d5 = vec3d5.method_1029().method_1021(speed.getValue() * (GLFW.glfwGetKey(mc.method_22683().method_4490(), ((KeyBindingAccessor) keyBinding7).getBoundKey().method_1444()) == GLFW.GLFW_PRESS ? 2 : 1));

		oldPos = pos;
		pos = pos.method_1019(vec3d5);
	}

	@Override
	public void onCameraUpdate(CameraUpdateEvent event) {
		float tickDelta = mc.method_61966().method_60637(true);

		if (mc.field_1755 != null)
			return;

		event.setX(class_3532.method_16436(tickDelta, oldPos.field_1352, pos.field_1352));
		event.setY(class_3532.method_16436(tickDelta, oldPos.field_1351, pos.field_1351));
		event.setZ(class_3532.method_16436(tickDelta, oldPos.field_1350, pos.field_1350));
	}
}
