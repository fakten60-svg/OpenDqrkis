package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.ChatUtils;

public final class AutoShulker extends Module implements TickListener {
    public enum ItemMode { SHULKERS, SHELLS }
    public enum Action { BUY_AND_SELL, BUY_ONLY, SELL_ONLY, ORDER_ONLY }

    private final ModeSetting<ItemMode> itemMode = new ModeSetting<>("Item Mode", ItemMode.SHULKERS, ItemMode.class);
    private final ModeSetting<Action> action = new ModeSetting<>("Action", Action.BUY_AND_SELL, Action.class);
    private final StringSetting minPrice = new StringSetting("Min Price", "850");
    private final StringSetting targetPlayer = new StringSetting("Target Player", "");
    private final BooleanSetting autoDrop = new BooleanSetting("Auto Drop", false);

    private int ticks;
    private State state = State.IDLE;

    private enum State { IDLE, OPEN_SHOP, SHOP_BUY, SHOP_CONFIRM, OPEN_ORDERS, ORDERS_SELECT, CYCLE_PAUSE }

    public AutoShulker() {
        super("Auto Shulker", "Automatically buys/sells shulkers and shulker shells with player targeting", -1, Category.MISC);
        addSettings(itemMode, action, minPrice, targetPlayer, autoDrop);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        ticks = 0;
        state = State.IDLE;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        if (ticks > 0) { ticks--; return; }

        class_1703 handler = mc.field_1724.field_7512;
        if (!(handler instanceof class_1707 container)) {
            if (state == State.IDLE) {
                if (action.getMode() == Action.SELL_ONLY || action.getMode() == Action.BUY_AND_SELL) {
                    // Alternate between shop and orders; simplified: open shop
                    mc.field_1724.field_3944.method_45730("shop");
                    state = State.OPEN_SHOP;
                    ticks = 20;
                }
            }
            return;
        }

        int rows = container.method_17388();
        switch (state) {
            case OPEN_SHOP -> {
                // Shop GUI: look for shulker related slots (simplified placeholder)
                // In original: clicks shop category then item slot then confirm
                // Simplified: try to click any shulker/lime pane that matches price filter
                boolean bought = tryBuyFromShop(container);
                if (bought) { state = State.SHOP_CONFIRM; ticks = 10; }
                else { mc.field_1724.method_7346(); state = State.CYCLE_PAUSE; ticks = 40; }
            }
            case SHOP_CONFIRM -> {
                // Confirm purchase (slot 15/confirm lime pane)
                if (container.method_7611(15).method_7677().method_31574(class_1802.field_8581)) {
                    mc.field_1761.method_2906(container.field_7763, 15, 0, class_1713.field_7790, mc.field_1724);
                }
                mc.field_1724.method_7346();
                state = State.CYCLE_PAUSE;
                ticks = 20;
            }
            case CYCLE_PAUSE -> {
                state = State.IDLE;
                ticks = 60;
            }
            default -> { state = State.IDLE; ticks = 10; }
        }
    }

    private boolean tryBuyFromShop(class_1703 handler) {
        for (int i = 0; i < handler.field_7761.size(); i++) {
            var stack = handler.method_7611(i).method_7677();
            boolean isTarget = (itemMode.getMode() == ItemMode.SHULKERS && stack.method_31574(class_1802.field_8545))
                    || (itemMode.getMode() == ItemMode.SHELLS && stack.method_31574(class_1802.field_8815));
            if (isTarget) {
                // Price filter via lore would go here; simplified to always attempt
                mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, mc.field_1724);
                return true;
            }
        }
        return false;
    }
}