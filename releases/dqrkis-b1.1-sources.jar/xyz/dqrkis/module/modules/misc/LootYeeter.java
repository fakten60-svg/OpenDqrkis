package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.PlayerInventoryAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2371;
import net.minecraft.class_490;

public final class LootYeeter extends Module implements TickListener {
	private final NumberSetting minTotems = new NumberSetting("Min Totems", 0, 36, 6, 1)
			.setDescription("Keeps at least this many totems");
	private final NumberSetting minPearls = new NumberSetting("Min Pearls", 0, 576, 64, 1)
			.setDescription("Keeps at least this many pearls");
	private final BooleanSetting totemsFirst = new BooleanSetting("Totems First", false)
			.setDescription("Checks totem overflow before pearl overflow");
	private final NumberSetting throwDelay = new NumberSetting("Throw Delay", 0, 10, 0, 1)
			.setDescription("Ticks between throws");
	private final KeybindSetting yeetKey = new KeybindSetting("Throw Key", GLFW.GLFW_KEY_X, false)
			.setDescription("Hold this key to throw junk items");
	private final BooleanSetting randomSlot = new BooleanSetting("Random Slot", true)
			.setDescription("Picks a random matching slot instead of the first one");

	private int throwIn;

	public LootYeeter() {
		super("Loot Yeeter",
				"Throws away junk items from your inventory",
				-1,
				Category.MISC);
		addSettings(minTotems, minPearls, totemsFirst, throwDelay, yeetKey, randomSlot);
	}

	@Override
	public void onEnable() {
		throwIn = 0;
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null)
			return;

		if (!(mc.field_1755 instanceof class_490 screen))
			return;

		int key = yeetKey.getKey();
		if (key <= 0 || GLFW.glfwGetKey(mc.method_22683().method_4490(), key) != GLFW.GLFW_PRESS)
			return;

		if (throwIn > 0) {
			throwIn--;
			return;
		}

		int slot = findSlot();
		if (slot == -1)
			return;

		mc.field_1761.method_2906(screen.method_17577().field_7763, slot, 1, class_1713.field_7795, mc.field_1724);
		throwIn = throwDelay.getValueInt();
	}

	private int findSlot() {
		int pearls = pearlSlot();
		int totems = totemSlot();

		if (totemsFirst.getValue())
			return totems != -1 ? totems : pearls;
		return pearls != -1 ? pearls : totems;
	}

	private int pearlSlot() {
		int total = countItem(class_1802.field_8634);
		if (total <= minPearls.getValueInt())
			return -1;

		ArrayList<Integer> slots = collectSlots(class_1802.field_8634);
		if (slots.isEmpty())
			return -1;

		if (randomSlot.getValue()) {
			int slot = slots.get(ThreadLocalRandom.current().nextInt(slots.size()));
			int count = getMain().get(slot).method_7947();
			return total - count >= minPearls.getValueInt() ? slot : -1;
		}

		int best = -1;
		int smallest = Integer.MAX_VALUE;
		for (int slot : slots) {
			int count = getMain().get(slot).method_7947();
			if (count < smallest) {
				smallest = count;
				best = slot;
			}
		}
		return total - smallest >= minPearls.getValueInt() ? best : -1;
	}

	private int totemSlot() {
		if (countItem(class_1802.field_8288) <= minTotems.getValueInt())
			return -1;

		ArrayList<Integer> slots = collectSlots(class_1802.field_8288);
		if (slots.isEmpty())
			return -1;

		return randomSlot.getValue()
				? slots.get(ThreadLocalRandom.current().nextInt(slots.size()))
				: slots.getFirst();
	}

	private ArrayList<Integer> collectSlots(net.minecraft.class_1792 item) {
		ArrayList<Integer> slots = new ArrayList<>();
		for (int i = 9; i < 36; i++) {
			class_1799 stack = getMain().get(i);
			if (stack.method_31574(item))
				slots.add(i);
		}
		return slots;
	}

	private int countItem(net.minecraft.class_1792 item) {
		int count = 0;
		for (class_1799 stack : getMain()) {
			if (stack.method_31574(item))
				count += stack.method_7947();
		}
		return count;
	}

	private class_2371<class_1799> getMain() {
		return ((PlayerInventoryAccessor) (Object) mc.field_1724.method_31548()).getMain();
	}
}
