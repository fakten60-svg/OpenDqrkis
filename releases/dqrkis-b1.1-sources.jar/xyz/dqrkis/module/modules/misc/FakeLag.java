package xyz.dqrkis.module.modules.misc;

import com.google.common.collect.Queues;
import xyz.dqrkis.event.events.PacketReceiveListener;
import xyz.dqrkis.event.events.PacketSendListener;
import xyz.dqrkis.event.events.PlayerTickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.TimerUtils;
import java.util.Queue;
import net.minecraft.class_1304;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2813;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_2885;

public final class FakeLag extends Module implements PlayerTickListener, PacketReceiveListener, PacketSendListener {
	public final Queue<class_2596<?>> packetQueue = Queues.newConcurrentLinkedQueue();
	public boolean bool;
	public class_243 pos = class_243.field_1353;
	public TimerUtils timerUtil = new TimerUtils();
	private final MinMaxSetting lagDelay = new MinMaxSetting("Lag Delay", 0, 1000, 1, 100, 200);
	private final BooleanSetting cancelOnElytra = new BooleanSetting("Cancel on Elytra", false)
			.setDescription("Cancel the lagging effect when you're wearing an elytra");

	private int delay;
	public FakeLag() {
		super("Fake Lag",
				"Makes it impossible to aim at you by creating a lagging effect",
				-1,
				Category.MISC);
		addSettings(lagDelay, cancelOnElytra);
	}

	@Override
	public void onEnable() {
		eventManager.add(PlayerTickListener.class, this);
		eventManager.add(PacketSendListener.class, this);
		eventManager.add(PacketReceiveListener.class, this);

		timerUtil.reset();
		if (mc.field_1724 != null)
			pos = mc.field_1724.method_73189();

		delay = lagDelay.getRandomValueInt();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(PlayerTickListener.class, this);
		eventManager.remove(PacketSendListener.class, this);
		eventManager.remove(PacketReceiveListener.class, this);
		reset();
		super.onDisable();
	}

	@Override
	public void onPacketReceive(PacketReceiveEvent event) {
		if (mc.field_1687 == null)
			return;

		if(mc.field_1724.method_29504())
			return;

		if (event.packet instanceof class_2664) {
			reset();
		}
	}

	@Override
	public void onPacketSend(PacketSendEvent event) {
		if (mc.field_1687 == null || mc.field_1724.method_6115() || mc.field_1724.method_29504())
			return;

		if (event.packet instanceof class_2824 || event.packet instanceof class_2879 || event.packet instanceof class_2885 || event.packet instanceof class_2813) {
			reset();
			return;
		}

		if (cancelOnElytra.getValue() && mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833) {
			reset();
			return;
		}

		if (!bool) {
			packetQueue.add(event.packet);
			event.cancel();
		}
	}

	@Override
	public void onPlayerTick() {
		if (timerUtil.delay(delay)) {
			if (mc.field_1724 != null && !mc.field_1724.method_6115()) {
				reset();
				delay = lagDelay.getRandomValueInt();
			}
		}
	}

	private void reset() {
		if (mc.field_1724 == null || mc.field_1687 == null)
			return;

		bool = true;

		synchronized (packetQueue) {
			while (!packetQueue.isEmpty()) {
				mc.method_1562().method_48296().method_52906(packetQueue.poll(), null, false);
			}
		}

		bool = false;
		timerUtil.reset();
		pos = mc.field_1724.method_73189();
	}
}
