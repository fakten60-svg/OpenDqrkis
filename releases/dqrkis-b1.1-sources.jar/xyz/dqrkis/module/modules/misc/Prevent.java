package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_3965;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.BlockBreakingListener;
import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.utils.BlockUtils;
import xyz.dqrkis.utils.WorldUtils;


public final class Prevent extends Module implements ItemUseListener, AttackListener, BlockBreakingListener {
	private final BooleanSetting doubleGlowstone = new BooleanSetting("Double Glowstone", false)
			.setDescription("Makes it so you can't charge the anchor again if it's already charged");
	private final BooleanSetting glowstoneMisplace = new BooleanSetting("Glowstone Misplace", false)
			.setDescription("Makes it so you can only right-click with glowstone only when aiming at an anchor");
	private final BooleanSetting anchorOnAnchor = new BooleanSetting("Anchor on Anchor", false)
			.setDescription("Makes it so you can't place an anchor on/next to another anchor unless charged");
	private final BooleanSetting obiPunch = new BooleanSetting("Obi Punch", false)
			.setDescription("Makes it so you can crystal faster by not letting you left click/start breaking the obsidian");
	private final BooleanSetting echestClick = new BooleanSetting("E-chest click", false)
			.setDescription("Makes it so you can't click on e-chests with PvP items");

	public Prevent() {
		super("Prevent",
				"Prevents you from certain actions",
				-1,
				Category.MISC);
		addSettings(doubleGlowstone, glowstoneMisplace, anchorOnAnchor, obiPunch, echestClick);
	}

	@Override
	public void onEnable() {
		eventManager.add(BlockBreakingListener.class, this);
		eventManager.add(AttackListener.class, this);
		eventManager.add(ItemUseListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(BlockBreakingListener.class, this);
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		super.onDisable();
	}

	@Override
	public void onAttack(AttackEvent event) {
		if (mc.field_1765 instanceof class_3965 hit) {
			if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_10540) && obiPunch.getValue() && mc.field_1724.method_24518(class_1802.field_8301))
				event.cancel();
		}
	}

	@Override
	public void onBlockBreaking(BlockBreakingEvent event) {
		if (mc.field_1765 instanceof class_3965 hit) {
			if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_10540) && obiPunch.getValue() && mc.field_1724.method_24518(class_1802.field_8301))
				event.cancel();
		}
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		if (mc.field_1765 instanceof class_3965 hit) {
			if (BlockUtils.isAnchorCharged(hit.method_17777()) && doubleGlowstone.getValue() && mc.field_1724.method_24518(class_1802.field_8801))
				event.cancel();

			if (!BlockUtils.isBlock(hit.method_17777(), class_2246.field_23152) && glowstoneMisplace.getValue() && mc.field_1724.method_24518(class_1802.field_8801))
				event.cancel();

			if (BlockUtils.isAnchorNotCharged(hit.method_17777()) && anchorOnAnchor.getValue() && mc.field_1724.method_24518(class_1802.field_23141))
				event.cancel();

			if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_10443) && echestClick.getValue() &&
					(WorldUtils.isSword(mc.field_1724.method_6047())
							|| mc.field_1724.method_6047().method_7909() == class_1802.field_8301
							|| mc.field_1724.method_6047().method_7909() == class_1802.field_8281
							|| mc.field_1724.method_6047().method_7909() == class_1802.field_23141
							|| mc.field_1724.method_6047().method_7909() == class_1802.field_8801))
				event.cancel();
		}
	}
}
