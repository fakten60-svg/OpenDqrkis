package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.ChatUtils;
import xyz.dqrkis.mixin.ClientPlayerInteractionManagerAccessor;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public final class AutoTreeFarmer extends Module implements TickListener {
    private enum TreeState { SEARCHING, PLANTING, BONEMEALING, MINING, WAIT }

    private static final int RADIUS = 16;

    private final BooleanSetting hotbarRefill = new BooleanSetting("Hotbar Refill", true);
    private final NumberSetting saplingCount = new NumberSetting("Sapling Count", 1, 10, 4, 1);
    private final NumberSetting boneMealCount = new NumberSetting("Bone Meal Count", 1, 10, 5, 1);

    private TreeState state = TreeState.SEARCHING;
    private final List<class_2338> saplingSpots = new ArrayList<>();
    private class_2338 farmCenter = null;
    private int spotIndex = 0;
    private int savedSlot = -1;

    public AutoTreeFarmer() {
        super("Auto Tree Farmer",
                "AFK farms 2x2 spruce podzol patches with auto refill",
                -1,
                Category.MISC);
        addSettings(hotbarRefill, saplingCount, boneMealCount);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        resetState();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        releaseKeys();
        if (savedSlot != -1 && mc.field_1724 != null) {
            mc.field_1724.method_31548().method_61496(savedSlot);
            syncSlot();
            savedSlot = -1;
        }
        resetState();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null)
            return;

        if (hotbarRefill.getValue())
            refillHotbar();

        switch (state) {
            case SEARCHING -> searchForPodzol();
            case PLANTING -> plantSaplings();
            case BONEMEALING -> boneMealSaplings();
            case MINING -> mineTrees();
            case WAIT -> waitCycle();
        }
    }

    private void resetState() {
        state = TreeState.SEARCHING;
        farmCenter = null;
        saplingSpots.clear();
        spotIndex = 0;
    }

    private void releaseKeys() {
        if (mc.field_1690 == null) return;
        mc.field_1690.field_1904.method_23481(false);
        mc.field_1690.field_1886.method_23481(false);
        mc.field_1690.field_1832.method_23481(false);
    }

    private void searchForPodzol() {
        class_2338 playerPos = mc.field_1724.method_24515();
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;

        for (int dy = -2; dy <= 0; dy++) {
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    class_2338 candidate = findPodzol2x2(playerPos.method_10069(dx, dy, dz));
                    if (candidate != null) {
                        double dist = playerPos.method_10262(candidate);
                        if (dist < bestDist) {
                            bestDist = dist;
                            best = candidate;
                        }
                    }
                }
            }
        }

        if (best == null)
            return;

        farmCenter = best;
        saplingSpots.clear();
        for (int dx = 0; dx < 2; dx++)
            for (int dz = 0; dz < 2; dz++)
                saplingSpots.add(farmCenter.method_10069(dx, 1, dz));

        saplingSpots.sort(Comparator.comparingDouble(pos -> -mc.field_1724.method_24515().method_10262(pos)));
        spotIndex = 0;
        state = TreeState.PLANTING;
        ChatUtils.info("Found 2x2 podzol at " + farmCenter.method_23854());
    }

    private class_2338 findPodzol2x2(class_2338 at) {
        for (int dx = -1; dx <= 0; dx++) {
            for (int dz = -1; dz <= 0; dz++) {
                class_2338 base = at.method_10069(dx, 0, dz);
                boolean valid = true;
                for (int x = 0; x < 2 && valid; x++)
                    for (int z = 0; z < 2 && valid; z++)
                        if (!mc.field_1687.method_8320(base.method_10069(x, 0, z)).method_27852(class_2246.field_10520))
                            valid = false;
                if (valid) return base;
            }
        }
        return null;
    }

    private void plantSaplings() {
        if (spotIndex >= saplingSpots.size()) {
            spotIndex = 0;
            state = TreeState.BONEMEALING;
            return;
        }

        class_2338 pos = saplingSpots.get(spotIndex);
        if (!mc.field_1687.method_8320(pos).method_26215()) {
            spotIndex++;
            return;
        }

        int saplingSlot = findSlotMatching(class_1802.field_17536);
        if (saplingSlot == -1) {
            ChatUtils.error("No spruce saplings!");
            state = TreeState.SEARCHING;
            return;
        }

        saveSlotOnce();
        mc.field_1724.method_31548().method_61496(saplingSlot);
        syncSlot();

        lookAt(pos);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808,
                new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false));
        mc.field_1724.method_6104(class_1268.field_5808);
        spotIndex++;

        if (spotIndex >= saplingSpots.size()) {
            spotIndex = 0;
            state = TreeState.BONEMEALING;
        }
    }

    private void boneMealSaplings() {
        int boneMealSlot = findSlotMatching(class_1802.field_8324);
        if (boneMealSlot == -1) {
            ChatUtils.error("No bone meal!");
            state = TreeState.SEARCHING;
            return;
        }

        if (anyTreeGrown()) {
            mc.field_1690.field_1904.method_23481(false);
            state = TreeState.MINING;
            ChatUtils.info("Tree grown! Starting to mine...");
            return;
        }

        saveSlotOnce();
        mc.field_1724.method_31548().method_61496(boneMealSlot);
        syncSlot();

        class_2338 target = farmCenter.method_10069(0, 1, 0);
        lookAt(target);

        mc.field_1690.field_1904.method_23481(true);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808,
                new class_3965(class_243.method_24953(target), class_2350.field_11036, target, false));
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void mineTrees() {
        mc.field_1690.field_1904.method_23481(false);

        class_2338 topLog = farmCenter.method_10069(0, 1, 0);
        if (mc.field_1687.method_8320(topLog).method_26204() != class_2246.field_10037) {
            releaseDigKeys();
            state = TreeState.WAIT;
            return;
        }

        int axeSlot = findAxeSlot();
        if (axeSlot == -1) {
            ChatUtils.error("No axe found!");
            state = TreeState.SEARCHING;
            return;
        }

        saveSlotOnce();
        mc.field_1724.method_31548().method_61496(axeSlot);
        syncSlot();

        lookAt(topLog);
        mc.field_1690.field_1886.method_23481(true);
        mc.field_1761.method_2910(farmCenter.method_10069(0, 1, 0), class_2350.field_11033);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void waitCycle() {
        releaseDigKeys();
        state = TreeState.SEARCHING;
        farmCenter = null;
        saplingSpots.clear();
        spotIndex = 0;
    }

    private boolean anyTreeGrown() {
        for (int dx = 0; dx < 2; dx++) {
            for (int dz = 0; dz < 2; dz++) {
                class_2248 above = mc.field_1687.method_8320(farmCenter.method_10069(dx, 1, dz)).method_26204();
                if (above != class_2246.field_10217 && above != class_2246.field_10124)
                    return true;
            }
        }
        return false;
    }

    private void releaseDigKeys() {
        mc.field_1690.field_1904.method_23481(false);
        mc.field_1690.field_1886.method_23481(false);
    }

    private void refillHotbar() {
        ensureHotbarHas(class_1802.field_8324, boneMealCount.getValueInt());
        ensureHotbarHas(class_1802.field_17536, saplingCount.getValueInt());
    }

    private void ensureHotbarHas(net.minecraft.class_1792 item, int minCount) {
        if (countInInventory(item) >= minCount)
            return;

        int source = -1;
        for (int i = 9; i < mc.field_1724.method_31548().method_5439(); i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item)) {
                source = i;
                break;
            }
        }
        if (source == -1)
            return;

        int dest = findHotbarSlotWith(item);
        if (dest == -1)
            dest = findEmptyHotbarSlot();
        if (dest == -1)
            return;

        final int syncId = mc.field_1724.field_7498.field_7763;
        final int src = source;
        final int dst = dest;
        mc.execute(() -> mc.field_1761.method_2906(syncId, src, 0, net.minecraft.class_1713.field_7790, mc.field_1724));
        mc.execute(() -> mc.field_1761.method_2906(syncId, dst, 0, net.minecraft.class_1713.field_7790, mc.field_1724));
        mc.execute(() -> mc.field_1761.method_2906(syncId, src, 0, net.minecraft.class_1713.field_7790, mc.field_1724));
    }

    private int countInInventory(net.minecraft.class_1792 item) {
        int count = 0;
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(item))
                count += stack.method_7947();
        }
        return count;
    }

    private int findHotbarSlotWith(net.minecraft.class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item))
                return i;
        }
        return -1;
    }

    private int findEmptyHotbarSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960())
                return i;
        }
        return -1;
    }

    private int findSlotMatching(net.minecraft.class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item))
                return i;
        }
        return -1;
    }

    private int findAxeSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1743)
                return i;
        }
        return -1;
    }

    private void saveSlotOnce() {
        if (savedSlot == -1)
            savedSlot = mc.field_1724.method_31548().method_67532();
    }

    private void lookAt(class_2338 target) {
        class_243 delta = class_243.method_24953(target).method_1020(mc.field_1724.method_33571()).method_1029();
        mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350)));
        mc.field_1724.method_36457((float) (-Math.toDegrees(Math.asin(delta.field_1351))));
    }

    private void syncSlot() {
        if (mc.field_1761 != null)
            ((ClientPlayerInteractionManagerAccessor) mc.field_1761).syncSlot();
    }
}