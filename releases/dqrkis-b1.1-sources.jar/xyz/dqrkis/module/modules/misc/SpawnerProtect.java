package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.ChatUtils;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.KeyUtils;
import xyz.dqrkis.utils.RotationUtils;
import xyz.dqrkis.utils.WorldUtils;
import xyz.dqrkis.mixin.ClientPlayerInteractionManagerAccessor;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public final class SpawnerProtect extends Module implements TickListener {
    public enum State {
        CHECKING,
        FINDSPAWNER,
        MINING,
        FINDENDERCHEST,
        OPENENDERCHEST,
        DUMPINVENTORY
    }

    private final BooleanSetting fastMode = new BooleanSetting("Fast Mode", true);
    private final NumberSetting emergencyDistance = new NumberSetting("Emergency Distance", 1, 50, 5, 0.5);

    private State state = State.CHECKING;
    private final List<class_2338> foundSpawners = new ArrayList<>();
    private int scanRadius = 10;
    private int currentSpawnerIndex = 0;
    private int miningTicks = 0;
    private int miningStage = 0;
    private int enderChestOpenTicks = 0;
    private int dumpSlot = 0;
    private boolean playerDetected = false;
    private boolean rotationComplete = false;
    private int rotationWaitTicks = 0;
    private int dumpProgress = 0;
    private int dumpInventoryTicks = 0;
    private int restartCooldown = 0;
    private int spawnScanCooldown = 0;
    private int recheckSpawnerTicks = 0;
    private int resumeCooldown = 0;
    private boolean spawnerRecheck = false;
    private boolean rotationDone = false;
    private int noPickaxeTicks = 0;
    private class_2338 originalPos;
    private boolean positionChanged = false;
    private boolean isResuming = false;
    private int resumeWait = 0;
    private class_2338 enderChestPos;
    private boolean isLookingAtChest = false;
    private int chestOpenWait = 0;
    private int dumpSlotIndex = 0;
    private int dumpWaitTicks = 0;
    private int spawnerVerifiedTicks = 0;
    private boolean spawnerVerified = false;
    private int attackTicks = 0;
    private int verificationWait = 0;
    private boolean pickaxeSwapped = false;
    private int originalSlot = -1;
    private boolean spawnerListCleared = false;

    private final BooleanSetting fastModeSetting = fastMode;
    private final NumberSetting emergencyDistSetting = emergencyDistance;

    public SpawnerProtect() {
        super("Spawner Protect",
                "Breaks all spawners around you when players are nearby and dumps your inventory in an e-chest",
                -1,
                Category.MISC);
        addSettings(fastMode, emergencyDistance);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        resetState();
        if (mc.field_1724 != null) {
            originalPos = mc.field_1724.method_24515();
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        if (mc.field_1690.field_1832.method_1434()) {
            mc.field_1690.field_1832.method_23481(false);
        }
        if (mc.field_1690.field_1886.method_1434()) {
            mc.field_1690.field_1886.method_23481(false);
        }
        if (mc.field_1690.field_1904.method_1434()) {
            mc.field_1690.field_1904.method_23481(false);
        }
        restoreOriginalSlot();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            return;
        }

        checkRestart();

        if (mc.field_1755 != null) {
            return;
        }

        if (mc.field_1724.method_7325()) {
            return;
        }

        // Sneak while in active states
        if (state == State.CHECKING || state == State.FINDSPAWNER || state == State.MINING) {
            mc.field_1724.method_5660(true);
            mc.field_1690.field_1832.method_23481(true);
        }

        // Check for nearby players (emergency distance)
        checkNearbyPlayers();

        // State machine
        switch (state) {
            case CHECKING -> checkState();
            case FINDSPAWNER -> findSpawners();
            case MINING -> mineSpawners();
            case FINDENDERCHEST -> findEnderChest();
            case OPENENDERCHEST -> openEnderChest();
            case DUMPINVENTORY -> dumpInventory();
        }

        // Resume cooldown
        if (resumeCooldown > 0) {
            resumeCooldown--;
        }
    }

    private void resetState() {
        state = State.CHECKING;
        foundSpawners.clear();
        spawnerRecheck = false;
        rotationDone = false;
        attackTicks = 0;
        verificationWait = 0;
        pickaxeSwapped = false;
        originalSlot = -1;
        spawnerListCleared = false;
        spawnerVerified = false;
        enderChestPos = null;
        isLookingAtChest = false;
        chestOpenWait = 0;
        dumpSlotIndex = 0;
        dumpWaitTicks = 0;
        spawnerVerifiedTicks = 0;
        spawnerVerified = false;
        attackTicks = 0;
        verificationWait = 0;
        pickaxeSwapped = false;
        originalSlot = -1;
        spawnerListCleared = false;
        spawnerVerified = false;
        enderChestPos = null;
        isLookingAtChest = false;
        chestOpenWait = 0;
        dumpSlotIndex = 0;
        dumpWaitTicks = 0;
    }

    private void checkRestart() {
        if (mc.field_1724 != null && originalPos != null) {
            class_2338 currentPos = mc.field_1724.method_24515();
            if (!currentPos.equals(originalPos) && !positionChanged) {
                positionChanged = true;
                isResuming = true;
                resumeWait = 40;
                sendChat("Restart Detected");
                state = State.CHECKING;
                foundSpawners.clear();
                rotationDone = false;
                if (originalSlot != -1) {
                    mc.field_1724.method_31548().method_61496(originalSlot);
                    syncSlot();
                    originalSlot = -1;
                }
                mc.field_1690.field_1886.method_23481(false);
            }
            originalPos = mc.field_1724.method_24515();

            if (resumeCooldown > 0) {
                resumeCooldown--;
            }
        }
    }

    private void checkState() {
        if (mc.field_1724 == null) return;

        int pickaxeSlot = findSilkTouchPickaxe();
        if (pickaxeSlot == -1) {
            ChatUtils.error("Please Get A Silk Touch Pickaxe!");
            setEnabled(false);
            return;
        }

        if (mc.field_1755 != null) {
            mc.execute(() -> {
                if (mc.field_1755 != null) {
                    mc.field_1755.method_25419();
                }
            });
        }

        int slot = findSilkTouchPickaxe();
        if (slot != -1) {
            originalSlot = mc.field_1724.method_31548().method_67532();
            mc.field_1724.method_31548().method_61496(slot);
            syncSlot();
        }

        playerDetected = false;
        rotationDone = false;
        rotationWaitTicks = 0;
        state = State.FINDSPAWNER;
        spawnerRecheck = false;
        rotationDone = false;
        attackTicks = 0;
        verificationWait = 0;
        pickaxeSwapped = false;
        originalSlot = -1;
        spawnerListCleared = false;
        isLookingAtChest = false;
        chestOpenWait = 0;
        dumpSlotIndex = 0;
        dumpWaitTicks = 0;
        if (mc.field_1724 != null) {
            class_2338 pos = mc.field_1724.method_24515();
        }
    }

    private void findSpawners() {
        foundSpawners.clear();
        class_2338 playerPos = mc.field_1724.method_24515();
        int radius = 10; // fixed scan radius

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2338 pos = mc.field_1724.method_24515().method_10069(dx, dy, dz);
                    if (mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10260) {
                        foundSpawners.add(pos);
                    }
                }
            }
        }

        if (foundSpawners.isEmpty()) {
            sendChat("No Spawners Found");
            state = State.CHECKING;
        } else {
            sendChat("Found " + foundSpawners.size() + " Spawners");
            currentSpawnerIndex = 0;
            spawnerRecheck = false;
            rotationDone = false;
            state = State.MINING;
        }
    }

    private void mineSpawners() {
        if (currentSpawnerIndex >= foundSpawners.size()) {
            sendChat("Mined Spawners");
            if (originalSlot != -1) {
                mc.field_1724.method_31548().method_61496(originalSlot);
                syncSlot();
                originalSlot = -1;
            }
            mc.field_1690.field_1886.method_23481(false);
            state = State.FINDENDERCHEST;
            foundSpawners.clear();
            currentSpawnerIndex = 0;
            return;
        }

        class_2338 target = foundSpawners.get(currentSpawnerIndex);
        class_2248 block = mc.field_1687.method_8320(target).method_26204();

        if (block != class_2246.field_10260 && !spawnerRecheck) {
            spawnerRecheck = true;
            spawnerVerifiedTicks = 0;
            mc.field_1690.field_1886.method_23481(false);
        } else if (spawnerRecheck) {
            spawnerVerifiedTicks++;
            if (spawnerVerifiedTicks < 10) {
                return;
            }
            class_2248 blockCheck = mc.field_1687.method_8320(target).method_26204();
            if (blockCheck != class_2246.field_10260) {
                sendChat("Spawner " + (currentSpawnerIndex + 1) + " Already Broken, Moving To Next");
                currentSpawnerIndex++;
                spawnerRecheck = false;
                spawnerVerified = false;
                spawnerVerifiedTicks = 0;
                attackTicks = 0;
                rotationDone = false;
                return;
            } else {
                int spawnerNum = currentSpawnerIndex + 1;
                int total = foundSpawners.size();
                sendChat("Spawner " + spawnerNum + " Detected After Verification");
                spawnerRecheck = false;
                spawnerVerified = false;
                spawnerVerifiedTicks = 0;
            }
        }

        if (!rotationDone && originalSlot == -1) {
            int pickaxeSlot = findSilkTouchPickaxe();
            if (pickaxeSlot == -1) {
                sendError("No Silk Touch Pickaxe Found In Hotbar!");
                state = State.CHECKING;
                return;
            }
            originalSlot = mc.field_1724.method_31548().method_67532();
            mc.field_1724.method_31548().method_61496(pickaxeSlot);
            syncSlot();
            pickaxeSwapped = true;
        }

        class_243 targetVec = class_243.method_24953(target);
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 diff = targetVec.method_1020(eyePos).method_1029();
        float yaw = (float) Math.toDegrees(Math.atan2(diff.field_1350, diff.field_1352)) - 90.0F;
        float pitch = (float) (-Math.toDegrees(Math.asin(diff.field_1351)));

        if (!rotationDone) {
            mc.field_1690.field_1886.method_23481(false);
            if (!RotationUtils.isRotating()) {
                RotationUtils.rotateTo(yaw, pitch, () -> {
                    rotationDone = true;
                    rotationWaitTicks = 0;
                });
            }
        } else {
            attackTicks++;
            mc.field_1690.field_1886.method_23481(true);
            if (attackTicks % 5 == 0) {
                class_2248 checkBlock = mc.field_1687.method_8320(target).method_26204();
                if (block != class_2246.field_10260) {
                    int mined = currentSpawnerIndex + 1;
                    int total = foundSpawners.size();
                    sendChat("Mined Spawner " + mined + "/" + total);
                    mc.field_1690.field_1886.method_23481(false);
                    currentSpawnerIndex++;
                    rotationDone = false;
                    attackTicks = 0;
                }
            }
        }
    }

    private void findEnderChest() {
        class_2338 playerPos = mc.field_1724.method_24515();
        class_2338 found = null;
        double bestDist = Double.MAX_VALUE;

        for (int dx = -10; dx <= 10; dx++) {
            for (int dy = -10; dy <= 10; dy++) {
                for (int dz = -10; dz <= 10; dz++) {
                    class_2338 pos = mc.field_1724.method_24515().method_10069(dx, dy, dz);
                    if (mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10443) {
                        double dist = playerPos.method_10262(pos);
                        if (dist < bestDist) {
                            bestDist = dist;
                            enderChestPos = pos;
                        }
                    }
                }
            }
        }

        if (enderChestPos == null) {
            sendError("No E-Chest Found!");
            state = State.CHECKING;
        } else {
            sendChat("Found E-Chest at " + enderChestPos.method_23854());
            mc.field_1724.method_5660(false);
            mc.field_1690.field_1832.method_23481(false);
            state = State.OPENENDERCHEST;
        }
    }

    private void openEnderChest() {
        if (enderChestPos == null) {
            state = State.CHECKING;
            return;
        }

        if (mc.field_1687.method_8320(enderChestPos).method_26204() != class_2246.field_10443) {
            sendError("E-Chest vanished!");
            state = State.CHECKING;
            return;
        }

        if (!isLookingAtChest && !rotationDone) {
            class_243 target = class_243.method_24953(enderChestPos);
            class_243 eyePos = mc.field_1724.method_33571();
            class_243 diff = target.method_1020(eyePos).method_1029();
            float yaw = (float) Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
            float pitch = (float) (-Math.toDegrees(Math.asin(diff.field_1351)));

            if (!RotationUtils.isRotating()) {
                RotationUtils.rotateTo(yaw, pitch, () -> {
                    rotationDone = true;
                    chestOpenWait = 10;
                });
            }
        } else if (rotationDone) {
            if (chestOpenWait > 0) {
                chestOpenWait--;
            } else {
                class_3965 hit = new class_3965(class_243.method_24953(enderChestPos), class_2350.field_11036, enderChestPos, false);
                class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
                if (result.method_23665()) {
                    isLookingAtChest = true;
                    chestOpenWait = 10;
                    state = State.DUMPINVENTORY;
                    dumpProgress = 0;
                    dumpWaitTicks = 0;
                } else {
                    rotationDone = false;
                }
            }
        }
    }

    private void dumpInventory() {
        class_1703 handler = mc.field_1724.field_7512;
        if (handler != null && handler != mc.field_1724.field_7498) {
            if (dumpProgress < 36) {
                int slot = 36 + dumpProgress; // start after hotbar
                if (slot < mc.field_1724.field_7498.field_7761.size()) {
                    mc.execute(() -> mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7794, mc.field_1724));
                    dumpProgress++;
                } else {
                    mc.execute(() -> {
                        if (mc.field_1755 != null) {
                            mc.field_1724.method_7346();
                        }
                    });
                    sendChat("Dumped Inventory");
                    sendChat("Spawners Saved!");
                    enderChestPos = null;
                    isLookingAtChest = false;
                    state = State.CHECKING;
                }
            } else {
                mc.execute(() -> {
                    if (mc.field_1755 != null) {
                        mc.field_1724.method_7346();
                    }
                });
                sendChat("Dumped Inventory");
                sendChat("Spawners Saved!");
                enderChestPos = null;
                isLookingAtChest = false;
                state = State.CHECKING;
            }
        } else {
            if (!isLookingAtChest) {
                sendError("E-Chest Not Opened");
                isLookingAtChest = false;
                state = State.OPENENDERCHEST;
            }
        }
    }

    private void checkNearbyPlayers() {
        if (emergencyDistSetting.getValue() > 0) {
            double range = emergencyDistSetting.getValue();
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player == mc.field_1724 || player.method_7325()) continue;

                double dist = mc.field_1724.method_5739(player);
                if (dist <= range) {
                    sendEmergencyAlert(player.method_5477().getString(), dist);
                    playerDetected = true;
                    return;
                }
            }
        }
    }

    private void sendEmergencyAlert(String playerName, double distance) {
        String msg = String.format("Emergency Distance Triggered! Player: %s (%.1f blocks)", playerName, distance);
        sendChat(msg);
    }

    private int findSilkTouchPickaxe() {
        if (mc.field_1724 == null) return -1;
        class_6880<class_1887> silkTouch;
        try {
            silkTouch = mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9099);
        } catch (Exception e) {
            return -1;
        }
        if (silkTouch == null) return -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_8377) || stack.method_31574(class_1802.field_22024) || stack.method_31574(class_1802.field_8403)) {
                if (class_1890.method_8225(silkTouch, stack) > 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    private void syncSlot() {
        if (mc.field_1761 != null) {
            ((ClientPlayerInteractionManagerAccessor) mc.field_1761).syncSlot();
        }
    }

    private void sendChat(String message) {
        ChatUtils.info(message);
    }

    private void sendError(String message) {
        ChatUtils.error(message);
    }

    private void restoreOriginalSlot() {
        if (originalSlot != -1 && mc.field_1724 != null) {
            mc.field_1724.method_31548().method_61496(originalSlot);
            syncSlot();
            originalSlot = -1;
        }
    }
}