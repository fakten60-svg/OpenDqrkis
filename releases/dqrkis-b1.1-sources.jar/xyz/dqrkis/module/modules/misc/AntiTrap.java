package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1531;
import net.minecraft.class_1533;

public final class AntiTrap extends Module implements TickListener {
	private final Set<class_1297> hiddenEntities = new HashSet<>();

	public AntiTrap() {
		super("Anti Trap",
				"Helps you escape traps by removing certain entities.",
				-1,
				Category.MISC);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);

		for (class_1297 entity : new HashSet<>(hiddenEntities)) {
			if (entity != null && !entity.method_31481() && mc.field_1687 != null)
				setHidden(entity, false);
		}
		hiddenEntities.clear();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1687 == null || mc.field_1724 == null)
			return;

		for (class_1297 entity : mc.field_1687.method_18112()) {
			if (entity == null || entity.method_31481())
				continue;

			if (isTrapEntity(entity)) {
				if (!hiddenEntities.contains(entity)) {
					setHidden(entity, true);
					hiddenEntities.add(entity);
				}
			} else if (hiddenEntities.contains(entity)) {
				setHidden(entity, false);
				hiddenEntities.remove(entity);
			}
		}

		hiddenEntities.removeIf(entity -> entity == null || entity.method_31481());
	}

	private boolean isTrapEntity(class_1297 entity) {
		if (entity instanceof class_1531 || entity instanceof class_1533)
			return true;

		class_1299<?> type = entity.method_5864();
		return type == class_1299.field_6131 || type == class_1299.field_6043
				|| type == class_1299.field_28401 || type == class_1299.field_6126;
	}

	private void setHidden(class_1297 entity, boolean hidden) {
		if (entity.method_31481())
			return;

		entity.method_5648(hidden);
	}
}
