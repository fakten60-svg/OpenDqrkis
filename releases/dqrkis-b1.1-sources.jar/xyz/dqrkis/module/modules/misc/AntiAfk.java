package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_3532;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;

public final class AntiAfk extends Module implements TickListener {
	private final NumberSetting interval = new NumberSetting("Interval", 20, 600, 100, 10)
			.setDescription("Ticks between view rotations");

	private int ticks;

	public AntiAfk() {
		super("Anti AFK",
				"Prevents you from being kicked for being AFK by rotating your view",
				-1,
				Category.MISC);
		addSettings(interval);
	}

	@Override
	public void onEnable() {
		ticks = 0;
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		ticks = 0;
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null)
			return;

		if (++ticks < interval.getValueInt())
			return;

		ticks = 0;
		float yaw = mc.field_1724.method_36454() + (float) (Math.random() * 10.0 - 5.0);
		float pitch = class_3532.method_15363(mc.field_1724.method_36455() + (float) (Math.random() * 10.0 - 5.0), -90.0F, 90.0F);
		mc.field_1724.method_36456(yaw);
		mc.field_1724.method_36457(pitch);
	}
}
