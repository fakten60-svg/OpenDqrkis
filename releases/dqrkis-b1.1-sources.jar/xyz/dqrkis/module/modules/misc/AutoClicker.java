package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.MinecraftClientAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.MathUtils;
import xyz.dqrkis.utils.MouseSimulation;
import xyz.dqrkis.utils.TimerUtils;
import xyz.dqrkis.utils.WorldUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1811;
import net.minecraft.class_239;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;


public final class AutoClicker extends Module implements TickListener {
	private final BooleanSetting onlyWeapon = new BooleanSetting("Only Weapon", true)
			.setDescription("Only left clicks with weapon in hand");
	private final BooleanSetting onlyBlocks = new BooleanSetting("Only Blocks", true)
			.setDescription("Only right clicks blocks");
	private final BooleanSetting onClick = new BooleanSetting("On Click", true);

	private final NumberSetting delay = new NumberSetting("Delay", 0, 1000, 0, 1);
	private final NumberSetting chance = new NumberSetting("Chance", 0, 100, 100, 1);
	private final ModeSetting<Mode> mode = new ModeSetting<>("Actions", Mode.All, Mode.class);
	private final TimerUtils timer = new TimerUtils();

	public enum Mode {
		All, Left, Right
	}

	public AutoClicker() {
		super("Auto Clicker",
				"Automatically clicks for you",
				-1,
				Category.MISC);

		addSettings(onlyWeapon, onClick, delay, chance, mode);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		timer.reset();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	//using this cuz its faster/instant
	@Override
	public void onTick() {
		if (mc.field_1724 == null)
			return;

		if (mc.field_1755 != null)
			return;

		if (mc.field_1765 == null)
			return;

		if (timer.delay(delay.getValueFloat()) && chance.getValueInt() >= MathUtils.randomInt(1, 100)) {
			if (mode.isMode(Mode.Left)) {
				performLeftClick();
			}

			if (mode.isMode(Mode.Right)) {
				performRightClick();
			}

			if (mode.isMode(Mode.All)) {
				performLeftClick();
				performRightClick();
			}
		}
	}

	private void performRightClick() {
		class_1792 mainhand = mc.field_1724.method_6047().method_7909();
		class_1792 offhand = mc.field_1724.method_6079().method_7909();

		if (mainhand.method_57347().method_57832(class_9334.field_50075))
			return;

		if (offhand.method_57347().method_57832(class_9334.field_50075))
			return;

		if (mainhand instanceof class_1811 || offhand instanceof class_1811)
			return;

		if (onClick.getValue() && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) != GLFW.GLFW_PRESS)
			return;

		MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

		((MinecraftClientAccessor) mc).invokeDoItemUse();
		timer.reset();
	}

	private void performLeftClick() {
		class_1792 mainhand = mc.field_1724.method_6047().method_7909();
		class_1792 offhand = mc.field_1724.method_6079().method_7909();

		if (mc.field_1765.method_17783() == class_239.class_240.field_1332)
			return;

		if (mc.field_1724.method_6115())
			return;

		if (onlyWeapon.getValue() && !WorldUtils.isWeapon(mc.field_1724.method_6047()))
			return;

		if (onClick.getValue() && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			return;

		MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

		((MinecraftClientAccessor) mc).invokeDoAttack();
		timer.reset();
	}
}
