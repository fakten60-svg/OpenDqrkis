package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_476;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ItemSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.ChatUtils;

public final class AutoBoneOrder extends Module implements TickListener {
    private final StringSetting orderName = new StringSetting("Order Name", "bones");
    private final ItemSetting orderItem = new ItemSetting("Order Item", class_1802.field_8606);
    private final NumberSetting clickDelay = new NumberSetting("Click Delay (ticks)", 1, 10, 2, 1);
    private final NumberSetting guiTimeout = new NumberSetting("GUI Timeout (ticks)", 20, 200, 60, 5);

    private enum State { IDLE, OPEN_ORDERS, WAIT_ORDERS_GUI, CLICK_SLOT_51, WAIT_SECOND_GUI, CLICK_TARGET_ITEM, WAIT_THIRD_GUI, CLICK_CHEST_SLOT, WAIT_ITEMS_GUI, COLLECT_ITEMS }
    private State state = State.IDLE;
    private int ticks;
    private long stateEnteredAt;

    public AutoBoneOrder() {
        super("Auto Bone Order", "Automates ordering bones", -1, Category.MISC);
        addSettings(orderName, orderItem, clickDelay, guiTimeout);
    }

    @Override public void onEnable() { eventManager.add(TickListener.class, this); state = State.IDLE; ticks = 0; super.onEnable(); }
    @Override public void onDisable() { eventManager.remove(TickListener.class, this); super.onDisable(); }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        switch (state) {
            case IDLE -> {
                mc.field_1724.field_3944.method_45730("order");
                state = State.WAIT_ORDERS_GUI; stateEnteredAt = System.currentTimeMillis(); ticks = clickDelay.getValueInt();
            }
            case WAIT_ORDERS_GUI -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476) { state = State.CLICK_SLOT_51; ticks = clickDelay.getValueInt(); }
                else if (System.currentTimeMillis() - stateEnteredAt > guiTimeout.getValueInt() * 50L) { ChatUtils.error("Order GUI timeout"); setEnabled(false); }
            }
            case CLICK_SLOT_51 -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476 screen) {
                    var handler = screen.method_17577();
                    if (handler.field_7761.size() > 51) mc.field_1761.method_2906(handler.field_7763, 51, 0, class_1713.field_7790, mc.field_1724);
                    state = State.WAIT_SECOND_GUI; stateEnteredAt = System.currentTimeMillis(); ticks = clickDelay.getValueInt();
                }
            }
            case WAIT_SECOND_GUI -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476) { state = State.CLICK_TARGET_ITEM; ticks = clickDelay.getValueInt(); }
            }
            case CLICK_TARGET_ITEM -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476 screen) {
                    var handler = screen.method_17577();
                    // Find slot containing the desired item (bone)
                    for (int i = 0; i < Math.min(handler.field_7761.size(), 54); i++) {
                        if (handler.method_7611(i).method_7677().method_31574(orderItem.getItem())) {
                            mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, mc.field_1724);
                            break;
                        }
                    }
                    state = State.WAIT_THIRD_GUI; stateEnteredAt = System.currentTimeMillis(); ticks = clickDelay.getValueInt();
                }
            }
            case WAIT_THIRD_GUI -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476) { state = State.CLICK_CHEST_SLOT; ticks = clickDelay.getValueInt(); }
            }
            case CLICK_CHEST_SLOT -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476 screen) {
                    // Click chest slots 11-16 etc. (original checks 11-16,20-24)
                    int[] chestSlots = {11,12,13,14,15,16,20,21,22,23,24};
                    for (int s : chestSlots) if (screen.method_17577().field_7761.size() > s && screen.method_17577().method_7611(s).method_7677().method_31574(class_1802.field_8106)) { mc.field_1761.method_2906(screen.method_17577().field_7763, s, 0, class_1713.field_7790, mc.field_1724); break; }
                    state = State.WAIT_ITEMS_GUI; stateEnteredAt = System.currentTimeMillis(); ticks = clickDelay.getValueInt();
                }
            }
            case WAIT_ITEMS_GUI -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476) { state = State.COLLECT_ITEMS; ticks = clickDelay.getValueInt(); }
            }
            case COLLECT_ITEMS -> {
                if (ticks-- > 0) return;
                if (mc.field_1755 instanceof class_476 screen) {
                    boolean collected = false;
                    for (int i = 0; i < Math.min(screen.method_17577().field_7761.size(), 54); i++) {
                        if (screen.method_17577().method_7611(i).method_7677().method_31574(orderItem.getItem())) {
                            mc.field_1761.method_2906(screen.method_17577().field_7763, i, 0, class_1713.field_7790, mc.field_1724);
                            collected = true; break;
                        }
                    }
                    mc.field_1724.method_7346();
                    ChatUtils.info(collected ? "Collected " + orderItem.getItem().toString() : "No items found to collect");
                    setEnabled(false);
                }
            }
        }
    }
}
