package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.utils.ChatUtils;

public final class ShopBuyer extends Module implements TickListener {
	public enum ShopItem {
		Obsidian(9, class_1802.field_8281),
		EndCrystal(10, class_1802.field_8301),
		RespawnAnchor(11, class_1802.field_23141),
		Glowstone(12, class_1802.field_8801),
		Totem(13, class_1802.field_8288),
		EnderPearl(14, class_1802.field_8634),
		GoldenApple(15, class_1802.field_8463),
		XpBottle(16, class_1802.field_8287),
		TippedArrow(17, class_1802.field_8087);

		public final int slot;
		public final net.minecraft.class_1792 item;

		ShopItem(int slot, net.minecraft.class_1792 item) {
			this.slot = slot;
			this.item = item;
		}
	}

	private final ModeSetting<ShopItem> item = new ModeSetting<>("Item", ShopItem.Obsidian, ShopItem.class);
	private final BooleanSetting autoDrop = new BooleanSetting("Auto Drop", true)
			.setDescription("Drops the bought items on the ground");

	private int delayTicks;
	private boolean inCategoryPage;
	private boolean inBuyPage;

	public ShopBuyer() {
		super("Shop Buyer",
				"Automatically buys selected items from PVP shop category",
				-1,
				Category.MISC);
		addSettings(item, autoDrop);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		delayTicks = 0;
		resetPageFlags();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		delayTicks = 0;
		resetPageFlags();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null)
			return;

		if (delayTicks > 0) {
			delayTicks--;
			return;
		}

		class_1703 handler = mc.field_1724.field_7512;
		if (!(handler instanceof class_1707 container)) {
			mc.field_1724.field_3944.method_45730("shop");
			delayTicks = 1;
			resetPageFlags();
			return;
		}

		int rows = container.method_17388();
		updatePageFlags(handler);

		if (rows == 3) {
			if (isBuyConfirmPage(handler)) {
				collectPurchase(handler);
				return;
			}

			if (isMainCategoryPage(handler)) {
				buySelected(handler);
				return;
			}

			if (isRootPage(handler)) {
				openPvpCategory(handler);
				return;
			}
		}

		resetPageFlags();
	}

	private void updatePageFlags(class_1703 handler) {
		if (isBuyConfirmPage(handler)) {
			inBuyPage = true;
		} else if (isMainCategoryPage(handler)) {
			inCategoryPage = true;
			inBuyPage = false;
		} else if (isRootPage(handler)) {
			inCategoryPage = false;
			inBuyPage = false;
		}
	}

	private boolean isRootPage(class_1703 handler) {
		return handler.method_7611(13).method_7677().method_31574(class_1802.field_8288) && !isBuyConfirmPage(handler);
	}

	private boolean isMainCategoryPage(class_1703 handler) {
		return handler.method_7611(9).method_7677().method_31574(class_1802.field_8281)
				|| handler.method_7611(10).method_7677().method_31574(class_1802.field_8301)
				|| handler.method_7611(11).method_7677().method_31574(class_1802.field_23141)
				|| handler.method_7611(12).method_7677().method_31574(class_1802.field_8801);
	}

	private boolean isBuyConfirmPage(class_1703 handler) {
		for (int i = 0; i < handler.field_7761.size(); i++) {
			if (handler.method_7611(i).method_7677().method_31574(class_1802.field_8581))
				return true;
		}
		return false;
	}

	private void openPvpCategory(class_1703 handler) {
		mc.field_1761.method_2906(handler.field_7763, 13, 0, class_1713.field_7790, mc.field_1724);
		delayTicks = 1;
		inCategoryPage = true;
	}

	private void buySelected(class_1703 handler) {
		ShopItem shopItem = item.getMode();
		int slot = shopItem.slot;

		if (slot != -1 && handler.method_7611(slot).method_7677().method_31574(shopItem.item))
			clickAndAwait(handler, slot);
	}

	private void clickAndAwait(class_1703 handler, int slot) {
		mc.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7790, mc.field_1724);
		delayTicks = 1;
		inBuyPage = true;
	}

	private void collectPurchase(class_1703 handler) {
		for (int i = 0; i < handler.field_7761.size(); i++) {
			if (handler.method_7611(i).method_7677().method_31574(class_1802.field_8581) && handler.method_7611(i).method_7677().method_7947() == 64) {
				mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, mc.field_1724);
				delayTicks = 1;
				return;
			}
		}

		for (int i = 0; i < handler.field_7761.size(); i++) {
			if (handler.method_7611(i).method_7677().method_31574(class_1802.field_8581)) {
				mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7790, mc.field_1724);
				delayTicks = 1;

				if (autoDrop.getValue())
					mc.field_1724.field_3944.method_52787(new class_2846(
							class_2846.class_2847.field_12970, class_2338.field_10980, class_2350.field_11033));

				resetPageFlags();
				return;
			}
		}
	}

	private void resetPageFlags() {
		inCategoryPage = false;
		inBuyPage = false;
	}
}
