package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2627;
import net.minecraft.class_2636;
import net.minecraft.class_2661;
import net.minecraft.class_2669;
import net.minecraft.class_2680;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.ChatUtils;
import xyz.dqrkis.utils.WorldUtils;

public final class TunnelBaseFinder extends Module implements TickListener {
    public enum MiningStyle { CRAWL, STANDING, AMETHYST }

    private static final int SCAN_INTERVAL_TICKS = 40;
    private static final long MIN_SESSION_MS = 5000L;

    private final ModeSetting<MiningStyle> miningStyle = new ModeSetting<>("Mining Style", MiningStyle.AMETHYST, MiningStyle.class);
    private final BooleanSetting spawnerCritical = new BooleanSetting("Spawner Critical", false);
    private final BooleanSetting humanize = new BooleanSetting("Humanize", true);
    private final NumberSetting delayRandomness = new NumberSetting("Delay Randomness", 0, 10, 3, 1);

    private class_2350 tunnelDirection = class_2350.field_11043;
    private int scanCounter;
    private int breakDelayTicks;
    private boolean miningPaused;
    private long sessionStartMs = -1L;
    private boolean waitingForStabilize = true;

    private int chests, shulkers, pistons;
    private boolean spawnerFound;

    public TunnelBaseFinder() {
        super("Tunnel Base Finder",
                "Digs in tunnels until you find a base",
                -1,
                Category.MISC);
        addSettings(miningStyle, spawnerCritical, humanize, delayRandomness);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        tunnelDirection = mc.field_1724 != null ? mc.field_1724.method_5735() : class_2350.field_11043;
        scanCounter = 0;
        breakDelayTicks = 0;
        sessionStartMs = -1L;
        waitingForStabilize = true;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        releaseKeys();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null)
            return;

        if (mc.field_1687 == null || mc.field_1687.method_30349() == null) {
            sessionStartMs = -1L;
            waitingForStabilize = true;
            return;
        }

        if (sessionStartMs == -1L)
            sessionStartMs = System.currentTimeMillis();
        else if (waitingForStabilize
                && System.currentTimeMillis() - sessionStartMs >= MIN_SESSION_MS)
            waitingForStabilize = false;

        if (!offhandHasTotem()) {
            disconnectWithReason("Totem Popped");
            return;
        }

        if (++scanCounter >= SCAN_INTERVAL_TICKS) {
            scanCounter = 0;
            scanLoadedChunks();
        }

        digStep();
    }

    private void digStep() {
        if (!holdingPickaxe()) {
            releaseKeys();
            return;
        }

        class_2338 feet = mc.field_1724.method_24515();
        class_2338 head = feet.method_10069(0, 1, 0);

        if (isDiggable(mc.field_1687.method_8320(head).method_26204())) {
            lookAtBlock(head);
            holdAttack(true);
            pauseBetweenBreaks();
            return;
        }

        if (isDiggable(mc.field_1687.method_8320(feet).method_26204())) {
            lookAtBlock(feet);
            holdAttack(true);
            pauseBetweenBreaks();
            return;
        }

        holdAttack(false);

        class_2338 ahead = feet.method_10093(tunnelDirection);
        class_2338 aheadDown = ahead.method_10069(0, -1, 0);
        class_2680 belowAheadState = mc.field_1687.method_8320(aheadDown);
        class_2248 belowAheadBlock = belowAheadState.method_26204();
        class_2680 atAheadState = mc.field_1687.method_8320(ahead);
        class_2248 atAheadBlock = atAheadState.method_26204();

        if (atAheadState.method_26215() && !belowAheadState.method_26215()) {
            faceDirection(tunnelDirection);
            mc.field_1690.field_1894.method_23481(true);
        } else {
            mc.field_1690.field_1894.method_23481(false);
            if (!belowAheadState.method_26215())
                tunnelDirection = tunnelDirection.method_10170();
        }
    }

    private void holdAttack(boolean pressed) {
        if (pressed && breakDelayTicks > 0) {
            breakDelayTicks--;
            mc.field_1690.field_1886.method_23481(false);
            return;
        }
        mc.field_1690.field_1886.method_23481(pressed);
    }

    private void pauseBetweenBreaks() {
        if (!humanize.getValue())
            return;
        int base = 3;
        int variance = delayRandomness.getValueInt();
        breakDelayTicks = Math.max(1, base + (int) (Math.random() * variance * 2) - variance);
    }

    private boolean isDiggable(class_2248 block) {
        return !block.method_9564().method_26215()
                && block != class_2246.field_9987
                && block != class_2246.field_10164
                && block != class_2246.field_10382;
    }

    private boolean holdingPickaxe() {
        return mc.field_1724.method_6047().method_7909().toString().contains("pickaxe");
    }

    private void lookAtBlock(class_2338 pos) {
        class_243 delta = class_243.method_24953(pos).method_1020(mc.field_1724.method_33571()).method_1029();
        mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350)));
        mc.field_1724.method_36457((float) (-Math.toDegrees(Math.asin(delta.field_1351))));
    }

    private void faceDirection(class_2350 direction) {
        float yaw = switch (direction) {
            case field_11043 -> 180.0F;
            case field_11035 -> 0.0F;
            case field_11039 -> 90.0F;
            case field_11034 -> -90.0F;
            default -> mc.field_1724.method_36454();
        };
        mc.field_1724.method_36456(yaw);
        mc.field_1724.method_36457(0.0F);
    }

    private void scanLoadedChunks() {
        chests = 0;
        shulkers = 0;
        pistons = 0;
        spawnerFound = false;

        for (var chunk : WorldUtils.getLoadedChunks().toList()) {
            for (class_2338 pos : chunk.method_12021()) {
                class_2586 blockEntity = mc.field_1687.method_8321(pos);
                if (blockEntity == null)
                    continue;

                if (blockEntity instanceof class_2636)
                    spawnerFound = true;

                if (blockEntity.method_11016().method_10264() > 0)
                    continue;

                if (blockEntity instanceof class_2595) chests++;
                else if (blockEntity instanceof class_2627) shulkers++;
                else if (blockEntity instanceof class_2669) pistons++;
            }
        }

        if (chests >= 35)
            disconnectWithReason("BASE");
        else if (shulkers >= 20)
            disconnectWithReason("Shulker threshold reached");
        else if (spawnerFound && spawnerCritical.getValue())
            disconnectWithReason("Spawner found");
    }

    private boolean offhandHasTotem() {
        return mc.field_1724 != null && mc.field_1724.method_6079().method_7909() == class_1802.field_8288;
    }

    private void disconnectWithReason(String reason) {
        setEnabled(false);
        releaseKeys();
        if (mc.field_1724 != null && mc.field_1724.field_3944 != null)
            mc.field_1724.field_3944.method_52781(new class_2661(class_2561.method_43470("TunnelBaseFinder | " + reason)));
    }

    private void releaseKeys() {
        if (mc.field_1690 == null) return;
        mc.field_1690.field_1886.method_23481(false);
        mc.field_1690.field_1904.method_23481(false);
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1832.method_23481(false);
    }
}