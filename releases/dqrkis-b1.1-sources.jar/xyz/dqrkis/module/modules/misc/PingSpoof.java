package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_2670;
import net.minecraft.class_2827;
import xyz.dqrkis.event.events.PacketReceiveListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.MathUtils;

public final class PingSpoof extends Module implements PacketReceiveListener {
	private final MinMaxSetting ping = new MinMaxSetting("Ping", 0, 1000, 1, 0, 600)
			.setDescription("The ping you want to achieve");

	private int delay;
	public PingSpoof() {
		super("Ping Spoof",
				"Holds back packets making the server think your internet connection is bad.", -1, Category.MISC);
		addSettings(ping);
	}

	@Override
	public void onEnable() {
		eventManager.add(PacketReceiveListener.class, this);

		delay = ping.getRandomValueInt();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(PacketReceiveListener.class, this);
		super.onDisable();
	}

	@Override
	public void onPacketReceive(PacketReceiveEvent event) {
		if (event.packet instanceof class_2670 packet) {
			new Thread(() -> {
				try {
					Thread.sleep(delay);
					mc.method_1562().method_48296().method_10743(new class_2827(packet.method_11517()));
					delay = ping.getRandomValueInt();
				} catch (InterruptedException ignored) {}
			}).start();

			event.cancel();
		}
	}
}
