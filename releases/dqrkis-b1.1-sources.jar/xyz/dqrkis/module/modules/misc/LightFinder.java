package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2818;
import net.minecraft.class_638;

public final class LightFinder extends Module implements TickListener {
    private final NumberSetting scanRadius = new NumberSetting("Scan Radius", 1, 16, 4, 1);
    private final NumberSetting maxY = new NumberSetting("Max Y", 10, 120, 50, 5);
    private final NumberSetting minY = new NumberSetting("Min Y", -64, 60, -60, 5);
    private final NumberSetting lightThreshold = new NumberSetting("Light Threshold", 1, 15, 8, 1);
    private final NumberSetting minCluster = new NumberSetting("Min Cluster", 2, 30, 5, 1);
    private final NumberSetting clusterRadius = new NumberSetting("Cluster Radius", 3, 24, 8, 1);
    private final NumberSetting scanInterval = new NumberSetting("Scan Interval", 10, 300, 60, 10);
    private final BooleanSetting ignoreLava = new BooleanSetting("Ignore Lava", true);
    private final BooleanSetting showCoords = new BooleanSetting("Show Coords", true);

    private int ticksSinceScan;
    private final Set<Long> scannedChunks = new HashSet<>();
    private final List<LightCluster> foundClusters = new ArrayList<>();

    private record LightCluster(class_2338 center, int lightCount) {}

    public LightFinder() {
        super("Light Finder",
                "Finds underground bases using light data analysis",
                -1,
                Category.MISC);
        addSettings(scanRadius, maxY, minY, lightThreshold, minCluster, clusterRadius, scanInterval, ignoreLava, showCoords);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        resetState();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        resetState();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (++ticksSinceScan < scanInterval.getValueInt())
            return;

        ticksSinceScan = 0;
        mc.execute(this::scan);
    }

    private void scan() {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        class_638 world = mc.field_1687;
        class_1923 playerChunk = mc.field_1724.method_31476();
        int radius = scanRadius.getValueInt();
        int topY = maxY.getValueInt();
        int bottomY = minY.getValueInt();
        int threshold = lightThreshold.getValueInt();
        boolean skipLava = ignoreLava.getValue();

        List<class_2338> candidates = new ArrayList<>();

        for (int chunkX = playerChunk.field_9181 - radius; chunkX <= playerChunk.field_9181 + radius; chunkX++) {
            for (int chunkZ = playerChunk.field_9180 - radius; chunkZ <= playerChunk.field_9180 + radius; chunkZ++) {
                long chunkKey = class_1923.method_8331(chunkX, chunkZ);
                if (scannedChunks.contains(chunkKey))
                    continue;

                class_2818 chunk = world.method_2935().method_21730(chunkX, chunkZ);
                if (chunk == null)
                    continue;

                scannedChunks.add(chunkKey);
                int startWX = chunkX << 4;
                int startWZ = chunkZ << 4;

                for (int x = startWX; x < startWX + 16; x += 2) {
                    for (int z = startWZ; z < startWZ + 16; z += 2) {
                        for (int y = bottomY; y < topY; y += 2) {
                            class_2338 pos = new class_2338(x, y, z);
                            int blockLight = world.method_8314(class_1944.field_9282, pos);
                            if (blockLight < threshold || (skipLava && isLavaNearby(world, pos)))
                                continue;

                            if (world.method_8314(class_1944.field_9284, pos) <= 4)
                                candidates.add(pos);
                        }
                    }
                }
            }
        }

        if (candidates.isEmpty())
            return;

        List<LightCluster> clusters = cluster(candidates);
        for (LightCluster cluster : clusters) {
            if (cluster.lightCount() < minCluster.getValueInt() || alreadyReported(cluster.center()))
                continue;

            foundClusters.add(cluster);

            if (showCoords.getValue() && mc.field_1724 != null) {
                int distance = (int) Math.sqrt(mc.field_1724.method_24515().method_10262(cluster.center()));
                mc.field_1724.method_7353(class_2561.method_43470(String.format(
                        "§6[§eLightFinder§6]§r Possible base: §b%d, %d, %d §7(%d lights, %dm away)",
                        cluster.center().method_10263(), cluster.center().method_10264(), cluster.center().method_10260(),
                        cluster.lightCount(), distance)), false);
            }
        }
    }

    private List<LightCluster> cluster(List<class_2338> positions) {
        List<LightCluster> clusters = new ArrayList<>();
        boolean[] visited = new boolean[positions.size()];
        double maxSquaredDistance = (double) clusterRadius.getValueInt() * clusterRadius.getValueInt();

        for (int i = 0; i < positions.size(); i++) {
            if (visited[i])
                continue;

            List<class_2338> group = new ArrayList<>();
            LinkedList<Integer> queue = new LinkedList<>();
            queue.add(i);
            visited[i] = true;

            while (!queue.isEmpty()) {
                class_2338 current = positions.get(queue.poll());
                group.add(current);

                for (int j = 0; j < positions.size(); j++) {
                    if (!visited[j] && current.method_10262(positions.get(j)) <= maxSquaredDistance) {
                        visited[j] = true;
                        queue.add(j);
                    }
                }
            }

            if (group.size() < 2)
                continue;

            int sumX = 0, sumY = 0, sumZ = 0;
            for (class_2338 pos : group) {
                sumX += pos.method_10263();
                sumY += pos.method_10264();
                sumZ += pos.method_10260();
            }

            clusters.add(new LightCluster(
                    new class_2338(sumX / group.size(), sumY / group.size(), sumZ / group.size()),
                    group.size()));
        }

        return clusters;
    }

    private boolean isLavaNearby(class_638 world, class_2338 pos) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    class_2338 check = pos.method_10069(dx, dy, dz);
                    if (world.method_8320(check).method_27852(class_2246.field_10164))
                        return true;
                }
            }
        }
        return false;
    }

    private boolean alreadyReported(class_2338 center) {
        for (LightCluster cluster : foundClusters) {
            if (cluster.center().method_10262(center) < 256.0D)
                return true;
        }
        return false;
    }

    private void resetState() {
        scannedChunks.clear();
        foundClusters.clear();
        ticksSinceScan = 0;
    }
}