package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.MathUtils;
import xyz.dqrkis.utils.MouseSimulation;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import org.lwjgl.glfw.GLFW;

public final class AutoXP extends Module implements TickListener, ItemUseListener {
	private final NumberSetting delay = new NumberSetting("Delay", 0, 20, 0, 1);
	private final NumberSetting chance = new NumberSetting("Chance", 0, 100, 100, 1)
			.setDescription("Randomization");
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false)
			.setDescription("Makes the CPS hud think you're legit");
	int clock;

	public AutoXP() {
		super("Auto XP",
				"Automatically throws XP bottles for you",
				-1,
				Category.MISC);
		addSettings(delay, chance, clickSimulation);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ItemUseListener.class, this);

		clock = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null)
			return;

		boolean dontThrow = clock != 0;

		int randomInt = MathUtils.randomInt(1, 100);

		if (mc.field_1724.method_6047().method_7909() != class_1802.field_8287)
			return;

		if (GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) != GLFW.GLFW_PRESS)
			return;

		if (dontThrow)
			clock--;

		if (!dontThrow && randomInt <= chance.getValueInt()) {
			if (clickSimulation.getValue())
				MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

			class_1269 result = mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
			if (result.method_23665()) mc.field_1724.method_6104(class_1268.field_5808);

			clock = delay.getValueInt();
		}
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		if (mc.field_1724.method_6047().method_7909() == class_1802.field_8287) {
			event.cancel();
		}
	}

}
