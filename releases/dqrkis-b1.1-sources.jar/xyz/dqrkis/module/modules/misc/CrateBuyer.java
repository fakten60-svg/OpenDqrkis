package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_465;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.utils.ChatUtils;

public final class CrateBuyer extends Module implements TickListener {
	public enum CrateAction {
		All, Helmet, Chestplate, Leggings, Boots, Sword, Pickaxe, Shovel
	}

	private static final int CONFIRM_SLOT = 15;
	private static final int CLICKS_PER_ACTION = 4;

	private final ModeSetting<CrateAction> action = new ModeSetting<>("Action", CrateAction.All, CrateAction.class);

	private int tickCounter;
	private int messageCooldown;
	private int clickPhase;
	private int allModeIndex;
	private boolean validScreenSeen;

	public CrateBuyer() {
		super("Crate Buyer",
				"Automatically buys items from the common crate",
				-1,
				Category.MISC);
		addSettings(action);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		tickCounter = 0;
		messageCooldown = 0;
		clickPhase = 0;
		allModeIndex = 0;
		validScreenSeen = false;
		ChatUtils.info("Activated. Mode: " + action.getMode());
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		clickPhase = 0;
		allModeIndex = 0;
		validScreenSeen = false;
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1761 == null)
			return;

		if (messageCooldown > 0)
			messageCooldown--;

		if (!(mc.field_1755 instanceof class_465<?> screen)) {
			if (validScreenSeen && messageCooldown == 0) {
				ChatUtils.error("You need to be on the crate screen to use this module.");
				messageCooldown = 20;
			}
			return;
		}

		if (!isValidCrateScreen(screen)) {
			if (!validScreenSeen && messageCooldown == 0) {
				ChatUtils.error("This doesn't appear to be a valid crate screen. Closing screen.");
				messageCooldown = 20;
				mc.method_1507(null);
			}
			return;
		}

		validScreenSeen = true;
		tickCounter++;
		if (tickCounter < CLICKS_PER_ACTION)
			return;

		tickCounter = 0;
		if (action.getMode() == CrateAction.All) {
			runTwoPhaseClick(categorySlot(CrateAction.values()[1 + allModeIndex]));
			allModeIndex = (allModeIndex + 1) % 7;
		} else {
			runTwoPhaseClick(categorySlot(action.getMode()));
		}
	}

	private void runTwoPhaseClick(int categorySlot) {
		if (clickPhase == 0) {
			mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, categorySlot, 0, class_1713.field_7790, mc.field_1724);
			clickPhase = 1;
		} else {
			mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, CONFIRM_SLOT, 0, class_1713.field_7790, mc.field_1724);
			clickPhase = 0;
		}
	}

	private boolean isValidCrateScreen(class_465<?> screen) {
		for (int i = 0; i <= 9; i++) {
			if (!screen.method_17577().method_7611(i).method_7677().method_31574(class_1802.field_8871))
				return false;
		}
		for (int i = 17; i <= 26; i++) {
			if (!screen.method_17577().method_7611(i).method_7677().method_31574(class_1802.field_8871))
				return false;
		}
		return true;
	}

	private static int categorySlot(CrateAction crateAction) {
		return switch (crateAction) {
			case Helmet -> 10;
			case Chestplate -> 11;
			case Leggings -> 12;
			case Boots -> 13;
			case Sword -> 14;
			case Pickaxe -> 15;
			case Shovel -> 16;
			default -> 10;
		};
	}
}
