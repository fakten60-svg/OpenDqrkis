package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import xyz.dqrkis.event.events.PacketReceiveListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;

public class PackSpoof extends Module implements PacketReceiveListener {
    public PackSpoof() {
        super("Pack Spoof", "Ignores custom resource packs", -1, Category.MISC);
    }

    @Override
    public void onEnable() {
        eventManager.add(PacketReceiveListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(PacketReceiveListener.class, this);
        super.onDisable();
    }

    @Override
    public void onPacketReceive(PacketReceiveEvent event) {
        if(mc.method_1562() != null) {
            class_2596<?> packet = event.packet;
            if (packet instanceof class_2720) {
                event.cancel();

                mc.method_1562().method_52787(new class_2856(mc.field_1724.method_5667(), class_2856.class_2857.field_13016));
                mc.method_1562().method_52787(new class_2856(mc.field_1724.method_5667(), class_2856.class_2857.field_13017));
            }
        }
    }
}
