package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_639;
import net.minecraft.class_642;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;

public final class AutoReconnect extends Module {
	private final NumberSetting delay = new NumberSetting("Delay", 0, 60, 3.5, 0.1)
			.setDescription("Seconds to wait before reconnecting");
	private final BooleanSetting hideButtons = new BooleanSetting("Hide Buttons", false)
			.setDescription("Hides the reconnect buttons on the disconnect screen");

	public class_639 serverAddress;
	public class_642 serverInfo;

	public AutoReconnect() {
		super("Auto Reconnect",
				"Automatically reconnects when disconnected from a server",
				-1,
				Category.MISC);
		addSettings(delay, hideButtons);
	}

	public void recordConnection(class_639 address, class_642 info) {
		this.serverAddress = address;
		this.serverInfo = info;
	}

	public boolean hasServer() {
		return serverAddress != null;
	}

	public double getDelaySeconds() {
		return delay.getValue();
	}

	public boolean shouldHideButtons() {
		return hideButtons.getValue();
	}
}
