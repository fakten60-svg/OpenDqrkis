package xyz.dqrkis.module.modules.misc;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;

public final class Sprint extends Module implements TickListener {
    public Sprint() {
        super("Sprint", "Keeps you sprinting at all times", -1, Category.MISC);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        mc.field_1724.method_5728(mc.field_1724.field_3913.method_20622());
    }
}
