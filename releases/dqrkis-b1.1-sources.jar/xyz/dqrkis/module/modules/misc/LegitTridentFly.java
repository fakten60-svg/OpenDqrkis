package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.ClientPlayerInteractionManagerAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.utils.ChatUtils;

public final class LegitTridentFly extends Module implements TickListener {
	private boolean pressingUse;
	private boolean waitingForRelease;
	private int releaseDelay;
	private int savedSlot = -1;
	private long lastNanoTime;

	public LegitTridentFly() {
		super("Legit Trident Fly",
				"Undetectable Trident Fly. Requires Rain, RipTide",
				-1,
				Category.MISC);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		pressingUse = false;
		waitingForRelease = false;
		releaseDelay = -1;
		savedSlot = -1;

		if (mc.field_1724 != null && !findRiptideTrident()) {
			ChatUtils.error("No riptide trident found in hotbar!");
			setEnabled(false);
			return;
		}

		lastNanoTime = System.nanoTime();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);

		if (mc.field_1690.field_1904.method_1434())
			mc.field_1690.field_1904.method_23481(false);

		if (savedSlot != -1 && mc.field_1724 != null) {
			mc.field_1724.method_31548().method_61496(savedSlot);
			((ClientPlayerInteractionManagerAccessor) mc.field_1761).syncSlot();
			savedSlot = -1;
		}
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null)
			return;

		long now = System.nanoTime();
		float delta = (float) (now - lastNanoTime) / 1.0E9F;
		lastNanoTime = now;

		if (mc.field_1687.method_8430(delta) == 0.0F) {
			ChatUtils.error("It needs to be raining to use this!");
			setEnabled(false);
			return;
		}

		class_1799 mainHand = mc.field_1724.method_6047();
		if (!hasRiptide(mainHand)) {
			if (!findRiptideTrident()) {
				ChatUtils.error("No riptide trident found in hotbar!");
				setEnabled(false);
				return;
			}
			mainHand = mc.field_1724.method_6047();
		}

		if (mainHand.method_7963()) {
			int maxDamage = mainHand.method_7936();
			int remaining = maxDamage - mainHand.method_7919();
			double durabilityPercent = (double) remaining / maxDamage * 100.0D;
			if (durabilityPercent <= 20.0D) {
				ChatUtils.error("Trident durability too low!");
				setEnabled(false);
				return;
			}
		}

		if (waitingForRelease) {
			releaseDelay++;
			if (releaseDelay >= 1) {
				waitingForRelease = false;
				pressingUse = true;
				mc.field_1690.field_1904.method_23481(true);
			}
		} else if (pressingUse) {
			int useTicksTotal = mainHand.method_7935(mc.field_1724);
			int useTicksLeft = mc.field_1724.method_6014();
			int elapsed = useTicksTotal - useTicksLeft;

			if (mc.field_1724.method_6115() && elapsed >= 10) {
				mc.field_1690.field_1904.method_23481(false);
				pressingUse = false;
				waitingForRelease = true;
				releaseDelay = 0;
			} else if (!mc.field_1724.method_6115()) {
				mc.field_1690.field_1904.method_23481(true);
			}
		} else {
			pressingUse = true;
			mc.field_1690.field_1904.method_23481(true);
		}
	}

	private boolean findRiptideTrident() {
		if (mc.field_1724 == null)
			return false;

		if (savedSlot == -1)
			savedSlot = mc.field_1724.method_31548().method_67532();

		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (stack.method_31574(class_1802.field_8547) && hasRiptide(stack)) {
				mc.field_1724.method_31548().method_61496(i);
				((ClientPlayerInteractionManagerAccessor) mc.field_1761).syncSlot();
				return true;
			}
		}
		return false;
	}

	private boolean hasRiptide(class_1799 stack) {
		return xyz.dqrkis.utils.ItemUtils.hasEnchant(stack, "riptide");
	}
}
