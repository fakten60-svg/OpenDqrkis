package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_476;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.ChatUtils;

public final class AhSell extends Module implements TickListener {
	private static final int CONFIRM_SLOT = 15;
	private static final int GUI_TIMEOUT_TICKS = 10;
	private static final int CONFIRM_DELAY_TICKS = 2;

	private final StringSetting sellPrice = new StringSetting("Sell Price", "15000".toString());
	private final NumberSetting delay = new NumberSetting("Delay (ticks)", 5, 100, 20, 1);

	private int delayTicks;
	private State state = State.IDLE;
	private int stateTicks;

	private enum State { IDLE, WAITING_FOR_GUI, CLICKING_CONFIRM }

	public AhSell() {
		super("Ah Sell",
				"Automatically sells items from your hotbar.",
				-1,
				Category.MISC);
		addSettings(sellPrice, delay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetToIdle();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		resetToIdle();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null)
			return;

		if (delayTicks > 0) {
			delayTicks--;
			return;
		}

		switch (state) {
			case IDLE -> tryStartSale();
			case WAITING_FOR_GUI -> {
				stateTicks--;
				if (mc.field_1755 instanceof class_476) {
					state = State.CLICKING_CONFIRM;
					stateTicks = CONFIRM_DELAY_TICKS;
				} else if (stateTicks <= 0) {
					resetToIdle();
				}
			}
			case CLICKING_CONFIRM -> {
				stateTicks--;
				if (stateTicks <= 0) {
					if (mc.field_1755 instanceof class_476) {
						mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, CONFIRM_SLOT, 0, class_1713.field_7790, mc.field_1724);
						mc.field_1724.method_7346();
					}
					resetToIdle();
				}
			}
		}
	}

	private void tryStartSale() {
		int slot = -1;
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (!stack.method_7960()) {
				slot = i;
				break;
			}
		}

		if (slot == -1) {
			ChatUtils.info("Hotbar is empty. Disabling.");
			setEnabled(false);
			return;
		}

		try {
			Integer.parseInt(sellPrice.getValue());
		} catch (NumberFormatException e) {
			ChatUtils.error("Invalid sell price. Disabling.");
			setEnabled(false);
			return;
		}

		InventoryUtils_setSelectedSlot(slot);
		mc.field_1724.field_3944.method_45730("ah sell " + sellPrice.getValue());
		state = State.WAITING_FOR_GUI;
		stateTicks = GUI_TIMEOUT_TICKS;
	}

	private void InventoryUtils_setSelectedSlot(int slot) {
		mc.field_1724.method_31548().method_61496(slot);
		((xyz.dqrkis.mixin.ClientPlayerInteractionManagerAccessor) mc.field_1761).syncSlot();
	}

	private void resetToIdle() {
		state = State.IDLE;
		delayTicks = delay.getValueInt();
		stateTicks = 0;
	}
}
