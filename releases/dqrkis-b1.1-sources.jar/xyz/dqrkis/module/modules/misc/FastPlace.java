package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1747;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.MinecraftClientAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;

public final class FastPlace extends Module implements TickListener {
	private final NumberSetting delay = new NumberSetting("Delay", 0, 4, 0, 1)
			.setDescription("Ticks between placements");

	private int placeIn;

	public FastPlace() {
		super("Fast Place",
				"Removes the delay when holding right click with blocks",
				-1,
				Category.MISC);
		addSettings(delay);
	}

	@Override
	public void onEnable() {
		placeIn = 0;
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1761 == null)
			return;

		if (!(mc.field_1724.method_6047().method_7909() instanceof class_1747))
			return;

		if (!mc.field_1690.field_1904.method_1434())
			return;

		if (placeIn > 0) {
			placeIn--;
			return;
		}

		((MinecraftClientAccessor) mc).setItemUseCooldown(0);
		placeIn = delay.getValueInt();
	}
}
