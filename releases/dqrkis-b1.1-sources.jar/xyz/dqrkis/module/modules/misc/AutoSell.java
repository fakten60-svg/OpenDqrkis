package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_476;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.ChatUtils;

public final class AutoSell extends Module implements TickListener {
	private enum State { IDLE, OPENING_GUI, DEPOSITING, CLOSING }

	private final NumberSetting clickDelay = new NumberSetting("Click Delay (ticks)", 1, 10, 2, 1);

	private State state = State.IDLE;
	private int searchStartSlot;
	private int timeoutTicks;
	private int delayTicks;

	public AutoSell() {
		super("Auto Sell",
				"Automatically sells all items in your inventory.",
				-1,
				Category.MISC);
		addSettings(clickDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);

		if (mc.field_1724 != null && mc.field_1687 != null) {
			state = State.OPENING_GUI;
			mc.field_1724.field_3944.method_45730("sell");
			timeoutTicks = 40;
		} else {
			disable();
		}
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		resetState();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1761 == null) {
			mc.execute(this::disable);
			return;
		}

		if (delayTicks > 0) {
			delayTicks--;
			return;
		}

		switch (state) {
			case OPENING_GUI -> {
				if (mc.field_1755 instanceof class_476) {
					state = State.DEPOSITING;
					searchStartSlot = mc.field_1724.field_7498.field_7761.size() - 36;
				} else if (--timeoutTicks <= 0) {
					ChatUtils.error("Timed out waiting for sell GUI.");
					mc.execute(this::disable);
				}
			}
			case DEPOSITING -> {
				if (!(mc.field_1755 instanceof class_476)) {
					ChatUtils.error("Sell GUI closed unexpectedly.");
					mc.execute(this::disable);
					return;
				}

				int slot = -1;
				for (int i = searchStartSlot; i < mc.field_1724.field_7498.field_7761.size(); i++) {
					if (mc.field_1724.field_7498.method_7611(i).field_7871 == mc.field_1724.method_31548()) {
						class_1799 stack = mc.field_1724.field_7498.method_7611(i).method_7677();
						if (!stack.method_7960()) {
							slot = i;
							break;
						}
					}
				}

				if (slot != -1) {
					final int syncId = mc.field_1724.field_7498.field_7763;
					final int targetSlot = slot;
					mc.execute(() -> mc.field_1761.method_2906(syncId, targetSlot, 0, class_1713.field_7794, mc.field_1724));
					searchStartSlot = slot + 1;
					delayTicks = clickDelay.getValueInt();
				} else {
					state = State.CLOSING;
				}
			}
			case CLOSING -> {
				mc.execute(() -> {
					if (mc.field_1755 != null && mc.field_1724 != null)
						mc.field_1724.method_7346();
					ChatUtils.info("Finished selling items.");
					disable();
				});
				state = State.IDLE;
			}
			case IDLE -> {}
		}
	}

	private void disable() {
		setEnabled(false);
	}

	private void resetState() {
		state = State.IDLE;
		searchStartSlot = 0;
		timeoutTicks = 0;
		delayTicks = 0;
	}
}
