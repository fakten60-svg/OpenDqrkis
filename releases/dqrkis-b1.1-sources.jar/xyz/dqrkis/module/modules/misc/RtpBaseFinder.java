package xyz.dqrkis.module.modules.misc;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2636;
import net.minecraft.class_2661;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.utils.WorldUtils;

public final class RtpBaseFinder extends Module implements TickListener {
	public enum Region { Random, East, West, EuWest, EuCentral, Asia, Oceania }

	private static final float TARGET_PITCH = 85.45357F;
	private static final long STABILIZE_MS = 2500L;
	private static final float ROTATE_SPEED = 4.0F;

	private final ModeSetting<Region> region = new ModeSetting<>("Region", Region.Random, Region.class);

	private long worldReadyTime = -1L;
	private boolean waitingForWorld = true;
	private boolean rotating;
	private boolean sentRtpThisDescent;

	private boolean spawnerFound;
	private int chests;

	public RtpBaseFinder() {
		super("RTP Base Finder",
				"Finds bases by digging down",
				-1,
				Category.MISC);
		addSettings(region);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);

		if (mc.field_1755 != null)
			mc.field_1755.method_25419();

		worldReadyTime = -1L;
		waitingForWorld = true;
		rotating = false;
		sentRtpThisDescent = false;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		releaseDigKeys();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1761 == null)
			return;

		if (mc.field_1687 == null) {
			worldReadyTime = -1L;
			waitingForWorld = true;
			return;
		}

		if (worldReadyTime == -1L)
			worldReadyTime = System.currentTimeMillis();

		if (!offhandHasTotem()) {
			disconnectWithReason("Totem Popped");
			return;
		}

		scanLoadedChunks();

		float pitch = mc.field_1724.method_36455();

		if ((int) pitch == 85) {
			rotating = false;
			digOrRequestRtp();
		} else if (!rotating && stabilizedLongEnough()) {
			rotating = true;
		} else if (rotating) {
			rotateTowardsTarget();
		}
	}

	private boolean stabilizedLongEnough() {
		if (mc.field_1687 == null || worldReadyTime == -1L)
			return false;
		return System.currentTimeMillis() - worldReadyTime >= STABILIZE_MS;
	}

	private void rotateTowardsTarget() {
		float currentPitch = mc.field_1724.method_36455();
		float diff = TARGET_PITCH - currentPitch;
		if (Math.abs(diff) <= ROTATE_SPEED) {
			mc.field_1724.method_36457(TARGET_PITCH);
		} else {
			mc.field_1724.method_36457(currentPitch + Math.signum(diff) * ROTATE_SPEED);
		}
	}

	private void digOrRequestRtp() {
		if (mc.field_1724.method_23318() > 0.0D) {
			mc.field_1690.field_1886.method_23481(true);
			mc.field_1690.field_1832.method_23481(true);
		} else {
			releaseDigKeys();

			if (!sentRtpThisDescent) {
				sendRtpCommand();
				sentRtpThisDescent = true;
				worldReadyTime = System.currentTimeMillis();
			}
		}
	}

	private void releaseDigKeys() {
		mc.field_1690.field_1886.method_23481(false);
		mc.field_1690.field_1832.method_23481(false);
	}

	private void sendRtpCommand() {
		switch (region.getMode()) {
			case East -> mc.method_1562().method_45730("rtp east");
			case West -> mc.method_1562().method_45730("rtp west");
			case EuWest -> mc.method_1562().method_45730("rtp eu west");
			case EuCentral -> mc.method_1562().method_45730("rtp eu central");
			case Asia -> mc.method_1562().method_45730("rtp asia");
			case Oceania -> mc.method_1562().method_45730("rtp oceania");
			case Random -> mc.method_1562().method_45730(switch ((int) (Math.random() * 6)) {
				case 0 -> "rtp east";
				case 1 -> "rtp west";
				case 2 -> "rtp eu west";
				case 3 -> "rtp eu central";
				case 4 -> "rtp asia";
				default -> "rtp oceania";
			});
		}
	}

	private void scanLoadedChunks() {
		chests = 0;
		int hoppers = 0;
		int dispensers = 0;
		int enderChests = 0;
		int shulkers = 0;
		spawnerFound = false;

		for (var chunk : WorldUtils.getLoadedChunks().toList()) {
			for (class_2338 pos : chunk.method_12021()) {
				class_2586 blockEntity = mc.field_1687.method_8321(pos);
				if (blockEntity == null)
					continue;

				if (blockEntity instanceof class_2636)
					spawnerFound = true;

				if (blockEntity.method_11016().method_10264() > 0)
					continue;

				if (blockEntity instanceof class_2595) chests++;
				else if (blockEntity instanceof class_2614) hoppers++;
				else if (blockEntity instanceof class_2601) dispensers++;
				else if (blockEntity instanceof class_2611) enderChests++;
				else if (blockEntity instanceof class_2627) shulkers++;
			}
		}

		if (chests >= 20)
			disconnectWithReason("Chest threshold reached");
		else if (shulkers >= 20)
			disconnectWithReason("Shulker threshold reached");
		else if (spawnerFound)
			disconnectWithReason("Spawner found");
	}

	private boolean offhandHasTotem() {
		if (mc.field_1724 == null)
			return false;

		class_1799 offHand = mc.field_1724.method_6079();
		return offHand.method_7909() == class_1802.field_8288;
	}

	private void disconnectWithReason(String reason) {
		if (mc.field_1687 == null || worldReadyTime == -1L)
			return;

		if (System.currentTimeMillis() - worldReadyTime < STABILIZE_MS)
			return;

		setEnabled(false);
		if (mc.field_1724 != null && mc.field_1724.field_3944 != null)
			mc.field_1724.field_3944.method_52781(new class_2661(class_2561.method_43470("RTPBaseFinder | " + reason)));
	}
}
