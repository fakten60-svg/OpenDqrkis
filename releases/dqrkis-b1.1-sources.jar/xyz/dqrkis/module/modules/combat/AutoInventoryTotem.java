package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_490;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.FakeInvScreen;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.TimerUtils;


public final class AutoInventoryTotem extends Module implements TickListener {
	public enum Mode {
		Blatant, Random
	}

	private final ModeSetting<Mode> mode = new ModeSetting<>("Mode", Mode.Blatant, Mode.class)
			.setDescription("Whether to randomize the toteming pattern or no");
	private final NumberSetting delay = new NumberSetting("Delay", 0, 20, 0, 1);
	private final BooleanSetting hotbar = new BooleanSetting("Hotbar", true).setDescription("Puts a totem in your hotbar as well, if enabled (Setting below will work if this is enabled)");
	private final NumberSetting totemSlot = new NumberSetting("Totem Slot", 1, 9, 1, 1)
			.setDescription("Your preferred totem slot");
	private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", false)
			.setDescription("Switches to totem slot when going inside the inventory");
	private final BooleanSetting forceTotem = new BooleanSetting("Force Totem", false).setDescription("Puts the totem in the slot, regardless if its space is taken up by something else");
	private final BooleanSetting autoOpen = new BooleanSetting("Auto Open", false)
			.setDescription("Automatically opens and closes the inventory for you");
	private final NumberSetting stayOpenFor = new NumberSetting("Stay Open For", 0, 20, 0, 1);

	int clock = -1;
	int closeClock = -1;

	TimerUtils openTimer = new TimerUtils();
	TimerUtils closeTimer = new TimerUtils();

	public AutoInventoryTotem() {
		super("Auto Inventory Totem",
				"Automatically equips a totem in your offhand and main hand if empty",
				-1,
				Category.COMBAT);
		addSettings(mode, delay, hotbar, totemSlot, autoSwitch, forceTotem, autoOpen, stayOpenFor);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		clock = -1;
		closeClock = -1;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (shouldOpenScreen() && autoOpen.getValue())
			mc.method_1507(new FakeInvScreen(mc.field_1724));

		if (!(mc.field_1755 instanceof class_490 || mc.field_1755 instanceof FakeInvScreen)) {
			clock = -1;
			closeClock = -1;
			return;
		}

		if (clock == -1)
			clock = delay.getValueInt();

		if (closeClock == -1)
			closeClock = stayOpenFor.getValueInt();

		if (clock > 0)
			clock--;

		class_1661 inventory = mc.field_1724.method_31548();

		if (autoSwitch.getValue())
			inventory.method_61496(totemSlot.getValueInt() - 1);

		if (clock <= 0) {
			if (mc.field_1724.method_6079().method_7909() != class_1802.field_8288) {
				int slot = mode.isMode(Mode.Blatant) ? InventoryUtils.findTotemSlot() : InventoryUtils.findRandomTotemSlot();

				if (slot != -1) {
					mc.field_1761.method_2906(((class_490) mc.field_1755).method_17577().field_7763, slot, 40, class_1713.field_7791, mc.field_1724);
					return;
				}
			}

			if(hotbar.getValue()) {
				class_1799 mainHand = mc.field_1724.method_6047();
				if (mainHand.method_7960() || forceTotem.getValue() && mainHand.method_7909() != class_1802.field_8288) {
					int slot = mode.isMode(Mode.Blatant) ? InventoryUtils.findTotemSlot() : InventoryUtils.findRandomTotemSlot();

					if (slot != -1) {
						mc.field_1761.method_2906(((class_490) mc.field_1755).method_17577().field_7763, slot, inventory.method_67532(), class_1713.field_7791, mc.field_1724);
						return;
					}
				}
			}


			if (shouldCloseScreen() && autoOpen.getValue()) {
				if (closeClock != 0) {
					closeClock--;
					return;
				}

				mc.field_1755.method_25419();
				closeClock = stayOpenFor.getValueInt();
			}
		}
	}

	public boolean shouldCloseScreen() {
		if(hotbar.getValue())
			return (mc.field_1724.method_31548().method_5438(totemSlot.getValueInt() - 1).method_7909() == class_1802.field_8288 && mc.field_1724.method_6079().method_7909() == class_1802.field_8288) && mc.field_1755 instanceof FakeInvScreen;
		else return ( mc.field_1724.method_6079().method_7909() == class_1802.field_8288) && mc.field_1755 instanceof FakeInvScreen;
	}

	public boolean shouldOpenScreen() {
		if(hotbar.getValue())
			return (mc.field_1724.method_6079().method_7909() != class_1802.field_8288 || mc.field_1724.method_31548().method_5438(totemSlot.getValueInt() - 1).method_7909() != class_1802.field_8288)
					&& !(mc.field_1755 instanceof FakeInvScreen) && InventoryUtils.countItemExceptHotbar(item -> item == class_1802.field_8288) != 0;
		else return (mc.field_1724.method_6079().method_7909() != class_1802.field_8288 && !(mc.field_1755 instanceof FakeInvScreen) && InventoryUtils.countItemExceptHotbar(item -> item == class_1802.field_8288) != 0);
	}
}
