package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.ItemUtils;
import xyz.dqrkis.utils.WorldUtils;

public final class StunSlam extends Module implements TickListener {
	private enum WeaponMode { Mace, Density, Breach }

	private final NumberSetting minFallDistance = new NumberSetting("Min Fall Distance", 0, 10, 1.5, 0.1)
			.setDescription("Only strikes after falling this far");
	private final ModeSetting<WeaponMode> weapon = new ModeSetting<>("Weapon", WeaponMode.Mace, WeaponMode.class)
			.setDescription("Which mace variant to swap to");
	private final NumberSetting cooldown = new NumberSetting("Cooldown", 0, 20, 0, 1)
			.setDescription("Ticks to wait between combos");

	private enum State { IDLE, AXE_SWAPPED, MACE_SWAPPED }

	private int cooldownTicks;
	private State state = State.IDLE;
	private class_1657 target;

	public StunSlam() {
		super("Stun Slam",
				"Stuns your enemy with an axe then slams with a mace",
				-1,
				Category.COMBAT);
		addSettings(minFallDistance, weapon, cooldown);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		state = State.IDLE;
		target = null;
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null)
			return;

		if (state == State.AXE_SWAPPED && target != null) {
			attack(target);

			int maceSlot = findMaceSlot();
			if (maceSlot != -1) {
				InventoryUtils.setInvSlot(maceSlot);
				state = State.MACE_SWAPPED;
			} else {
				startCooldown();
			}
		} else if (state == State.MACE_SWAPPED && target != null) {
			attack(target);
			startCooldown();
		} else if (cooldownTicks > 0) {
			cooldownTicks--;
		} else {
			class_1657 player = WorldUtils.findNearestPlayer(mc.field_1724, 4.5F, true, false);
			if (player == null)
				return;

			if (mc.field_1724.field_6017 < minFallDistance.getValueFloat())
				return;

			if (player.method_6039()) {
				int axeSlot = findAxeSlot();
				if (axeSlot != -1) {
					InventoryUtils.setInvSlot(axeSlot);
					state = State.AXE_SWAPPED;
					target = player;
					return;
				}
			}

			int maceSlot = findMaceSlot();
			if (maceSlot != -1) {
				InventoryUtils.setInvSlot(maceSlot);
				state = State.MACE_SWAPPED;
				target = player;
			}
		}
	}

	private void attack(class_1657 player) {
		if (!player.method_5805() || mc.field_1724.method_5858(player) >= 20.25D)
			return;

		mc.field_1761.method_2918(mc.field_1724, player);
		mc.field_1724.method_6104(class_1268.field_5808);
	}

	private void startCooldown() {
		state = State.IDLE;
		target = null;
		cooldownTicks = cooldown.getValueInt();
	}

	private void resetState() {
		cooldownTicks = 0;
		state = State.IDLE;
		target = null;
	}

	private int findAxeSlot() {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (WorldUtils.isAxe(stack))
				return i;
		}
		return -1;
	}

	private int findMaceSlot() {
		WeaponMode mode = weapon.getMode();

		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (!stack.method_31574(class_1802.field_49814))
				continue;

			if (mode == WeaponMode.Density && !ItemUtils.hasEnchant(stack, "density"))
				continue;
			if (mode == WeaponMode.Breach && !ItemUtils.hasEnchant(stack, "breach"))
				continue;

			return i;
		}

		return mode == WeaponMode.Mace ? -1 : findAnyMaceSlot();
	}

	private int findAnyMaceSlot() {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (ItemUtils.isMace(stack))
				return i;
		}
		return -1;
	}
}
