package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.MathUtils;

public final class AutoJumpReset extends Module implements TickListener {
	private final NumberSetting chance = new NumberSetting("Chance", 0, 100, 100, 1);

	public AutoJumpReset() {
		super("Auto Jump Reset",
				"Automatically jumps for you when you get hit so you take less knockback (not good for crystal pvp)",
				-1,
				Category.COMBAT);
		addSettings(chance);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if(MathUtils.randomInt(1, 100) <= chance.getValueInt()) {
			if (mc.field_1755 != null)
				return;

			if (mc.field_1724.method_6115())
				return;

			if (mc.field_1724.field_6235 == 0)
				return;

			if (mc.field_1724.field_6235 == mc.field_1724.field_6254)
				return;

			if (!mc.field_1724.method_24828())
				return;

			if (mc.field_1724.field_6235 == 9 && MathUtils.randomInt(1, 100) <= chance.getValueInt())
				mc.field_1724.method_6043();
		}
	}
}
