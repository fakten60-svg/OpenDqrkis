package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_3489;
import net.minecraft.class_3966;
import net.minecraft.class_9362;
import xyz.dqrkis.event.events.ShieldDisabledListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.ItemUtils;

public final class TotemPopHit extends Module implements TickListener, ShieldDisabledListener {
	private final BooleanSetting swapToSword = new BooleanSetting("Swap To Sword", true)
			.setDescription("Swaps to a sword when the shield gets disabled");
	private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true)
			.setDescription("Switches back to your previous slot");
	private final NumberSetting switchBackDelay = new NumberSetting("Switch Back Delay", 0, 5, 1, 1);

	private boolean swapped;
	private int previousSlot = -1;
	private int switchClock;

	public TotemPopHit() {
		super("Totem Pop Hit",
				"Attacks instantly when enemy pops a totem",
				-1,
				Category.COMBAT);
		addSettings(swapToSword, switchBack, switchBackDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ShieldDisabledListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ShieldDisabledListener.class, this);
		if (swapped && previousSlot != -1 && mc.field_1724 != null)
			InventoryUtils.setInvSlot(previousSlot);
		resetState();
		super.onDisable();
	}

	@Override
	public void onShieldDisabled() {
		if (mc.field_1724 == null || swapped)
			return;

		if (!(mc.field_1765 instanceof class_3966 hit) || hit.method_17782() == null)
			return;

		if (isGoodWeapon(mc.field_1724.method_6047().method_7909()))
			return;

		if (!swapToSword.getValue())
			return;

		int slot = findSwordSlot();
		if (slot == -1)
			return;

		if (switchBack.getValue() && previousSlot == -1)
			previousSlot = mc.field_1724.method_31548().method_67532();

		InventoryUtils.setInvSlot(slot);

		if (switchBack.getValue()) {
			swapped = true;
			switchClock = 0;
		}
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null)
			return;

		if (!swapped || previousSlot == -1)
			return;

		if (switchClock < switchBackDelay.getValueInt()) {
			switchClock++;
			return;
		}

		InventoryUtils.setInvSlot(previousSlot);
		resetState();
	}

	private boolean isGoodWeapon(net.minecraft.class_1792 item) {
		return item instanceof class_1835 || item instanceof class_9362
				|| new class_1799(item).method_31573(class_3489.field_42611) || new class_1799(item).method_31573(class_3489.field_42612);
	}

	private int findSwordSlot() {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (stack.method_31573(class_3489.field_42611))
				return i;
		}
		return -1;
	}

	private void resetState() {
		swapped = false;
		previousSlot = -1;
		switchClock = 0;
	}
}
