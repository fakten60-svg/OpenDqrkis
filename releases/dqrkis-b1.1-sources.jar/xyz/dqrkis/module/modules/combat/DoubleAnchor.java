package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.BlockUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public final class DoubleAnchor extends Module implements TickListener {
	public DoubleAnchor() {
		super("Double Anchor",
				"Helps you do the air place/double anchor",
				-1,
				Category.COMBAT);
	}

	private class_2338 pos;
	private int count;

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		pos = null;
		count = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 == null) {
			assert mc.field_1724 != null;
			if (mc.field_1724.method_6047().method_31574(class_1802.field_23141)) {
				assert mc.field_1687 != null;
				if (mc.field_1765 instanceof class_3965 h && BlockUtils.isAnchorCharged(h.method_17777())) {
					if (GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
						if (h.method_17777().equals(pos)) {
							if (count >= 1) return;
						} else {
							pos = h.method_17777();
							count = 0;
						}

						mc.method_1562().method_52787(new class_2885(class_1268.field_5808, h, 0));
						count++;
					}
				}
			}
		}
	}
}
