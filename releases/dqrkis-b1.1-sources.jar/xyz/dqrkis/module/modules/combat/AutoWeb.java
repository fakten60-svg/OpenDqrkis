package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;

public final class AutoWeb extends Module implements TickListener {
	private final NumberSetting delay = new NumberSetting("Delay", 0, 20, 2, 1)
			.setDescription("Ticks between web placements");
	private final BooleanSetting onlyHoldingWebs = new BooleanSetting("Only Holding Webs", true)
			.setDescription("Only places webs while holding cobwebs");

	private int placeIn;

	public AutoWeb() {
		super("Auto Web",
				"Places webs at enemies feet automatically",
				-1,
				Category.COMBAT);
		addSettings(delay, onlyHoldingWebs);
	}

	@Override
	public void onEnable() {
		placeIn = 0;
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null)
			return;

		if (placeIn > 0) {
			placeIn--;
			return;
		}

		if (onlyHoldingWebs.getValue() && !mc.field_1724.method_6047().method_31574(class_1802.field_8786))
			return;

		class_2338 pos = mc.field_1724.method_24515().method_10074();
		if (!mc.field_1687.method_8320(pos).method_26215())
			return;

		class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
		mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
		mc.field_1724.method_6104(class_1268.field_5808);
		placeIn = delay.getValueInt();
	}
}
