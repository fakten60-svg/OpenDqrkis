package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_490;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.HandledScreenMixin;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;

public final class HoverTotem extends Module implements TickListener {
	private final NumberSetting delay = new NumberSetting("Delay", 0, 20, 0, 1);
	private final BooleanSetting hotbar = new BooleanSetting("Hotbar", true).setDescription("Puts a totem in your hotbar as well, if enabled (Setting below will work if this is enabled)");
	private final NumberSetting slot = new NumberSetting("Totem Slot", 1, 9, 1, 1)
			.setDescription("Your preferred totem slot");
	private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch", false)
			.setDescription("Switches to totem slot when going inside the inventory");

	private int clock;

	public HoverTotem() {
		super("Hover Totem",
				"Equips a totem in your totem and offhand slots if a totem is hovered",
				-1,
				Category.COMBAT);
		addSettings(delay, hotbar, slot, autoSwitch);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		clock = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 instanceof class_490 inv) {
			class_1735 hoveredSlot = ((HandledScreenMixin) inv).getFocusedSlot();

			if (autoSwitch.getValue())
				mc.field_1724.method_31548().method_61496(slot.getValueInt() - 1);

			if (hoveredSlot != null) {
				int slot = hoveredSlot.method_34266();

				if (slot > 35)
					return;

				int totem = this.slot.getValueInt() - 1;

				if (hoveredSlot.method_7677().method_7909() == class_1802.field_8288) {
					if (hotbar.getValue() && mc.field_1724.method_31548().method_5438(totem).method_7909() != class_1802.field_8288) {
						if (clock > 0) {
							clock--;
							return;
						}

						mc.field_1761.method_2906(inv.method_17577().field_7763, slot, totem, class_1713.field_7791, mc.field_1724);
						clock = delay.getValueInt();
					} else if (!mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
						if (clock > 0) {
							clock--;
							return;
						}

						mc.field_1761.method_2906(inv.method_17577().field_7763, slot, 40, class_1713.field_7791, mc.field_1724);
						clock = delay.getValueInt();
					}
				}
			}
		} else clock = delay.getValueInt();
	}
}
