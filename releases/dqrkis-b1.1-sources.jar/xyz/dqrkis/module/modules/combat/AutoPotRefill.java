package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1294;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_490;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.HandledScreenMixin;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;

public final class AutoPotRefill extends Module implements TickListener {
	public enum Mode {
		Auto, Hover
	}

	private final ModeSetting<Mode> mode = new ModeSetting<>("Mode", Mode.Auto, Mode.class);
	private final NumberSetting delay = new NumberSetting("Delay", 0, 10, 0, 1);

	private int clock;

	public AutoPotRefill() {
		super("Auto Pot Refill",
				"Refills your hotbar with potions",
				-1,
				Category.COMBAT);
		addSettings(mode, delay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);

		clock = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 instanceof class_490 inventoryScreen) {
			if (mode.isMode(Mode.Hover)) {
				class_1735 focusedSlot = ((HandledScreenMixin) inventoryScreen).getFocusedSlot();

				if (focusedSlot == null)
					return;

				class_1661 inventory = mc.field_1724.method_31548();

				int emptySlot = -1;
				for (int i = 0; i <= 8; i++) {
					if (inventory.method_5438(i).method_7960()) {
						emptySlot = i;
						break;
					}
				}

				if (emptySlot == -1)
					return;

				if (InventoryUtils.isThatSplash(class_1294.field_5915.comp_349(), 1, 1, focusedSlot.method_7677())) {
					if (clock < delay.getValueInt()) {
						clock++;
						return;
					}

					mc.field_1761.method_2906(
							inventoryScreen.method_17577().field_7763,
							focusedSlot.method_34266(),
							emptySlot,
							class_1713.field_7791,
							mc.field_1724);

					clock = 0;
				}
			}

			if (mode.isMode(Mode.Auto)) {
				int slot = InventoryUtils.findPot(class_1294.field_5915.comp_349(), 1, 1);

				if (slot != -1) {
					class_1661 inventory = mc.field_1724.method_31548();

					int emptySlot = -1;
					for (int i = 0; i <= 8; i++) {
						if (inventory.method_5438(i).method_7960()) {
							emptySlot = i;
							break;
						}
					}

					if (emptySlot == -1) return;

					if (clock < delay.getValueInt()) {
						clock++;
						return;
					}

					mc.field_1761.method_2906(
							inventoryScreen.method_17577().field_7763,
							slot,
							emptySlot,
							class_1713.field_7791,
							mc.field_1724);

					clock = 0;
				}
			}
		}
	}
}
