package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.MinecraftClientAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.BlockUtils;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.KeyUtils;
import xyz.dqrkis.utils.MouseSimulation;
import xyz.dqrkis.utils.WorldUtils;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1621;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public final class AutoDTap extends Module implements TickListener, ItemUseListener {
	private final KeybindSetting macroKey = new KeybindSetting("Macro Key", GLFW.GLFW_MOUSE_BUTTON_LEFT, false)
			.setDescription("Hold this button to run the macro");
	private final NumberSetting placeDelay = new NumberSetting("Place Delay", 0, 20, 3, 1);
	private final NumberSetting breakDelay = new NumberSetting("Break Delay", 0, 20, 3, 1);
	private final NumberSetting placeChance = new NumberSetting("Place Chance %", 0, 100, 100, 1);
	private final NumberSetting attackChance = new NumberSetting("Attack Chance %", 0, 100, 100, 1);
	private final BooleanSetting antiWeakness = new BooleanSetting("Anti Weakness", false)
			.setDescription("Pauses while weak and an enemy recently died nearby");
	private final BooleanSetting allEntities = new BooleanSetting("All Entities", false)
			.setDescription("Attacks any entity in the crosshair, not just crystals and slimes");
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false);
	private final BooleanSetting breakBlocks = new BooleanSetting("Break Blocks", false)
			.setDescription("Mines the block you are pointing at");
	private final BooleanSetting swapForWeakness = new BooleanSetting("Swap For Weakness", false)
			.setDescription("Swaps to a sword while attacking while weak");
	private final NumberSetting attackWindow = new NumberSetting("Attack Window", 0, 100, 20, 1)
			.setDescription("Ticks a position stays limited after two placements");
	private final NumberSetting placeLimitDelay = new NumberSetting("Place Limit Delay", 0, 100, 10, 1)
			.setDescription("Extra delay once a position reaches its place limit");

	private static final int MAX_PLACES_PER_POS = 2;

	private int placeIn;
	private int breakIn;
	public boolean active;
	private final Map<class_2338, Integer> placeCounts = new HashMap<>();
	private final Map<class_2338, Integer> limitWindows = new HashMap<>();

	public AutoDTap() {
		super("Auto DTap",
				"Places and breaks crystals for you with limits",
				-1,
				Category.COMBAT);
		addSettings(macroKey, placeDelay, breakDelay, placeChance, attackChance, antiWeakness,
				allEntities, clickSimulation, breakBlocks, swapForWeakness, attackWindow, placeLimitDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ItemUseListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		placeCounts.clear();
		limitWindows.clear();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || mc.field_1761 == null)
			return;

		boolean placeWasReady = placeIn == 0;
		boolean breakWasCooling = breakIn != 0;

		if (placeIn > 0)
			placeIn--;

		if (breakIn > 0)
			breakIn--;

		if (antiWeakness.getValue() && WorldUtils.isDeadBodyNearby())
			return;

		ThreadLocalRandom random = ThreadLocalRandom.current();
		int roll = random.nextInt(1, 101);

		limitWindows.entrySet().removeIf(entry -> {
			int ticks = entry.getValue() - 1;
			if (ticks <= 0) {
				placeCounts.remove(entry.getKey());
				return true;
			}
			entry.setValue(ticks);
			return false;
		});

		if (mc.field_1724.method_6115())
			return;

		if (breakBlocks.getValue() && isComboingNearby())
			return;

		if (macroKey.getKey() != -1 && !KeyUtils.isKeyPressed(macroKey.getKey())) {
			resetState();
			return;
		}

		active = true;

		if (mc.field_1724.method_6047().method_7909() != class_1802.field_8301)
			return;

		class_239 hitResult = mc.field_1765;
		if (!(hitResult instanceof class_3965 blockHit) || hitResult.method_17783() != class_239.class_240.field_1332)
			return;

		class_2338 pos = blockHit.method_17777();

		handleCrystalPlace(blockHit, pos, placeWasReady, roll, random);
		handleBlockBreak(blockHit, pos, !breakWasCooling, placeWasReady, breakWasCooling, roll, random);
		handleMissSwing(!breakWasCooling, roll, random);

		handleEntityAttack(!breakWasCooling, random);
	}

	private void handleCrystalPlace(class_3965 blockHit, class_2338 pos, boolean placeReady, int roll, ThreadLocalRandom random) {
		if (!placeReady || roll > placeChance.getValueInt())
			return;

		if (!isSupport(pos) || !BlockUtils.canPlaceBlockClient(pos) || limitWindows.containsKey(pos))
			return;

		int places = placeCounts.getOrDefault(pos, 0);
		if (places >= MAX_PLACES_PER_POS)
			return;

		if (clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

		WorldUtils.placeBlock(blockHit, true);

		placeCounts.put(pos, places + 1);
		if (places + 1 >= MAX_PLACES_PER_POS)
			limitWindows.put(pos, placeLimitDelay.getValueInt());

		placeIn = placeDelay.getValueInt();
	}

	private void handleBlockBreak(class_3965 blockHit, class_2338 pos, boolean breakReady,
	                              boolean placeReady, boolean breakWasCooling, int roll, ThreadLocalRandom random) {
		if (!breakBlocks.getValue())
			return;

		if (!breakReady || roll > attackChance.getValueInt())
			return;

		if (clickSimulation.getValue() && (!isSupport(pos) || BlockUtils.canPlaceBlockClient(pos)))
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

		mc.field_1761.method_2910(pos, blockHit.method_17780());
		mc.field_1724.method_6104(class_1268.field_5808);
		mc.field_1761.method_2902(pos, blockHit.method_17780());
		breakIn = breakDelay.getValueInt();

		if (placeReady && roll <= placeChance.getValueInt() && breakWasCooling && clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
	}

	private void handleMissSwing(boolean breakReady, int roll, ThreadLocalRandom random) {
		if (mc.field_1765.method_17783() != class_239.class_240.field_1333 || !breakBlocks.getValue())
			return;

		if (!breakReady || roll > attackChance.getValueInt())
			return;

		if (mc.field_1761.method_2924())
			((MinecraftClientAccessor) mc).setAttackCooldown(10);

		if (clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

		mc.field_1724.method_6104(class_1268.field_5808);
		breakIn = breakDelay.getValueInt();
	}

	private void handleEntityAttack(boolean breakReady, ThreadLocalRandom random) {
		if (!(mc.field_1765 instanceof class_3966 entityHit))
			return;

		int roll = random.nextInt(1, 101);
		if (!breakReady || roll > attackChance.getValueInt())
			return;

		class_1297 entity = entityHit.method_17782();
		if (!allEntities.getValue() && !(entity instanceof class_1511) && !(entity instanceof class_1621))
			return;

		int previousSlot = mc.field_1724.method_31548().method_67532();
		boolean needsSword = (entity instanceof class_1511 || entity instanceof class_1621)
				&& swapForWeakness.getValue()
				&& isWeakWithoutStrength();

		if (needsSword)
			InventoryUtils.selectSword();

		if (clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

		WorldUtils.hitEntity(entity, true);
		breakIn = breakDelay.getValueInt();

		if (needsSword)
			InventoryUtils.setInvSlot(previousSlot);
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		if (mc.field_1724 == null || mc.field_1724.method_6047().method_7909() != class_1802.field_8301)
			return;

		if (!(mc.field_1765 instanceof class_3965 blockHit))
			return;

		if (blockHit.method_17783() != class_239.class_240.field_1332)
			return;

		class_2338 support = blockHit.method_17777();
		if (isSupport(support))
			event.cancel();
	}

	private boolean isWeakWithoutStrength() {
		class_1293 weakness = mc.field_1724.method_6112(class_1294.field_5911);
		class_1293 strength = mc.field_1724.method_6112(class_1294.field_5910);
		return weakness != null && (strength == null || strength.method_5578() <= weakness.method_5578());
	}

	private boolean isComboingNearby() {
		return mc.field_1687.method_18456().parallelStream()
				.filter(player -> player != mc.field_1724)
				.filter(player -> player.method_5858(mc.field_1724) < 36.0D)
				.filter(player -> player.method_49107() == null)
				.filter(player -> !player.method_24828())
				.anyMatch(player -> player.field_6235 >= 2)
				&& !(mc.field_1724.method_6052() instanceof net.minecraft.class_1657);
	}

	private boolean isSupport(class_2338 pos) {
		class_2248 block = mc.field_1687.method_8320(pos).method_26204();
		return block == class_2246.field_10540 || block == class_2246.field_9987;
	}

	private void resetState() {
		placeIn = 0;
		breakIn = 0;
		active = false;
	}
}
