package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import xyz.dqrkis.event.events.ShieldDisabledListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.ItemUtils;
import xyz.dqrkis.utils.WorldUtils;

public final class MaceSwap extends Module implements TickListener, ShieldDisabledListener {
	private final BooleanSetting density = new BooleanSetting("Density", true)
			.setDescription("Prefers maces enchanted with Density");
	private final BooleanSetting breach = new BooleanSetting("Breach", true)
			.setDescription("Prefers maces enchanted with Breach");
	private final BooleanSetting swords = new BooleanSetting("Swords", true)
			.setDescription("Triggers when holding a sword");
	private final BooleanSetting axes = new BooleanSetting("Axes", false)
			.setDescription("Triggers when holding an axe");
	private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true)
			.setDescription("Switches back to your previous slot");
	private final NumberSetting switchBackDelay = new NumberSetting("Switch Back Delay", 0, 20, 0, 1);

	private boolean swapped;
	private int previousSlot = -1;
	private int switchClock;

	public MaceSwap() {
		super("Mace Swap",
				"Swaps to a mace after disabling an opponents shield",
				-1,
				Category.COMBAT);
		addSettings(density, breach, swords, axes, switchBack, switchBackDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ShieldDisabledListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ShieldDisabledListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null || mc.field_1724 == null)
			return;

		if (!swapped)
			return;

		if (switchBack.getValue()) {
			if (switchClock < switchBackDelay.getValueInt()) {
				switchClock++;
				return;
			}
			if (previousSlot != -1)
				InventoryUtils.setInvSlot(previousSlot);
		}

		resetState();
	}

	@Override
	public void onShieldDisabled() {
		if (mc.field_1724 == null)
			return;

		if (!weaponMatches(mc.field_1724.method_6047()))
			return;

		if (previousSlot == -1)
			previousSlot = mc.field_1724.method_31548().method_67532();

		if (density.getValue() && breach.getValue()) {
			swapToAnyMace();
		} else if (!density.getValue() && !breach.getValue()) {
			swapToAnyMace();
		} else {
			if (density.getValue())
				swapToEnchantedMace("density");

			if (breach.getValue())
				swapToEnchantedMace("breach");
		}

		swapped = true;
	}

	private boolean weaponMatches(class_1799 stack) {
		if (swords.getValue() && axes.getValue())
			return WorldUtils.isSword(stack) || WorldUtils.isAxe(stack);
		return (!swords.getValue() || WorldUtils.isSword(stack)) && (!axes.getValue() || WorldUtils.isAxe(stack));
	}

	private void swapToAnyMace() {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (ItemUtils.isMace(stack)) {
				InventoryUtils.setInvSlot(i);
				return;
			}
		}
	}

	private void swapToEnchantedMace(String enchant) {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (stack.method_31574(class_1802.field_49814) && ItemUtils.hasEnchant(stack, enchant)) {
				InventoryUtils.setInvSlot(i);
				return;
			}
		}
	}

	private void resetState() {
		previousSlot = -1;
		switchClock = 0;
		swapped = false;
	}
}
