package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;

public final class HitboxExpand extends Module {
	private final BooleanSetting playersOnly = new BooleanSetting("Players Only", true)
			.setDescription("Only expands the hitbox of players");
	private final NumberSetting expand = new NumberSetting("Expand Amount", 0, 1, 0.1, 0.05)
			.setDescription("How much to expand the targeting hitbox");

	public HitboxExpand() {
		super("Hitbox Expand",
				"Expands entity hitboxes so they are easier to hit",
				-1,
				Category.COMBAT);
		addSettings(playersOnly, expand);
	}

	public float getExpand(class_1297 entity) {
		if (!isEnabled())
			return 0.0F;
		if (playersOnly.getValue() && !(entity instanceof class_1657))
			return 0.0F;
		if (entity == mc.field_1724)
			return 0.0F;
		return expand.getValueFloat();
	}
}
