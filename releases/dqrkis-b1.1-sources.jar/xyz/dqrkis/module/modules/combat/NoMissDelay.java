package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_239;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.BlockBreakingListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.utils.WorldUtils;

public final class NoMissDelay extends Module implements AttackListener, BlockBreakingListener {
	private final BooleanSetting onlyWeapon = new BooleanSetting("Only weapon", true);
	private final BooleanSetting air = new BooleanSetting("Air", true)
			.setDescription("Whether to stop hits directed to the air");
	private final BooleanSetting blocks = new BooleanSetting("Blocks", false)
			.setDescription("Whether to stop hits directed to blocks");

	public NoMissDelay() {
		super("No Miss Delay",
				"Doesn't let you miss your sword/axe hits",
				-1,
				Category.COMBAT);
		addSettings(onlyWeapon, air, blocks);
	}

	@Override
	public void onEnable() {
		eventManager.add(AttackListener.class, this);
		eventManager.add(BlockBreakingListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(BlockBreakingListener.class, this);
		super.onDisable();
	}

	@Override
	public void onAttack(AttackEvent event) {
		if (onlyWeapon.getValue() && !WorldUtils.isWeapon(mc.field_1724.method_6047()))
			return;

		switch (mc.field_1765.method_17783()) {
			case field_1333 -> {
				if (air.getValue()) event.cancel();
			}
			case field_1332 -> {
				if (blocks.getValue()) event.cancel();
			}
		}
	}

	@Override
	public void onBlockBreaking(BlockBreakingEvent event) {
		if (onlyWeapon.getValue() && !WorldUtils.isWeapon(mc.field_1724.method_6047()))
			return;

		if (mc.field_1765.method_17783() == class_239.class_240.field_1332) {
			if (blocks.getValue()) event.cancel();
		}
	}
}
