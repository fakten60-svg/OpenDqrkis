package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1268;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;

public final class AntiWeb extends Module implements TickListener {
	private final BooleanSetting swing = new BooleanSetting("Swing Hand", true)
			.setDescription("Swings the hand when breaking webs");
	private final BooleanSetting breakAbove = new BooleanSetting("Break Above Head", true)
			.setDescription("Also breaks the web above your head");

	public AntiWeb() {
		super("Anti Web",
				"Breaks webs around you instantly",
				-1,
				Category.COMBAT);
		addSettings(swing, breakAbove);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null)
			return;

		class_2338 feet = mc.field_1724.method_24515();

		if (mc.field_1687.method_8320(feet).method_27852(class_2246.field_10343)) {
			mc.field_1761.method_2910(feet, class_2350.field_11036);
			if (swing.getValue())
				mc.field_1724.method_6104(class_1268.field_5808);
		}

		if (breakAbove.getValue()) {
			class_2338 above = feet.method_10084();
			if (mc.field_1687.method_8320(above).method_27852(class_2246.field_10343))
				mc.field_1761.method_2910(above, class_2350.field_11036);
		}
	}
}
