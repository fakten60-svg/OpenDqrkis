package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.*;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public final class AutoHitCrystal extends Module implements TickListener, ItemUseListener, AttackListener {
	private final KeybindSetting activateKey = new KeybindSetting("Activate Key", GLFW.GLFW_MOUSE_BUTTON_RIGHT, false)
			.setDescription("Key that does hit crystalling");
	private final BooleanSetting checkPlace = new BooleanSetting("Check Place", false)
			.setDescription("Checks if you can place the obsidian on that block");
	private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 20, 0, 1);
	private final NumberSetting switchChance = new NumberSetting("Switch Chance", 0, 100, 100, 1);
	private final NumberSetting placeDelay = new NumberSetting("Place Delay", 0, 20, 0, 1);
	private final NumberSetting placeChance = new NumberSetting("Place Chance", 0, 100, 100, 1).setDescription("Randomization");
	private final BooleanSetting workWithTotem = new BooleanSetting("Work With Totem", false);
	private final BooleanSetting workWithCrystal = new BooleanSetting("Work With Crystal", false);
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false)
			.setDescription("Makes the CPS hud think you're legit");
	private final BooleanSetting swordSwap = new BooleanSetting("Sword Swap", true);

	private int placeClock = 0;
	private int switchClock = 0;
	private boolean active;
	private boolean crystalling;
	private boolean crystalSelected;

	public AutoHitCrystal() {
		super("Auto Hit Crystal",
				"Automatically hit-crystals for you",
				-1,
				Category.COMBAT);
		addSettings(activateKey, checkPlace, switchDelay, switchChance, placeDelay, placeChance, workWithTotem, workWithCrystal, clickSimulation, swordSwap);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ItemUseListener.class, this);
		eventManager.add(AttackListener.class, this);
		reset();

		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		eventManager.remove(AttackListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		int randomNum = MathUtils.randomInt(1, 100);

		if (mc.field_1755 != null)
			return;

		if (KeyUtils.isKeyPressed(activateKey.getKey())) {
			if(mc.field_1765 instanceof class_3965 hitResult && mc.field_1765.method_17783() == class_239.class_240.field_1332)
				if(!active && !BlockUtils.canPlaceBlockClient(hitResult.method_17777()) && checkPlace.getValue())
					return;

			class_1799 mainHandStack = mc.field_1724.method_6047();

			if (!(WorldUtils.isSword(mainHandStack) || (workWithTotem.getValue() && mainHandStack.method_31574(class_1802.field_8288)) || workWithCrystal.getValue() && mainHandStack.method_31574(class_1802.field_8301)) && !active)
				return;
			else if(mc.field_1765 instanceof class_3965 hitResult && !active) {
				if(swordSwap.getValue()) {
					if (mc.field_1765.method_17783() == class_239.class_240.field_1332) {
						class_2248 block = mc.field_1687.method_8320(hitResult.method_17777()).method_26204();

						crystalling = block == class_2246.field_10540 || block == class_2246.field_9987;
					}
				}
			}

			active = true;

			if (!crystalling) {
				if (mc.field_1765 instanceof class_3965 hit) {
					if (hit.method_17783() == class_239.class_240.field_1333)
						return;

					if (!BlockUtils.isBlock(hit.method_17777(), class_2246.field_10540)) {
						if(BlockUtils.isBlock(hit.method_17777(), class_2246.field_23152) && BlockUtils.isAnchorCharged(hit.method_17777()))
							return;

						mc.field_1690.field_1904.method_23481(false);

						if (!mc.field_1724.method_24518(class_1802.field_8281)) {
							if (switchClock > 0) {
								switchClock--;
								return;
							}

							if (randomNum <= switchChance.getValueInt()) {
								switchClock = switchDelay.getValueInt();
								InventoryUtils.selectItemFromHotbar(class_1802.field_8281);
							}
						}

						if (mc.field_1724.method_24518(class_1802.field_8281)) {
							if (placeClock > 0) {
								placeClock--;
								return;
							}

							if (clickSimulation.getValue())
								MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

							randomNum = MathUtils.randomInt(1, 100);

							if (randomNum <= placeChance.getValueInt()) {
								WorldUtils.placeBlock(hit, true);

								placeClock = placeDelay.getValueInt();
								crystalling = true;
							}
						}
					}
				}
			}

			if (crystalling) {
				if (!mc.field_1724.method_24518(class_1802.field_8301) && !crystalSelected) {
					if (switchClock > 0) {
						switchClock--;
						return;
					}

					randomNum = MathUtils.randomInt(1, 100);

					if (randomNum <= switchChance.getValueInt()) {
						crystalSelected = InventoryUtils.selectItemFromHotbar(class_1802.field_8301);
						switchClock = switchDelay.getValueInt();
					}
				}

				if (mc.field_1724.method_24518(class_1802.field_8301)) {
					AutoCrystal autoCrystal = Dqrkis.INSTANCE.getModuleManager().getModule(AutoCrystal.class);

					if (!autoCrystal.isEnabled())
						autoCrystal.onTick();
				}
			}
		} else reset();
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		class_1799 mainHandStack = mc.field_1724.method_6047();
		if ((mainHandStack.method_31574(class_1802.field_8301) || mainHandStack.method_31574(class_1802.field_8281)) && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) != GLFW.GLFW_PRESS)
			event.cancel();
	}

	public void reset() {
		placeClock = placeDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
		active = false;
		crystalling = false;
		crystalSelected = false;
	}

	@Override
	public void onAttack(AttackEvent event) {
		if (mc.field_1724.method_6047().method_31574(class_1802.field_8301) && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			event.cancel();
	}
}
