package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.HudListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.MouseSimulation;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_332;

public final class AutoMace extends Module implements TickListener, HudListener {
	private final NumberSetting targetRange = new NumberSetting("Target Range", 1, 6, 4.5, 0.1);
	private final NumberSetting minFallDistance = new NumberSetting("Min Fall Distance", 1, 10, 3, 0.1);
	private final NumberSetting minFallVelocity = new NumberSetting("Min Fall Velocity", 0.1, 2, 0.3, 0.1);
	private final NumberSetting attackCooldownTicks = new NumberSetting("Attack Cooldown", 0, 10, 1, 1);
	private final BooleanSetting elytraOnly = new BooleanSetting("Elytra Only", true)
			.setDescription("Only works while gliding with an elytra");
	private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", true);
	private final BooleanSetting seeOnly = new BooleanSetting("See Only", true)
			.setDescription("Only targets players you can see");
	private final BooleanSetting checkFallVelocity = new BooleanSetting("Check Fall Velocity", true);
	private final BooleanSetting waitForCrit = new BooleanSetting("Wait For Crit", true);
	private final BooleanSetting breakShieldsWithAxe = new BooleanSetting("Break Shields With Axe", false);
	private final BooleanSetting debugOverlay = new BooleanSetting("Debug Overlay", true);

	private int previousSlot = -1;
	private int attackCooldown;
	private int switchBackTimer;
	private boolean hitLanded;
	private class_1657 lastTarget;
	private final List<String> debugMessages = new ArrayList<>();
	private long lastDebugTime;
	private boolean wasHighEnough;

	public AutoMace() {
		super("Auto Mace",
				"Automatically attacks with mace on fall",
				-1,
				Category.COMBAT);
		addSettings(targetRange, minFallDistance, minFallVelocity, attackCooldownTicks, elytraOnly,
				switchBack, clickSimulation, seeOnly, checkFallVelocity, waitForCrit, breakShieldsWithAxe, debugOverlay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(HudListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(HudListener.class, this);
		switchBackToSavedSlot();
		resetState();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || mc.field_1761 == null)
			return;

		tickSwitchBack();

		if (attackCooldown > 0)
			attackCooldown--;

		updateDebugFallTracking();

		if (!InventoryUtils.hasItemInHotbar(item -> item == class_1802.field_49814)) {
			if (previousSlot != -1 && switchBack.getValue())
				switchBackToSavedSlot();
			return;
		}

		class_1657 target = findTarget();
		if (target == null) {
			if (previousSlot != -1 && switchBack.getValue())
				switchBackToSavedSlot();
			debug("Waiting for player...");
			return;
		}

		lastTarget = target;
		double distance = mc.field_1724.method_5739(target);
		debug("Found player: " + target.method_5477().getString());

		if (distance > targetRange.getValueFloat()) {
			debug("Approaching target... (" + String.format("%.1fm", distance) + ")");
			return;
		}

		if (breakShieldsWithAxe.getValue() && holdingAxe() && isBlockingWithShield(target)) {
			shieldBreakCombo(target);
		} else {
			normalAttack(target);
		}
	}

	private void normalAttack(class_1657 target) {
		if (attackCooldown > 0)
			return;

		if (waitForCrit.getValue() && !isCritOpportunity()) {
			debug("Waiting for crit opportunity...");
			return;
		}

		if (!mc.field_1724.method_6047().method_31574(class_1802.field_49814) && !swapToMace())
			return;

		debug("Macing " + target.method_5477().getString() + "!");
		attack(target);
		attackCooldown = Math.max(attackCooldownTicks.getValueInt(), 10);
		hitLanded = true;

		if (switchBack.getValue())
			scheduleSwitchBack();
	}

	private void shieldBreakCombo(class_1657 target) {
		if (attackCooldown > 0)
			return;

		if (!findAndSwapToAxe()) {
			debug("No axe found - using mace only");
			normalAttack(target);
			return;
		}

		debug("Breaking shield with axe...");
		attack(target);

		if (!swapToMace()) {
			debug("Failed to switch to mace after axe!");
			return;
		}

		debug("Macing target for high damage!");
		attack(target);
		hitLanded = true;
		attackCooldown = Math.max(attackCooldownTicks.getValueInt(), 20);

		if (switchBack.getValue())
			scheduleSwitchBack();
	}

	private void attack(class_1657 target) {
		if (clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT, 100);

		mc.field_1761.method_2918(mc.field_1724, target);
		mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
	}

	private boolean isReadyToFall() {
		if (mc.field_1724 == null)
			return false;

		if (elytraOnly.getValue() && !mc.field_1724.method_6128())
			return false;

		if (checkFallVelocity.getValue() && Math.abs(mc.field_1724.method_18798().field_1351) < minFallVelocity.getValueFloat())
			return false;

		return !(getPotentialFallHeight() < minFallDistance.getValueFloat());
	}

	private double getPotentialFallHeight() {
		double y = mc.field_1724.method_23318();
		for (int i = 1; i <= 256; i++) {
			int checkY = (int) (y - i);
			if (checkY < mc.field_1687.method_31607())
				break;

			if (!mc.field_1687.method_8320(mc.field_1724.method_24515().method_33096(checkY)).method_26215())
				return i;
		}
		return y - mc.field_1687.method_31607();
	}

	private class_1657 findTarget() {
		class_1657 best = null;
		double bestDistance = targetRange.getValueFloat();

		for (class_1657 player : mc.field_1687.method_18456()) {
			if (!isValidTarget(player))
				continue;

			double distance = mc.field_1724.method_5739(player);
			if (distance > bestDistance)
				continue;

			if (seeOnly.getValue() && !mc.field_1724.method_6057(player))
				continue;

			bestDistance = distance;
			best = player;
		}
		return best;
	}

	private boolean isValidTarget(class_1657 player) {
		if (player == null || player == mc.field_1724)
			return false;

		if (player.method_29504() || player.method_31481())
			return false;

		return !player.method_68878() && !player.method_7325();
	}

	private boolean isCritOpportunity() {
		boolean falling = !mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 < 0.0D;
		boolean inFluidOrVehicle = mc.field_1724.method_5799() || mc.field_1724.method_5771()
				|| mc.field_1724.method_6101() || mc.field_1724.method_5765();

		return falling && !inFluidOrVehicle;
	}

	private boolean holdingAxe() {
		return InventoryUtils.hasItemInHotbar(item -> item.toString().contains("axe"));
	}

	private boolean isBlockingWithShield(class_1657 player) {
		boolean holdingShieldWhileUsing = player.method_6115()
				&& (player.method_6047().method_7909().toString().contains("shield")
				|| player.method_6079().method_7909().toString().contains("shield"));
		return holdingShieldWhileUsing || player.method_6039();
	}

	private boolean swapToMace() {
		saveCurrentSlotIfNeeded();

		for (int i = 0; i < 9; i++) {
			if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_49814)) {
				InventoryUtils.setInvSlot(i);
				return true;
			}
		}
		return false;
	}

	private boolean findAndSwapToAxe() {
		saveCurrentSlotIfNeeded();

		for (int i = 0; i < 9; i++) {
			String itemName = mc.field_1724.method_31548().method_5438(i).method_7909().toString();
			if (itemName.contains("axe")) {
				InventoryUtils.setInvSlot(i);
				return true;
			}
		}
		return false;
	}

	private void saveCurrentSlotIfNeeded() {
		if (previousSlot == -1)
			previousSlot = mc.field_1724.method_31548().method_67532();
	}

	private void scheduleSwitchBack() {
		switchBackTimer = 4;
	}

	private void tickSwitchBack() {
		if (switchBackTimer > 0 && --switchBackTimer == 0)
			switchBackToSavedSlot();
	}

	private void switchBackToSavedSlot() {
		if (previousSlot != -1 && previousSlot != mc.field_1724.method_31548().method_67532()) {
			InventoryUtils.setInvSlot(previousSlot);
			previousSlot = -1;
		}
	}

	private void updateDebugFallTracking() {
		if (!debugOverlay.getValue())
			return;

		double height = getPotentialFallHeight();
		boolean highEnough = height >= 5.0D;

		if (highEnough) {
			if (!wasHighEnough) {
				debugMessages.clear();
				debug("Mace mode activated - searching for targets...");
			}
		} else if (wasHighEnough) {
			switchBackTimer = Math.max(switchBackTimer, 60);
		}

		wasHighEnough = highEnough;
	}

	private void debug(String message) {
		if (!debugOverlay.getValue())
			return;

		long now = System.currentTimeMillis();
		if (now - lastDebugTime <= 100L)
			return;

		if (!debugMessages.contains(message)) {
			debugMessages.add(message);
			if (debugMessages.size() > 5)
				debugMessages.removeFirst();
		}

		lastDebugTime = now;
	}

	@Override
	public void onRenderHud(HudEvent event) {
		if (!debugOverlay.getValue() || debugMessages.isEmpty())
			return;

		class_332 context = event.context;

		int textWidth = 0;
		for (String message : debugMessages)
			textWidth = Math.max(textWidth, mc.field_1772.method_1727(message));

		int backgroundHeight = debugMessages.size() * 12 + 8;
		context.method_25294(6, 6, 10 + textWidth + 8, 10 + backgroundHeight, Integer.MIN_VALUE);
		context.method_25294(6, 6, textWidth + 12, backgroundHeight + 4, 0xFF00FF00);

		for (int i = 0; i < debugMessages.size(); i++)
			context.method_51433(mc.field_1772, debugMessages.get(i), 10, 10 + i * 12, 0xFFFFFF, true);
	}

	private void resetState() {
		previousSlot = -1;
		attackCooldown = 0;
		switchBackTimer = 0;
		hitLanded = false;
		lastTarget = null;
		debugMessages.clear();
		wasHighEnough = false;
	}
}
