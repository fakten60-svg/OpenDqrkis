package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.HudListener;
import xyz.dqrkis.event.events.PacketSendListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.TimerUtils;
import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import org.lwjgl.glfw.GLFW;

public final class AutoWTap extends Module implements PacketSendListener, HudListener {
	private final MinMaxSetting delay = new MinMaxSetting("Delay", 0, 1000, 1,230, 270);
	private final BooleanSetting inAir = new BooleanSetting("In Air", false)
			.setDescription("Whether it should W tap in air");
	private final TimerUtils sprintTimer = new TimerUtils();
	private final TimerUtils tapTimer = new TimerUtils();
	private boolean holdingForward;
	private boolean sprinting;
	private int currentDelay;
	private boolean jumpedWhileHitting;

	public AutoWTap() {
		super("Auto WTap",
				"Automatically W Taps for you so the opponent takes more knockback",
				-1,
				Category.COMBAT);
		addSettings(delay, inAir);
	}

	@Override
	public void onEnable() {
		eventManager.add(PacketSendListener.class, this);
		eventManager.add(HudListener.class, this);
		currentDelay = delay.getRandomValueInt();
		jumpedWhileHitting = false;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(PacketSendListener.class, this);
		eventManager.remove(HudListener.class, this);
		super.onDisable();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_W) != 1) {
			sprinting = false;
			holdingForward = false;
			return;
		}

		if (!inAir.getValue() && !mc.field_1724.method_24828())
			return;

		if (mc.field_1724.method_24828()) {
			jumpedWhileHitting = false;
		}

		if (GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_SPACE) == 1 && !inAir.getValue()) {
			if (holdingForward || sprinting) {
				mc.field_1690.field_1894.method_23481(true);
				holdingForward = false;
				sprinting = false;
				return;
			}
		}

		if (holdingForward && tapTimer.delay(1)) {
			mc.field_1690.field_1894.method_23481(false);
			sprintTimer.reset();
			sprinting = true;
			holdingForward = false;
		}

		if (sprinting && sprintTimer.delay(currentDelay)) {
			mc.field_1690.field_1894.method_23481(true);
			sprinting = false;
			currentDelay = delay.getRandomValueInt();
		}
	}

	@Override
	public void onPacketSend(PacketSendEvent event) {
		if (!(event.packet instanceof class_2824 packet))
			return;

		packet.method_34209(new class_2824.class_5908() {
			@Override
			public void method_34219(class_1268 hand) {
			}

			@Override
			public void method_34220(class_1268 hand, class_243 pos) {
			}

			@Override
			public void method_34218() {
				if (GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_SPACE) == 1 && !inAir.getValue()) {
					jumpedWhileHitting = true;
				}

				if (!inAir.getValue() && !mc.field_1724.method_24828())
					return;

				if (!jumpedWhileHitting && mc.field_1690.field_1894.method_1434() && mc.field_1724.method_5624()) {
					sprintTimer.reset();
					holdingForward = true;
				}
			}
		});
	}
}