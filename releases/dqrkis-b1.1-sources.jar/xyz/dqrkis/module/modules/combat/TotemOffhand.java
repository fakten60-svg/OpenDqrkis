package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;

public final class TotemOffhand extends Module implements TickListener {
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 5, 0, 1);
    private final NumberSetting equipDelay = new NumberSetting("Equip Delay", 1, 5, 1, 1);
    private final BooleanSetting switchBack = new BooleanSetting("Switch Back", false);

    private int switchClock, equipClock, switchBackClock;
    private int previousSlot = -1;
    boolean sent, active = false;

    public TotemOffhand() {
        super("Totem Offhand", "Switches to your totem slot and offhands a totem if you dont have one already", -1, Category.COMBAT);
        addSettings(switchDelay, equipDelay, switchBack);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        reset();

        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick() {
        if(mc.field_1755 != null)
            return;

        if(mc.field_1724.method_6079().method_7909() != class_1802.field_8288)
            active = true;

        if(active) {
			if (switchClock < switchDelay.getValueInt()) {
				switchClock++;
				return;
			}

			if(previousSlot == -1)
				previousSlot = mc.field_1724.method_31548().method_67532();

            if (InventoryUtils.selectItemFromHotbar(class_1802.field_8288)) {
                if (equipClock < equipDelay.getValueInt()) {
                    equipClock++;
                    return;
                }

                if (!sent) {
                    mc.method_1562().method_48296().method_10743(new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                    sent = true;
                    return;
                }
            }

            if(switchBackClock < switchDelay.getValue()) {
                switchBackClock++;
            } else {
                if(switchBack.getValue())
                    InventoryUtils.setInvSlot(previousSlot);

                reset();
            }
        }
    }

    public void reset() {
        switchClock = 0;
        equipClock = 0;
        switchBackClock = 0;
        previousSlot = -1;

        sent = false;
        active = false;
    }
}
