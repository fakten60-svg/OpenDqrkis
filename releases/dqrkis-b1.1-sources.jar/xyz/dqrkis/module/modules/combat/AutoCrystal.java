package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.*;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class AutoCrystal extends Module implements TickListener, ItemUseListener {
	private final KeybindSetting activateKey = new KeybindSetting("Activate Key", GLFW.GLFW_MOUSE_BUTTON_RIGHT, false)
			.setDescription("Key that does the crystalling");

	private final NumberSetting placeDelay = new NumberSetting("Place Delay", 0, 20, 0, 1);
	private final NumberSetting breakDelay = new NumberSetting("Break Delay", 0, 20, 0, 1);

	private final NumberSetting placeChance = new NumberSetting("Place Chance", 0, 100, 100, 1)
			.setDescription("Randomization");
	private final NumberSetting breakChance = new NumberSetting("Break Chance", 0, 100, 100, 1)
			.setDescription("Randomization");

	private final BooleanSetting stopOnKill = new BooleanSetting("Stop on Kill", false)
			.setDescription("Won't crystal if a dead player is nearby");
	private final BooleanSetting fakePunch = new BooleanSetting("Fake Punch", false)
			.setDescription("Will hit every entity and block if you miss a hitcrystal");
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false)
			.setDescription("Makes the CPS hud think you're legit");
	private final BooleanSetting damageTick = new BooleanSetting("Damage Tick", false)
			.setDescription("Times your crystals for a perfect d-tap");
	private final BooleanSetting antiWeakness = new BooleanSetting("Anti-Weakness", false)
			.setDescription("Silently switches to a sword and then hits the crystal if you have weakness");

	private final NumberSetting particleChance = new NumberSetting("Particle Chance", 0, 100, 20, 1)
			.setDescription("Adds block breaking particles to make it seem more legit from your POV (Only works with fake punch)");

	private int placeClock;
	private int breakClock;
	public boolean crystalling;

	public AutoCrystal() {
		super("Auto Crystal",
				"Automatically crystals fast for you",
				-1,
				Category.COMBAT);
		addSettings(activateKey, placeDelay, breakDelay, placeChance, breakChance, stopOnKill, fakePunch, clickSimulation, damageTick, antiWeakness, particleChance);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ItemUseListener.class, this);

		placeClock = 0;
		breakClock = 0;
		crystalling = false;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null)
			return;

		boolean dontPlace = (placeClock != 0);
		boolean dontBreak = (breakClock != 0);

		if (stopOnKill.getValue() && WorldUtils.isDeadBodyNearby())
			return;

		int randomInt = MathUtils.randomInt(1, 100);

		if (dontPlace)
			placeClock--;

		if (dontBreak)
			breakClock--;

		if (mc.field_1724.method_6115())
			return;

		if (damageTick.getValue() && damageTickCheck())
			return;

		if (activateKey.getKey() != -1 && !KeyUtils.isKeyPressed(activateKey.getKey())) {
			placeClock = 0;
			breakClock = 0;
			crystalling = false;
			return;
		} else crystalling = true;

		if (mc.field_1724.method_6047().method_7909() != class_1802.field_8301)
			return;

		if (mc.field_1765 instanceof class_3965 hit) {
			if (mc.field_1765.method_17783() == class_239.class_240.field_1332) {

				if (!dontPlace && randomInt <= placeChance.getValueInt()) {
					if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_10540) || BlockUtils.isBlock(hit.method_17777(), class_2246.field_9987) && CrystalUtils.canPlaceCrystalClientAssumeObsidian(hit.method_17777())) {

						if (clickSimulation.getValue())
							MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

						WorldUtils.placeBlock(hit, true);

						if (fakePunch.getValue()) {
							if (randomInt <= particleChance.getValue())
								if (CrystalUtils.canPlaceCrystalClientAssumeObsidian(hit.method_17777()) && hit.method_17780() == class_2350.field_11036)
									mc.field_1724.method_6104(class_1268.field_5808);
						}

						placeClock = placeDelay.getValueInt();
					}
				}

				if (fakePunch.getValue()) {
					if (!dontBreak && randomInt <= breakChance.getValueInt()) {

						if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_10540) || BlockUtils.isBlock(hit.method_17777(), class_2246.field_9987))
							return;

						if (clickSimulation.getValue()) {
							if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_10540) || BlockUtils.isBlock(hit.method_17777(), class_2246.field_9987)) {
								if (CrystalUtils.canPlaceCrystalClientAssumeObsidian(hit.method_17777()))
									MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);
							} else MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);
						}

						mc.field_1761.method_2910(hit.method_17777(), hit.method_17780());
						mc.field_1724.method_6104(class_1268.field_5808);
						mc.field_1761.method_2902(hit.method_17777(), hit.method_17780());

						breakClock = breakDelay.getValueInt();
					}

					if (!dontPlace && randomInt <= placeChance.getValueInt() && dontBreak) {
						if (clickSimulation.getValue())
							MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
					}
				}
			}

			if (mc.field_1765.method_17783() == class_239.class_240.field_1333) {
				if (fakePunch.getValue()) {
					if (!dontBreak && randomInt <= breakChance.getValueInt()) {
						if (mc.field_1761.method_2924())
							mc.field_1771 = 10;

						if (clickSimulation.getValue())
							MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

						mc.field_1724.method_6104(class_1268.field_5808);

						breakClock = breakDelay.getValueInt();
					}

					if (!dontPlace && randomInt <= placeChance.getValueInt() && dontBreak) {
						if (clickSimulation.getValue())
							MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
					}
				}
			}
		}

		randomInt = MathUtils.randomInt(1, 100);

		if (mc.field_1765 instanceof class_3966 hit) {
			if (!dontBreak && randomInt <= breakChance.getValueInt()) {
				class_1297 entity = hit.method_17782();

				if (!fakePunch.getValue() && !(entity instanceof class_1511 || entity instanceof class_1621))
					return;

				int previousSlot = mc.field_1724.method_31548().method_67532();

				if(entity instanceof class_1511 || entity instanceof class_1621)
					if(antiWeakness.getValue() && cantBreakCrystal())
						InventoryUtils.selectSword();

				if (clickSimulation.getValue())
					MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

				WorldUtils.hitEntity(entity, true);
				breakClock = breakDelay.getValueInt();

				if(antiWeakness.getValue())
					InventoryUtils.setInvSlot(previousSlot);
			}
		}
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		if (mc.field_1724.method_6047().method_7909() == class_1802.field_8301) {
			if ((mc.field_1765 instanceof class_3965 h
					&& mc.field_1765.method_17783() == class_239.class_240.field_1332
					&& (BlockUtils.isBlock(h.method_17777(), class_2246.field_10540) || BlockUtils.isBlock(h.method_17777(), class_2246.field_9987)))) {
				event.cancel();
			}
		}
	}

	private boolean cantBreakCrystal() {
        assert mc.field_1724 != null;
        class_1293 weakness = mc.field_1724.method_6112(class_1294.field_5911);
		class_1293 strength = mc.field_1724.method_6112(class_1294.field_5910);
		return (!(weakness == null || strength != null && strength.method_5578() > weakness.method_5578() || WorldUtils.isTool(mc.field_1724.method_6047())));
	}

	private boolean damageTickCheck() {
		return mc.field_1687.method_18456().parallelStream()
				.filter(e -> e != mc.field_1724)
				.filter(e -> e.method_5858(mc.field_1724) < 36)
				.filter(e -> e.method_49107() == null)
				.filter(e -> !e.method_24828())
				.anyMatch(e -> e.field_6235 >= 2)

				&& !(mc.field_1724.method_6052() instanceof class_1657);
	}
}
