package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.ItemUseListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.*;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_9334;

//not mine
public final class AnchorMacro extends Module implements TickListener, ItemUseListener {
	private final BooleanSetting whileUse = new BooleanSetting("While Use", true).setDescription("If it should trigger while eating/using shield");
	private final BooleanSetting stopOnKill = new BooleanSetting("Stop on Kill", false).setDescription("Doesn't anchor if body nearby");
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false).setDescription("Makes the CPS hud think you're legit");
	private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 20, 0, 1);
	private final NumberSetting switchChance = new NumberSetting("Switch Chance", 0, 100, 100, 1);
	private final NumberSetting placeChance = new NumberSetting("Place Chance", 0, 100, 100, 1).setDescription("Randomization");
	private final NumberSetting glowstoneDelay = new NumberSetting("Glowstone Delay", 0, 20, 0, 1);
	private final NumberSetting glowstoneChance = new NumberSetting("Glowstone Chance", 0, 100, 100, 1);
	private final NumberSetting explodeDelay = new NumberSetting("Explode Delay", 0, 20, 0, 1);
	private final NumberSetting explodeChance = new NumberSetting("Explode Chance", 0, 100, 100, 1);
	private final NumberSetting explodeSlot = new NumberSetting("Explode Slot", 1, 9, 1, 1);
	private final BooleanSetting onlyOwn = new BooleanSetting("Only Own", false);
	private final BooleanSetting onlyCharge = new BooleanSetting("Only Charge", false);

	private int switchClock = 0;
	private int glowstoneClock = 0;
	private int explodeClock = 0;

	//hashset cuz in a hashset stuff cant repeat iirc
	private final Set<class_2338> ownedAnchors = new HashSet<>();

	public AnchorMacro() {
		super("Anchor Macro",
				"Automatically blows up respawn anchors for you",
				-1,
				Category.COMBAT);
		addSettings(whileUse, stopOnKill, clickSimulation, placeChance, switchDelay, switchChance, glowstoneDelay, glowstoneChance, explodeDelay, explodeChance, explodeSlot, onlyOwn, onlyCharge);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(ItemUseListener.class, this);
		switchClock = 0;
		glowstoneClock = 0;
		explodeClock = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(ItemUseListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null)
			return;

		if (((mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) || mc.field_1724.method_6047().method_7909() instanceof class_1819 || mc.field_1724.method_6079().method_7909() instanceof class_1819 || mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075)) && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) && whileUse.getValue())
			return;

		if(stopOnKill.getValue() && WorldUtils.isDeadBodyNearby())
			return;

		int randomInt = MathUtils.randomInt(1, 100);

		if (KeyUtils.isKeyPressed(GLFW.GLFW_MOUSE_BUTTON_RIGHT)) {
			if (mc.field_1765 instanceof class_3965 hit) {
				if (BlockUtils.isBlock(hit.method_17777(), class_2246.field_23152)) {
					if (onlyOwn.getValue() && !ownedAnchors.contains(hit.method_17777()))
						return;

					mc.field_1690.field_1904.method_23481(false);

					if (BlockUtils.isAnchorNotCharged(hit.method_17777())) {
						randomInt = MathUtils.randomInt(1, 100);

						if (randomInt <= placeChance.getValueInt()) {
							if (!mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
								if (switchClock != switchDelay.getValueInt()) {
									switchClock++;
									return;
								}

								randomInt = MathUtils.randomInt(1, 100);

								if(randomInt <= switchChance.getValueInt()) {
									switchClock = 0;
									InventoryUtils.selectItemFromHotbar(class_1802.field_8801);
								}
							}

							if (mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
								if (glowstoneClock != glowstoneDelay.getValueInt()) {
									glowstoneClock++;
									return;
								}

								randomInt = MathUtils.randomInt(1, 100);

								if(randomInt <= glowstoneChance.getValueInt()) {
									glowstoneClock = 0;

									if (clickSimulation.getValue())
										MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

									WorldUtils.placeBlock(hit, true);
								}
							}
						}
					}

					if (BlockUtils.isAnchorCharged(hit.method_17777())) {
						int slot = explodeSlot.getValueInt() - 1;

						if (mc.field_1724.method_31548().method_67532() != slot) {
							if (switchClock != switchDelay.getValueInt()) {
								switchClock++;
								return;
							}

							if(randomInt <= switchChance.getValueInt()) {
								switchClock = 0;
								mc.field_1724.method_31548().method_61496(slot);
							}
						}

						if (mc.field_1724.method_31548().method_67532() == slot) {
							if (explodeClock != explodeDelay.getValueInt()) {
								explodeClock++;
								return;
							}

							randomInt = MathUtils.randomInt(1, 100);

							if(randomInt <= explodeChance.getValueInt()) {
								explodeClock = 0;

								if (!onlyCharge.getValue()) {
									if (clickSimulation.getValue())
										MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

									WorldUtils.placeBlock(hit, true);

									ownedAnchors.remove(hit.method_17777());
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public void onItemUse(ItemUseEvent event) {
		if (mc.field_1765 instanceof class_3965 hitResult && hitResult.method_17783() == class_239.class_240.field_1332) {
			if (mc.field_1724.method_6047().method_7909() == class_1802.field_23141) {
				class_2350 dir = hitResult.method_17780();
				class_2338 pos = hitResult.method_17777();

				if (!mc.field_1687.method_8320(pos).method_45474()) {
					switch (dir) {
						case field_11036: {
							ownedAnchors.add(pos.method_10069(0, 1, 0));
							break;
						}
						case field_11033: {
							ownedAnchors.add(pos.method_10069(0, -1, 0));
							break;
						}
						case field_11034: {
							ownedAnchors.add(pos.method_10069(1, 0, 0));
							break;
						}
						case field_11039: {
							ownedAnchors.add(pos.method_10069(-1, 0, 0));
							break;
						}
						case field_11043: {
							ownedAnchors.add(pos.method_10069(0, 0, -1));
							break;
						}
						case field_11035: {
							ownedAnchors.add(pos.method_10069(0, 0, 1));
							break;
						}
					}
				} else ownedAnchors.add(pos);
			}

			class_2338 bp = hitResult.method_17777();

			if(BlockUtils.isAnchorCharged(bp))
				ownedAnchors.remove(bp);
		}
	}
}
