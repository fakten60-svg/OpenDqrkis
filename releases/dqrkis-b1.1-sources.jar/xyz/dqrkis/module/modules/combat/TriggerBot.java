package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.modules.client.Friends;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.MinMaxSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.MouseSimulation;
import xyz.dqrkis.utils.TimerUtils;
import xyz.dqrkis.utils.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import org.lwjgl.glfw.GLFW;

public final class TriggerBot extends Module implements TickListener, AttackListener {
	private final BooleanSetting inScreen = new BooleanSetting("Work In Screen", false)
			.setDescription("Will trigger even if youre inside a screen");
	private final BooleanSetting whileUse = new BooleanSetting("While Use", false)
			.setDescription("Will hit the player no matter if you're eating or blocking with a shield");
	private final BooleanSetting onLeftClick = new BooleanSetting("On Left Click", false)
			.setDescription("Only gets triggered if holding down left click");
	private final BooleanSetting allItems = new BooleanSetting("All Items", false)
			.setDescription("Works with all Items /THIS USES SWORD DELAY AS THE DELAY/");
	private final MinMaxSetting swordDelay = new MinMaxSetting("Sword Delay", 0, 1000, 1, 540, 550)
			.setDescription("Delay for swords");
	private final MinMaxSetting axeDelay = new MinMaxSetting("Axe Delay", 0, 1000, 1, 780, 800)
			.setDescription("Delay for axes");
	/*private final NumberSetting swordDelay = new NumberSetting("Sword Delay", 0, 1000, 550, 1)
			.setDescription("Delay for swords");*/
	/*private final NumberSetting axeDelay = new NumberSetting("Axe Delay", 0, 1000, 800, 1)
			.setDescription("Delay for axes");*/
	private final BooleanSetting checkShield = new BooleanSetting("Check Shield", false)
			.setDescription("Checks if the player is blocking your hits with a shield (Recommended with Shield Disabler)");
	private final BooleanSetting onlyCritSword = new BooleanSetting("Only Crit Sword", false)
			.setDescription("Only does critical hits with a sword");
	private final BooleanSetting onlyCritAxe = new BooleanSetting("Only Crit Axe", false)
			.setDescription("Only does critical hits with an axe");
	private final BooleanSetting swing = new BooleanSetting("Swing Hand", true)
			.setDescription("Whether to swing the hand or not");
	private final BooleanSetting whileAscend = new BooleanSetting("While Ascending", false)
			.setDescription("Wont hit if you're ascending from a jump, only if on ground or falling");
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false)
			.setDescription("Makes the CPS hud think you're legit");
	private final BooleanSetting strayBypass = new BooleanSetting("Stray Bypass", false)
			.setDescription("Bypasses stray's Anti-TriggerBot");
	private final BooleanSetting allEntities = new BooleanSetting("All Entities", false)
			.setDescription("Will attack all entities");
	private final BooleanSetting useShield = new BooleanSetting("Use Shield", false)
			.setDescription("Uses shield if it's in your offhand");
	private final NumberSetting shieldTime = new NumberSetting("Shield Time", 100, 1000, 350, 1);
	private final BooleanSetting sticky = new BooleanSetting("Same Player", false)
			.setDescription("Hits the player that was recently attacked, good for FFA");
	private final TimerUtils timer = new TimerUtils();

	private int currentSwordDelay, currentAxeDelay;

	public TriggerBot() {
		super("Trigger Bot",
				"Automatically hits players for you",
				-1,
				Category.COMBAT);
		addSettings(inScreen, whileUse, onLeftClick, allItems, swordDelay, axeDelay, checkShield, whileAscend, sticky, onlyCritSword, onlyCritAxe, swing, clickSimulation, strayBypass, allEntities, useShield, shieldTime);
	}

	@Override
	public void onEnable() {
		currentSwordDelay = swordDelay.getRandomValueInt();
		currentAxeDelay = axeDelay.getRandomValueInt();

		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);
		super.onDisable();
	}

	@SuppressWarnings("all")
	@Override
	public void onTick() {
		try {
			if (!inScreen.getValue() && mc.field_1755 != null)
				return;

			if(Dqrkis.INSTANCE.getModuleManager().getModule(Friends.class).antiAttack.getValue() && Dqrkis.INSTANCE.getFriendManager().isAimingOverFriend())
				return;

			class_1799 mainHandStack = mc.field_1724.method_6047();
			class_1792 item = mainHandStack.method_7909();

			if (onLeftClick.getValue() && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
				return;

			if (((mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075) || mc.field_1724.method_6079().method_7909() instanceof class_1819) && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) && !whileUse.getValue())
				return;
			
			if (!whileAscend.getValue() && ((!mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 > 0) || (!mc.field_1724.method_24828() && mc.field_1724.field_6017 <= 0.0F)))
				return;

			if (!allItems.getValue()) {
				if (WorldUtils.isSword(mainHandStack)) {
					if (mc.field_1765 instanceof class_3966 hit) {
						class_1297 entity = hit.method_17782();

						assert mc.field_1724.method_6052() != null;
						if (sticky.getValue() && entity != mc.field_1724.method_6052())
							return;

						if (entity instanceof class_1657 || (strayBypass.getValue() && entity instanceof class_1642) || (allEntities.getValue() && entity != null)) {

							if (entity instanceof class_1657 player) {
								if (checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player))
									return;
							}

							if (onlyCritSword.getValue() && mc.field_1724.field_6017 <= 0.0F)
								return;

							if (timer.delay(currentSwordDelay)) {
								if (useShield.getValue()) {
									if (mc.field_1724.method_6079().method_7909() == class_1802.field_8255 && mc.field_1724.method_6039())
										MouseSimulation.mouseRelease(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
								}

								WorldUtils.hitEntity(entity, swing.getValue());

								if (clickSimulation.getValue())
									MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

								currentSwordDelay = swordDelay.getRandomValueInt();
								timer.reset();
							} else {
								if (useShield.getValue()) {
									if (mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
										int useFor = shieldTime.getValueInt();
										MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT, useFor);
									}
								}
							}
						}
					}
				} else if (WorldUtils.isAxe(mainHandStack)) {
					if (mc.field_1765 instanceof class_3966 hit) {
						class_1297 entity = hit.method_17782();

						if (entity instanceof class_1657 || (strayBypass.getValue() && entity instanceof class_1642) || (allEntities.getValue() && entity != null)) {
							if (entity instanceof class_1657 player) {
								if (checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player))
									return;
							}

							if (onlyCritAxe.getValue() && mc.field_1724.field_6017 <= 0.0F)
								return;

							if (timer.delay(currentAxeDelay)) {
								WorldUtils.hitEntity(entity, swing.getValue());

								if (clickSimulation.getValue())
									MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

								currentAxeDelay = axeDelay.getRandomValueInt();
								timer.reset();
							} else {
								if (useShield.getValue()) {
									if (mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
										int useFor = shieldTime.getValueInt();
										MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT, useFor);
									}
								}
							}
						}
					}
				}
			} else {
				if (mc.field_1765 instanceof class_3966 entityHit && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
					class_1297 entity = entityHit.method_17782();

					assert mc.field_1724.method_6052() != null;
					if (sticky.getValue() && entity != mc.field_1724.method_6052())
						return;

					if (entity instanceof class_1657 || (strayBypass.getValue() && entity instanceof class_1642) || (allEntities.getValue() && entity != null)) {
						if (entity instanceof class_1657 player) {
							if (checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player))
								return;
						}

						if (onlyCritSword.getValue() && mc.field_1724.field_6017 <= 0.0F)
							return;

						if (timer.delay(currentSwordDelay)) {
							WorldUtils.hitEntity(entity, swing.getValue());

							if (clickSimulation.getValue())
								MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

							currentSwordDelay = swordDelay.getRandomValueInt();
							timer.reset();
						} else {
							if (useShield.getValue()) {
								if (mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
									int useFor = shieldTime.getValueInt();
									MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT, useFor);
								}
							}
						}
					}
				}
			}
		} catch (Exception ignored) {}
	}

	@Override
	public void onAttack(AttackEvent event) {
		if (GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			event.cancel();
	}
}
