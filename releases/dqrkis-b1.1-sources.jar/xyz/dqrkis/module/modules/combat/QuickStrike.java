package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_6025;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.ItemUtils;
import xyz.dqrkis.utils.WorldUtils;

public final class QuickStrike extends Module implements TickListener {
	private final NumberSetting minFallDistance = new NumberSetting("Min Fall Distance", 1, 10, 3, 0.5)
			.setDescription("Only strikes after falling this far");
	private final NumberSetting attackDelay = new NumberSetting("Attack Delay", 0, 500, 100, 10)
			.setDescription("Milliseconds between attacks");
	private final NumberSetting densityFallDistance = new NumberSetting("Density Fall Distance", 1, 20, 7, 0.5)
			.setDescription("Falls beyond this use a Density mace instead of Breach");
	private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);
	private final BooleanSetting targetMobs = new BooleanSetting("Target Mobs", false)
			.setDescription("Also strikes mobs (ignores passive and tamed ones)");
	private final BooleanSetting shieldSwap = new BooleanSetting("Shield Swap", false)
			.setDescription("Swaps to an axe first against blocking players");
	private final BooleanSetting autoSwap = new BooleanSetting("Auto Swap", true)
			.setDescription("Swaps to a mace automatically");

	private long lastAttackMs;
	private int previousSlot = -1;
	private double apexY = -1.0D;
	private boolean shieldHandled;
	private int stage;
	private boolean pendingMaceAttack;
	private class_1297 maceTarget;
	private boolean pendingAxeAttack;
	private class_1297 axeTarget;
	private boolean airborne;

	public QuickStrike() {
		super("Quick Strike",
				"Automatically attacks while falling with mace.",
				-1,
				Category.COMBAT);
		addSettings(minFallDistance, attackDelay, densityFallDistance, targetPlayers, targetMobs, shieldSwap, autoSwap);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		if (previousSlot != -1 && mc.field_1724 != null)
			InventoryUtils.setInvSlot(previousSlot);
		resetState();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || mc.field_1761 == null)
			return;

		if (pendingAxeAttack && axeTarget != null) {
			attack(axeTarget);
			pendingAxeAttack = false;
			swapToMace();
			shieldHandled = true;
			stage = 0;
			pendingMaceAttack = true;
		} else if (pendingMaceAttack && maceTarget != null) {
			long now = System.currentTimeMillis();
			if (holdingMace() && now - lastAttackMs >= attackDelayMs()) {
				attack(maceTarget);
				lastAttackMs = now;
			}
			pendingMaceAttack = false;
			maceTarget = null;
		} else {
			updateFallState();
			engageWhileFalling();
		}
	}

	private long attackDelayMs() {
		return attackDelay.getValueLong();
	}

	private void updateFallState() {
		boolean onGround = mc.field_1724.method_24828();
		boolean fallingFast = mc.field_1724.method_18798().field_1351 < -0.1;
		double y = mc.field_1724.method_23318();

		if (onGround) {
			if (airborne)
				resetAirState();

			if (previousSlot != -1) {
				InventoryUtils.setInvSlot(previousSlot);
				previousSlot = -1;
			}
		} else {
			if (!airborne) {
				airborne = true;
				apexY = y;
				shieldHandled = false;
				stage = 0;
			} else if (fallingFast && apexY != -1.0D && y > apexY) {
				apexY = y;
			}
		}
	}

	private void engageWhileFalling() {
		if (!airborne || mc.field_1724.method_18798().field_1351 >= -0.1)
			return;

		double fallDistance = mc.field_1724.field_6017;
		if (fallDistance < minFallDistance.getValueFloat())
			return;

		class_1297 target = findNearestTarget();
		if (target == null)
			target = mc.field_1692;

		if (!isValidTarget(target))
			return;

		if (shieldSwap.getValue())
			tryShieldSwap(target, fallDistance);

		if (!shieldSwap.getValue() || shieldHandled || stage == 0)
			engage(target, fallDistance);
	}

	private void tryShieldSwap(class_1297 target, double fallDistance) {
		boolean blocking = target instanceof class_1657 player && player.method_24518(class_1802.field_8255) && player.method_6039();
		if (!(blocking && fallDistance > minFallDistance.getValueFloat() && !shieldHandled && stage == 0))
			return;

		if (previousSlot == -1)
			previousSlot = mc.field_1724.method_31548().method_67532();

		int axeSlot = findAxeSlot();
		if (axeSlot != -1) {
			InventoryUtils.setInvSlot(axeSlot);
			pendingAxeAttack = true;
			axeTarget = target;
			maceTarget = target;
			stage = 1;
		}
	}

	private void engage(class_1297 target, double fallDistance) {
		if (!holdingMace()) {
			if (previousSlot == -1)
				previousSlot = mc.field_1724.method_31548().method_67532();

			if (autoSwap.getValue())
				selectMaceForFall(fallDistance);
			else
				swapToMace();
		} else if (autoSwap.getValue()) {
			selectMaceForFall(fallDistance);
		}

		if (holdingMace()) {
			pendingMaceAttack = true;
			maceTarget = target;
		}
	}

	private void selectMaceForFall(double fallDistance) {
		int slot = fallDistance >= densityFallDistance.getValueFloat()
				? findEnchantedMace("density")
				: findEnchantedMace("breach");

		if (slot == -1)
			slot = findMaceSlot();

		if (slot != -1)
			InventoryUtils.setInvSlot(slot);
	}

	private void swapToMace() {
		int slot = findMaceSlot();
		if (slot != -1)
			InventoryUtils.setInvSlot(slot);
	}

	private void attack(class_1297 target) {
		if (!(target instanceof class_1309 living))
			return;

		if (!living.method_5805() || mc.field_1724.method_5858(target) >= 20.25D)
			return;

		mc.field_1761.method_2918(mc.field_1724, target);
		mc.field_1724.method_6104(class_1268.field_5808);
	}

	private boolean holdingMace() {
		return mc.field_1724.method_6047().method_31574(class_1802.field_49814);
	}

	private boolean isValidTarget(class_1297 entity) {
		if (entity == null || entity == mc.field_1724 || !(entity instanceof class_1309 living))
			return false;

		if (!living.method_5805() || living.method_29504())
			return false;

		if (entity instanceof class_1657)
			return targetPlayers.getValue();

		if (!targetMobs.getValue())
			return false;

		return !(entity instanceof class_1296) && !(entity instanceof class_6025);
	}

	private class_1297 findNearestTarget() {
		class_1297 best = null;
		double bestDistance = 16.0D;

		for (class_1297 entity : mc.field_1687.method_18112()) {
			if (!(entity instanceof class_1309 living) || entity == mc.field_1724 || !living.method_5805())
				continue;

			double distance = mc.field_1724.method_5858(entity);
			if (distance < bestDistance) {
				bestDistance = distance;
				best = entity;
			}
		}

		return best;
	}

	private int findAxeSlot() {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (WorldUtils.isAxe(stack))
				return i;
		}
		return -1;
	}

	private int findMaceSlot() {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (stack.method_31574(class_1802.field_49814))
				return i;
		}
		return -1;
	}

	private int findEnchantedMace(String enchant) {
		for (int i = 0; i < 9; i++) {
			class_1799 stack = mc.field_1724.method_31548().method_5438(i);
			if (stack.method_31574(class_1802.field_49814) && ItemUtils.hasEnchant(stack, enchant))
				return i;
		}
		return -1;
	}

	private void resetAirState() {
		airborne = false;
		apexY = -1.0D;
		shieldHandled = false;
		stage = 0;
	}

	private void resetState() {
		previousSlot = -1;
		lastAttackMs = 0L;
		pendingMaceAttack = false;
		maceTarget = null;
		pendingAxeAttack = false;
		axeTarget = null;
		resetAirState();
	}
}
