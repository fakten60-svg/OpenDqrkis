package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.AttackListener;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.MouseSimulation;
import xyz.dqrkis.utils.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class ShieldDisabler extends Module implements TickListener, AttackListener {
	private final NumberSetting hitDelay = new NumberSetting("Hit Delay", 0, 20, 0, 1);
	private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 20, 0, 1);
	private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);
	private final BooleanSetting stun = new BooleanSetting("Stun", false);
	private final BooleanSetting clickSimulate = new BooleanSetting("Click Simulation", false);
	private final BooleanSetting requireHoldAxe = new BooleanSetting("Hold Axe", false);

	int previousSlot, hitClock, switchClock;

	public ShieldDisabler() {
		super("Shield Disabler",
				"Automatically disables your opponents shield",
				-1,
				Category.COMBAT);

		addSettings(switchDelay, hitDelay, switchBack, stun, clickSimulate, requireHoldAxe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);

		hitClock = hitDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
		previousSlot = -1;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null)
			return;

		if(requireHoldAxe.getValue() && !(mc.field_1724.method_6047().method_7909() instanceof class_1743))
			return;

		if (mc.field_1765 instanceof class_3966 entityHit) {
			class_1297 entity = entityHit.method_17782();

			if (mc.field_1724.method_6115())
				return;

			if (entity instanceof class_1657 player) {
				if (WorldUtils.isShieldFacingAway(player))
					return;

				if (player.method_24518(class_1802.field_8255) && player.method_6039()) {
					if (switchClock > 0) {
						if (previousSlot == -1)
							previousSlot = mc.field_1724.method_31548().method_67532();

						switchClock--;
						return;
					}

					if (InventoryUtils.selectAxe()) {
						if (hitClock > 0) {
							hitClock--;
						} else {
							if (clickSimulate.getValue())
								MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

							WorldUtils.hitEntity(player, true);

							if (stun.getValue()) {
								if (clickSimulate.getValue())
									MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

								WorldUtils.hitEntity(player, true);
							}

							hitClock = hitDelay.getValueInt();
							switchClock = switchDelay.getValueInt();
						}
					}
				} else if (previousSlot != -1) {
					if (switchBack.getValue())
						InventoryUtils.setInvSlot(previousSlot);

					previousSlot = -1;
				}
			}
		}
	}

	@Override
	public void onAttack(AttackListener.AttackEvent event) {
		if (GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			event.cancel();
	}
}
