package xyz.dqrkis.module.modules.combat;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1294;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;

public final class AutoPot extends Module implements TickListener {
	private final NumberSetting minHealth = new NumberSetting("Min Health", 1, 20, 10, 1);
	private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 10, 0, 1);
	private final NumberSetting throwDelay = new NumberSetting("Throw Delay", 0, 10, 0, 1);
	private final BooleanSetting goToPrevSlot = new BooleanSetting("Switch Back", true);
	private final BooleanSetting lookDown = new BooleanSetting("Look Down", true);

	private int switchClock, throwClock, prevSlot;
	private float prevPitch;
	private boolean bool;

	public AutoPot() {
		super("Auto Pot",
				"Automatically throws health potions when low on health",
				-1,
				Category.COMBAT);

		addSettings(minHealth, switchDelay, throwDelay, goToPrevSlot, lookDown);
	}

	private void reset() {
		switchClock = 0;
		throwClock = 0;
		prevSlot = -1;
		prevPitch = -1;
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		reset();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1755 != null)
			return;

		if ((mc.field_1724.method_6032() <= minHealth.getValueFloat() || bool)) {

			if (bool && mc.field_1724.method_6032() >= mc.field_1724.method_6063()) {
				bool = false;
				return;
			}

			if (!InventoryUtils.isThatSplash(class_1294.field_5915.comp_349(), 1, 1, mc.field_1724.method_6047())) {
				if (switchClock < switchDelay.getValue()) {
					switchClock++;
					return;
				}

				if (goToPrevSlot.getValue() && prevSlot == -1) prevSlot = mc.field_1724.method_31548().method_67532();
				if (lookDown.getValue() && prevPitch == -1) prevPitch = mc.field_1724.method_36455();

				int potSlot = InventoryUtils.findSplash(class_1294.field_5915.comp_349(), 1, 1);

				if (potSlot != -1) {
					InventoryUtils.setInvSlot(potSlot);

					switchClock = 0;
				}
			}

			if (InventoryUtils.isThatSplash(class_1294.field_5915.comp_349(), 1, 1, mc.field_1724.method_6047())) {
				if (throwClock < throwDelay.getValue()) {
					throwClock++;
					return;
				}

				if (lookDown.getValue())
					mc.field_1724.method_36457(90F);

				class_1269 actionResult = mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
				if (actionResult.method_23665())
					mc.field_1724.method_6104(class_1268.field_5808);

				throwClock = 0;
			}
		} else if (prevSlot != -1 || prevPitch != -1) {
			InventoryUtils.setInvSlot(prevSlot);
			prevSlot = -1;

			mc.field_1724.method_36457(prevPitch);
			prevPitch = -1;
		}
	}
}
