package xyz.dqrkis.module.modules.combat;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.mixin.MinecraftClientAccessor;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.BlockUtils;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.KeyUtils;
import xyz.dqrkis.utils.MouseSimulation;
import xyz.dqrkis.utils.WorldUtils;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public final class Macro198 extends Module implements TickListener {
	private enum State { IDLE, PLACE_OBI, WAIT_OBI, PLACE_CRYSTAL, BREAK_CRYSTAL }

	private final KeybindSetting macroKey = new KeybindSetting("Macro Key", GLFW.GLFW_MOUSE_BUTTON_MIDDLE, false)
			.setDescription("Hold this button to run the macro");
	private final BooleanSetting autoBreak = new BooleanSetting("Auto Break", true)
			.setDescription("Breaks placed crystals automatically");
	private final NumberSetting placeDelay = new NumberSetting("Place Delay", 0, 20, 0, 1);
	private final NumberSetting breakDelay = new NumberSetting("Break Delay", 0, 20, 0, 1);
	private final NumberSetting placeChance = new NumberSetting("Place Chance %", 0, 100, 100, 1);
	private final NumberSetting attackChance = new NumberSetting("Attack Chance %", 0, 100, 100, 1);
	private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false);
	private final BooleanSetting airSwing = new BooleanSetting("Air Swing", false)
			.setDescription("Swings at air when no crystal is in range");
	private final NumberSetting airSwingChance = new NumberSetting("Air Swing Chance %", 0, 100, 20, 1);

	private static final int MAX_PLACES_PER_POS = 2;

	private int placeIn;
	private int breakIn;
	private State state = State.IDLE;
	private class_2338 targetPos;

	public Macro198() {
		super("Macro 198",
				"Combat macro for 1.9.8 style gameplay",
				-1,
				Category.COMBAT);
		addSettings(macroKey, autoBreak, placeDelay, breakDelay, placeChance, attackChance, clickSimulation, airSwing, airSwingChance);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null || mc.field_1761 == null)
			return;

		if (!KeyUtils.isKeyPressed(macroKey.getKey())) {
			resetState();
			return;
		}

		if (placeIn > 0)
			placeIn--;

		if (breakIn > 0)
			breakIn--;

		attackNearbyCrystals();

		State previous = state;
		for (int i = 0; i < 4 && state == previous; i++) {
			switch (state) {
				case IDLE -> scanForPlacement();
				case PLACE_OBI -> placeObsidian();
				case WAIT_OBI -> waitForObsidian();
				case PLACE_CRYSTAL -> placeCrystal();
				case BREAK_CRYSTAL -> finishCycle();
			}
			previous = state;
		}
	}

	private void resetState() {
		placeIn = 0;
		breakIn = 0;
		state = State.IDLE;
		targetPos = null;
	}

	private void scanForPlacement() {
		class_239 hit = mc.field_1724.method_5745(4.5D, 1.0F, false);
		if (!(hit instanceof class_3965 blockHit) || blockHit.method_17783() != class_239.class_240.field_1332)
			return;

		class_2338 pos = blockHit.method_17777();
		if (mc.field_1687.method_8320(pos).method_26215())
			return;

		if (mc.field_1724.method_33571().method_1022(blockHit.method_17784()) > 4.5D)
			return;

		if (blockHit.method_17780() != class_2350.field_11036)
			return;

		if (isSupport(mc.field_1687.method_8320(pos).method_26204())) {
			targetPos = pos;
			state = State.PLACE_CRYSTAL;
		} else {
			targetPos = pos.method_10084();
			state = State.PLACE_OBI;
		}
	}

	private void placeObsidian() {
		if (placeIn > 0)
			return;

		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (random.nextInt(1, 101) > placeChance.getValueInt())
			return;

		class_239 hit = mc.field_1724.method_5745(4.5D, 1.0F, false);
		if (!(hit instanceof class_3965 blockHit) || hit.method_17783() != class_239.class_240.field_1332) {
			state = State.IDLE;
			return;
		}

		if (mc.field_1724.method_33571().method_1022(blockHit.method_17784()) > 4.5D) {
			state = State.IDLE;
			return;
		}

		InventoryUtils.selectItemFromHotbar(class_1802.field_8281);
		if (clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

		WorldUtils.placeBlock(blockHit, true);
		placeIn = placeDelay.getValueInt();
		state = State.WAIT_OBI;
	}

	private void waitForObsidian() {
		if (isSupport(mc.field_1687.method_8320(targetPos).method_26204())) {
			state = State.PLACE_CRYSTAL;
		} else if (isSupport(mc.field_1687.method_8320(targetPos.method_10074()).method_26204())) {
			targetPos = targetPos.method_10074();
			state = State.PLACE_CRYSTAL;
		} else {
			state = State.IDLE;
		}
	}

	private void placeCrystal() {
		if (placeIn > 0)
			return;

		if (!isSupport(mc.field_1687.method_8320(targetPos).method_26204())) {
			state = State.IDLE;
			return;
		}

		if (!BlockUtils.canPlaceBlockClient(targetPos)) {
			state = State.BREAK_CRYSTAL;
			return;
		}

		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (random.nextInt(1, 101) > placeChance.getValueInt())
			return;

		InventoryUtils.selectItemFromHotbar(class_1802.field_8301);
		class_3965 hit = new class_3965(
				new class_243(targetPos.method_10263() + 0.5D, targetPos.method_10264() + 1.0D, targetPos.method_10260() + 0.5D),
				class_2350.field_11036, targetPos, false);

		if (clickSimulation.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);

		WorldUtils.placeBlock(hit, true);
		placeIn = placeDelay.getValueInt();
		state = State.BREAK_CRYSTAL;
	}

	private void finishCycle() {
		if (autoBreak.getValue())
			state = State.IDLE;
		else
			state = isSupport(mc.field_1687.method_8320(targetPos).method_26204()) ? State.PLACE_CRYSTAL : State.IDLE;

		if (airSwing.getValue() && breakIn == 0
				&& mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1333
				&& ThreadLocalRandom.current().nextInt(1, 101) <= attackChance.getValueInt()) {
			((MinecraftClientAccessor) mc).setAttackCooldown(10);

			if (clickSimulation.getValue())
				MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

			mc.field_1724.method_6104(class_1268.field_5808);
			breakIn = breakDelay.getValueInt();
		}
	}

	private void attackNearbyCrystals() {
		if (breakIn > 0)
			return;

		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (random.nextInt(1, 101) > attackChance.getValueInt())
			return;

		if (mc.field_1765 instanceof class_3966 entityHit
				&& entityHit.method_17782() instanceof class_1511 crystal) {
			if (clickSimulation.getValue())
				MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

			WorldUtils.hitEntity(crystal, true);
			breakIn = breakDelay.getValueInt();
			return;
		}

		for (class_1297 entity : mc.field_1687.method_18112()) {
			if (entity instanceof class_1511 && entity.method_5739(mc.field_1724) < 9.0D) {
				if (clickSimulation.getValue())
					MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

				mc.field_1761.method_2918(mc.field_1724, entity);
				mc.field_1724.method_6104(class_1268.field_5808);
				breakIn = breakDelay.getValueInt();
				return;
			}
		}
	}

	private static boolean isSupport(net.minecraft.class_2248 block) {
		return block == class_2246.field_10540 || block == class_2246.field_9987;
	}
}
