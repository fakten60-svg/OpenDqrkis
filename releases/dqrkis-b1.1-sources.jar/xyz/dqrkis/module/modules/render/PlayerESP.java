package xyz.dqrkis.module.modules.render;

import xyz.dqrkis.event.events.GameRenderListener;
import xyz.dqrkis.event.events.HudListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.ColorUtils;
import xyz.dqrkis.utils.ProjectionUtils;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.Utils;
import java.awt.*;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_7833;

public final class PlayerESP extends Module implements GameRenderListener, HudListener {
	public enum Mode {
		TwoD, ThreeD
	}

	public final ModeSetting<Mode> mode = new ModeSetting<>("Mode", Mode.ThreeD, Mode.class);
	private final NumberSetting alpha = new NumberSetting("Alpha", 0, 255, 100, 1);
	private final NumberSetting width = new NumberSetting("Line width", 1, 10, 1, 1);
	private final BooleanSetting tracers = new BooleanSetting("Tracers", false)
			.setDescription("Draws a line from your player to the other");
	private final BooleanSetting threeDOutline = new BooleanSetting("3D box outline", false);
	private final BooleanSetting twoDOutline = new BooleanSetting("2D Outline", false);

	public PlayerESP() {
		super("Player ESP",
				"Renders players through walls",
				-1,
				Category.RENDER);
		addSettings(alpha, mode, threeDOutline, twoDOutline, width, tracers);
	}

	@Override
	public void onEnable() {
		eventManager.add(GameRenderListener.class, this);
		eventManager.add(HudListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(GameRenderListener.class, this);
		eventManager.remove(HudListener.class, this);
		super.onDisable();
	}

	@Override
	public void onGameRender(GameRenderEvent event) {
		if (mc.field_1687 == null || mc.field_1724 == null) {
			return;
		}

		class_4184 camera = mc.field_1773.method_19418();
		if (camera == null) {
			return;
		}

		event.matrices.method_22903();
		class_243 cameraPos = camera.method_71156();
		event.matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
		event.matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
		event.matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

		for (class_1657 player : mc.field_1687.method_18456()) {
			if (!shouldRender(player)) {
				continue;
			}

			class_238 box = getRenderBox(player, event.delta).method_1014(0.02);
			if (mode.isMode(Mode.ThreeD)) {
				RenderUtils.renderFilledBox(
						event.matrices,
						(float) box.field_1323,
						(float) box.field_1322,
						(float) box.field_1321,
						(float) box.field_1320,
						(float) box.field_1325,
						(float) box.field_1324,
						getColor(alpha.getValueInt()).brighter()
				);
				if (threeDOutline.getValue())
					RenderUtils.renderBoxOutline(event.matrices, box, getColor(255), width.getValueInt());
			}

			if (tracers.getValue() && mc.field_1765 != null) {
				RenderUtils.renderLine(event.matrices, Utils.getMainColor(255, 1), mc.field_1765.method_17784(), player.method_30950(RenderUtils.tickProgress()));
			}
		}

		event.matrices.method_22909();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		if (!mode.isMode(Mode.TwoD) || mc.field_1687 == null || mc.field_1724 == null) {
			return;
		}

		for (class_1657 player : mc.field_1687.method_18456()) {
			if (!shouldRender(player)) {
				continue;
			}

			ScreenBounds bounds = projectBounds(getRenderBox(player, event.delta));
			if (bounds == null || !bounds.isValid()) {
				continue;
			}

			Color outlineColor = getColor(255);
			int thickness = Math.max(1, width.getValueInt());
			if (twoDOutline.getValue()) {
				Color borderColor = new Color(0, 0, 0, Math.min(255, outlineColor.getAlpha()));
				drawOutline(event.context, bounds, thickness + 1, borderColor);
			}
			drawOutline(event.context, bounds, thickness, outlineColor);
		}
	}

	private boolean shouldRender(class_1297 entity) {
		return entity instanceof class_1657 player && player != mc.field_1724 && player.method_5805();
	}

	private class_238 getRenderBox(class_1657 player, float tickDelta) {
		double x = class_3532.method_16436(tickDelta, player.field_6014, player.method_23317());
		double y = class_3532.method_16436(tickDelta, player.field_6036, player.method_23318());
		double z = class_3532.method_16436(tickDelta, player.field_5969, player.method_23321());
		return player.method_5829().method_989(x - player.method_23317(), y - player.method_23318(), z - player.method_23321());
	}

	private ScreenBounds projectBounds(class_238 box) {
		double minX = Double.POSITIVE_INFINITY;
		double minY = Double.POSITIVE_INFINITY;
		double maxX = Double.NEGATIVE_INFINITY;
		double maxY = Double.NEGATIVE_INFINITY;
		int visibleCorners = 0;

		for (double x : new double[]{box.field_1323, box.field_1320}) {
			for (double y : new double[]{box.field_1322, box.field_1325}) {
				for (double z : new double[]{box.field_1321, box.field_1324}) {
					ProjectionUtils.ProjectedPoint projected = ProjectionUtils.project(new class_243(x, y, z));
					if (projected == null) {
						continue;
					}

					visibleCorners++;
					minX = Math.min(minX, projected.x());
					minY = Math.min(minY, projected.y());
					maxX = Math.max(maxX, projected.x());
					maxY = Math.max(maxY, projected.y());
				}
			}
		}

		if (visibleCorners == 0) {
			return null;
		}

		return new ScreenBounds((int) Math.floor(minX), (int) Math.floor(minY), (int) Math.ceil(maxX), (int) Math.ceil(maxY));
	}

	private void drawOutline(class_332 context, ScreenBounds bounds, int thickness, Color color) {
		int packedColor = color.getRGB();
		context.method_25294(bounds.minX, bounds.minY, bounds.maxX, bounds.minY + thickness, packedColor);
		context.method_25294(bounds.minX, bounds.maxY - thickness, bounds.maxX, bounds.maxY, packedColor);
		context.method_25294(bounds.minX, bounds.minY + thickness, bounds.minX + thickness, bounds.maxY - thickness, packedColor);
		context.method_25294(bounds.maxX - thickness, bounds.minY + thickness, bounds.maxX, bounds.maxY - thickness, packedColor);
	}

	private Color getColor(int alpha) {
		int red = ClickGUI.red.getValueInt();
		int green = ClickGUI.green.getValueInt();
		int blue = ClickGUI.blue.getValueInt();

		if (ClickGUI.rainbow.getValue())
			return ColorUtils.getBreathingRGBColor(1, alpha);
		else
			return new Color(red, green, blue, alpha);
	}

	private record ScreenBounds(int minX, int minY, int maxX, int maxY) {
		private boolean isValid() {
			return maxX > minX && maxY > minY;
		}
	}
}
