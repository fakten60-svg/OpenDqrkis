package xyz.dqrkis.module.modules.render;

import xyz.dqrkis.event.events.GameRenderListener;
import xyz.dqrkis.event.events.PacketReceiveListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.WorldUtils;
import net.minecraft.block.entity.*;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2605;
import net.minecraft.class_2611;
import net.minecraft.class_2627;
import net.minecraft.class_2636;
import net.minecraft.class_2637;
import net.minecraft.class_2646;
import net.minecraft.class_2818;
import net.minecraft.class_3719;
import net.minecraft.class_3866;
import net.minecraft.class_4184;
import net.minecraft.class_7833;
import java.awt.*;

public final class StorageEsp extends Module implements GameRenderListener, PacketReceiveListener {
	private final NumberSetting alpha = new NumberSetting("Alpha", 1, 255, 125, 1);
	private final BooleanSetting donutBypass = new BooleanSetting("Donut Bypass", false);
	private final BooleanSetting tracers = new BooleanSetting("Tracers", false)
			.setDescription("Draws a line from your player to the storage block");

	public StorageEsp() {
		super("Storage ESP",
				"Renders storage blocks through walls",
				-1,
				Category.RENDER);
		addSettings(donutBypass, alpha, tracers);
	}

	@Override
	public void onEnable() {
		eventManager.add(PacketReceiveListener.class, this);
		eventManager.add(GameRenderListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(PacketReceiveListener.class, this);
		eventManager.remove(GameRenderListener.class, this);
		super.onDisable();
	}

	@Override
	public void onGameRender(GameRenderEvent event) {
		renderStorages(event);
	}

	private Color getColor(class_2586 blockEntity, int a) {
		if (blockEntity instanceof class_2646) {
			return new Color(200, 91, 0, a);
		} else if (blockEntity instanceof class_2595) {
			return new Color(156, 91, 0, a);
		} else if (blockEntity instanceof class_2611) {
			return new Color(117, 0, 255, a);
		} else if (blockEntity instanceof class_2636) {
			return new Color(138, 126, 166, a);
		} else if (blockEntity instanceof class_2627) {
			return new Color(134, 0, 158, a);
		} else if (blockEntity instanceof class_3866) {
			return new Color(125, 125, 125, a);
		} else if (blockEntity instanceof class_3719) {
			return new Color(255, 140, 140, a);
		} else if (blockEntity instanceof class_2605) {
			return new Color(80, 80, 255, a);
		} else return new Color(255, 255, 255, 0);
	}

	private void renderStorages(GameRenderEvent event) {
		class_4184 cam = mc.field_1773.method_19418();
		if (cam == null) {
			return;
		}

		event.matrices.method_22903();
		class_243 cameraPos = cam.method_71156();
		event.matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
		event.matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
		event.matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

		for (class_2818 chunk : WorldUtils.getLoadedChunks().toList()) {
			for (class_2338 blockPos : chunk.method_12021()) {
				class_2586 blockEntity = mc.field_1687.method_8321(blockPos);
				if (blockEntity == null) {
					continue;
				}

				RenderUtils.renderFilledBox(event.matrices, blockPos.method_10263() + 0.1F, blockPos.method_10264() + 0.05F, blockPos.method_10260() + 0.1F, blockPos.method_10263() + 0.9F, blockPos.method_10264() + 0.85F, blockPos.method_10260() + 0.9F, getColor(blockEntity, alpha.getValueInt()));

				class_243 center = new class_243(blockPos.method_10263() + 0.5, blockPos.method_10264() + 0.5, blockPos.method_10260() + 0.5);
				if (tracers.getValue() && mc.field_1765 != null) {
					RenderUtils.renderLine(
							event.matrices,
							getColor(blockEntity, 255),
							mc.field_1765.method_17784(),
							center
					);
				}
			}
		}

		event.matrices.method_22909();
	}

	@Override
	public void onPacketReceive(PacketReceiveEvent event) {
		if (donutBypass.getValue()) {
			if (event.packet instanceof class_2637) {
				event.cancel();
			}
		}
	}
}
