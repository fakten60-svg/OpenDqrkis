package xyz.dqrkis.module.modules.render;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.StringSetting;

public final class NameHider extends Module {
	private final StringSetting fakeName = new StringSetting("Fake Name", "Player");
	private final BooleanSetting hideInChat = new BooleanSetting("Hide In Chat", true);
	private final BooleanSetting hideInTab = new BooleanSetting("Hide In Tab", true);
	private final BooleanSetting hideNametag = new BooleanSetting("Hide Nametag", true);

	public NameHider() {
		super("Name Hider",
				"Hides your name everywhere",
				-1,
				Category.RENDER);
		addSettings(fakeName, hideInChat, hideInTab, hideNametag);
	}

	public static NameHider get() {
		return Dqrkis.INSTANCE.getModuleManager().getModule(NameHider.class);
	}

	public String getFakeName() {
		return fakeName.getValue();
	}

	public boolean shouldHideInChat() {
		return isEnabled() && hideInChat.getValue();
	}

	public boolean shouldHideInTab() {
		return isEnabled() && hideInTab.getValue();
	}

	public boolean shouldHideNametag() {
		return isEnabled() && hideNametag.getValue();
	}

	public String filter(String text) {
		if (!isEnabled() || mc.field_1724 == null || text == null)
			return text;

		String ownName = mc.field_1724.method_5477().getString();
		if (ownName == null || ownName.isEmpty())
			return text;

		return text.contains(ownName) ? text.replace(ownName, fakeName.getValue()) : text;
	}
}
