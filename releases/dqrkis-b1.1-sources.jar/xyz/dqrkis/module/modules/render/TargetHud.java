package xyz.dqrkis.module.modules.render;

import xyz.dqrkis.event.events.HudListener;
import xyz.dqrkis.event.events.PacketSendListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.*;
import org.joml.Matrix3x2fStack;

import java.awt.*;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_332;
import net.minecraft.class_640;
import net.minecraft.class_7532;

public final class TargetHud extends Module implements HudListener, PacketSendListener {
	private final NumberSetting xCoord = new NumberSetting("X", 0, 1920, 500, 1);
	private final NumberSetting yCoord = new NumberSetting("Y", 0, 1080, 500, 1);
	private final BooleanSetting hudTimeout = new BooleanSetting("Timeout", true)
			.setDescription("Target hud will disappear after 10 seconds");
	private long lastAttackTime = 0;
	public static float animation;
	private static final long timeout = 10000;

	public TargetHud() {
		super("Target HUD",
				"Gives you information about the enemy player",
				-1,
				Category.RENDER);
		addSettings(xCoord, yCoord, hudTimeout);
	}

	@Override
	public void onEnable() {
		eventManager.add(HudListener.class, this);
		eventManager.add(PacketSendListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		eventManager.remove(PacketSendListener.class, this);
		super.onDisable();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		class_332 context = event.context;

		int x = xCoord.getValueInt();
		int y = yCoord.getValueInt();

		RenderUtils.unscaledProjection(context);
		if ((!hudTimeout.getValue() || (System.currentTimeMillis() - lastAttackTime <= timeout)) &&
				mc.field_1724.method_6052() != null && mc.field_1724.method_6052() instanceof class_1657 player && player.method_5805()) {
			animation = RenderUtils.fast(animation, mc.field_1724.method_6052() instanceof class_1657 player1 && player1.method_5805() ? 0 : 1, 15f);

			class_640 entry = mc.method_1562().method_2871(player.method_5667());
			Matrix3x2fStack matrices = context.method_51448();
			matrices.pushMatrix();
			matrices.scaleAround(Math.max(0.0f, 1.0f - animation), 1.0f, x + 170.0f, y + 100.0f);

		RenderUtils.renderRoundedQuad(context, new Color(0, 0, 0, 175), x, y, x + 340, y + 200, 5, 5, 5, 5, 10);
		RenderUtils.renderRoundedQuad(context, Utils.getMainColor(255, 1), x, y + 27, x + 340, y + 29, 0, 0, 0, 0, 10);

			TextRenderer.drawString(player.method_5477().getString() + " - " + MathUtils.roundToDecimal(player.method_5739(mc.field_1724), 0.5) + " blocks", context, x + 23, y + 5, Color.WHITE.getRGB());

			if (entry == null) {
				int charOff1 = x + 5;
				CharSequence chars = "Type: Bot";

				TextRenderer.drawString(chars, context, charOff1, y + 35, new Color(255, 80, 80, 255).getRGB());

				matrices.popMatrix();
				RenderUtils.scaledProjection(context);
				return;
			} else {
				int charOff1 = x + 5;
				CharSequence chars = "Type: Player";

				TextRenderer.drawString(chars, context, charOff1, y + 35, Color.white.getRGB());
			}

			TextRenderer.drawString("Health: " + Math.round((player.method_6032() + player.method_6067())), context, x + 5, y + 65, Color.GREEN.getRGB());
			context.method_25294(x, y + 200, x + 4, (y + 200) - Math.min(Math.round((player.method_6032() + player.method_6067()) * 5), 171), Color.GREEN.darker().getRGB());
			//RenderUtils.renderRoundedOutline(context, Color.green, x, y + 200, x, (y + 200) - Math.min(Math.round((player.getHealth() + player.getAbsorptionAmount()) * 5), 174), 0, 0, 0, 0, 3, 30);

			TextRenderer.drawString("Invisible: " + (player.method_5767() ? "Yes" : "No"), context, x + 5, y + 95, Color.WHITE.getRGB());

			TextRenderer.drawString("Ping: " + entry.method_2959(), context, x + 5, y + 125, Color.WHITE.getRGB());

			class_7532.method_52722(context, entry.method_52810(), x + 3, y + 3, 20);

			if (player.field_6235 != 0) {
				int charOff1 = x + 125;
				CharSequence chars = ("Damage Tick: " + player.field_6235);

				TextRenderer.drawString(chars, context, charOff1, y + 65, Color.WHITE.getRGB());
				//TextRenderer.drawString("Damage Tick: " + player.hurtTime, context, x + 125, y + 65, Color.WHITE.getRGB());
				context.method_25294(x + 125, y + 80, (x + 125) + (player.field_6235 * 15), y + 83, getDamageTickColor(player.field_6235).getRGB());
			}
			matrices.popMatrix();
		} else {
			animation = RenderUtils.fast(animation, 1, 15f);
		}
		RenderUtils.scaledProjection(context);
	}

	private Color getDamageTickColor(int hurtTime) {
		return switch (hurtTime) {
			case 0 -> null;
			case 10 -> new Color(255, 0, 0, 255);
			case 9 -> new Color(255, 50, 0, 255);
			case 8 -> new Color(255, 100, 0, 255);
			case 7 -> new Color(255, 150, 0, 255);
			case 6 -> new Color(255, 255, 0, 255);
			case 5 -> new Color(200, 255, 0, 255);
			case 4 -> new Color(175, 255, 0, 255);
			case 3 -> new Color(100, 255, 0, 255);
			case 2 -> new Color(50, 255, 0, 255);
			case 1 -> new Color(0, 255, 0, 255);
			default -> throw new IllegalStateException("uv" + hurtTime);
		};
	}

	@Override
	public void onPacketSend(PacketSendListener.PacketSendEvent event) {
		if (event.packet instanceof class_2824 packet) {
			packet.method_34209(new class_2824.class_5908() {
				@Override
				public void method_34219(class_1268 hand) {

				}

				@Override
				public void method_34220(class_1268 hand, class_243 pos) {

				}

				@Override
				public void method_34218() {
					if (mc.field_1692 instanceof class_1657) {
						lastAttackTime = System.currentTimeMillis();
					}
				}
			});
		}
	}
}
