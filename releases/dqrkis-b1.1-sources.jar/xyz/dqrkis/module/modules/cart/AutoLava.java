package xyz.dqrkis.module.modules.cart;

import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.KeyUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class AutoLava extends Module implements TickListener {
	private final KeybindSetting activateKey = new KeybindSetting("Activate Key", GLFW.GLFW_KEY_R, false);
	private final NumberSetting delay = new NumberSetting("Delay", 0, 10, 0, 1);

	private class_2338 targetPos;
	private int state;
	private int delayTicks;
	private boolean keyWasPressed;

	public AutoLava() {
		super("Auto Lava",
				"Places lava at player feet",
				-1,
				Category.CART);
		addSettings(activateKey, delay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		resetState();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null)
			return;

		boolean pressed = activateKey.getKey() != -1 && KeyUtils.isKeyPressed(activateKey.getKey());

		if (pressed && !keyWasPressed && state == 0) {
			if (!InventoryUtils.hasItemInHotbar(item -> item == class_1802.field_8187)) {
				keyWasPressed = pressed;
				return;
			}

			if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1331) {
				class_1297 entity = ((class_3966) mc.field_1765).method_17782();
				if (entity instanceof class_1657 player) {
					targetPos = predictLandingPos(player);
					if (targetPos != null && isValidPlacement(targetPos))
						state = 1;
					else
						targetPos = null;
				}
			}
		}

		keyWasPressed = pressed;

		if (state != 0) {
			if (delayTicks > 0) {
				delayTicks--;
			} else {
				mc.execute(this::step);
			}
		}
	}

	private void step() {
		if (mc.field_1724 == null || mc.field_1687 == null)
			return;

		switch (state) {
			case 1 -> {
				if (InventoryUtils.selectItemFromHotbar(class_1802.field_8187)) {
					state = 2;
					delayTicks = 1;
				} else {
					resetState();
				}
			}
			case 2 -> {
				if (placeLava()) {
					state = 3;
				} else {
					resetState();
				}
			}
			case 3 -> {
				pickLavaBackUp();
				resetState();
			}
		}
	}

	private class_2338 predictLandingPos(class_1657 player) {
		class_243 pos = player.method_73189();
		class_243 velocity = player.method_18798();

		if (player.method_24828() && velocity.method_37267() < 0.1)
			return new class_2338((int) Math.floor(pos.field_1352), (int) Math.floor(pos.field_1351), (int) Math.floor(pos.field_1350));

		double x = pos.field_1352, y = pos.field_1351, z = pos.field_1350;
		double vx = velocity.field_1352, vy = velocity.field_1351, vz = velocity.field_1350;

		for (int i = 0; i < 20; i++) {
			vy = (vy - 0.08D) * 0.98D;
			vx *= 0.91D;
			vz *= 0.91D;
			x += vx;
			y += vy;
			z += vz;

			class_2338 below = new class_2338((int) Math.floor(x), (int) Math.floor(y) - 1, (int) Math.floor(z));
			if (!mc.field_1687.method_8320(below).method_26215())
				return new class_2338((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
		}

		return new class_2338((int) Math.floor(pos.field_1352), (int) Math.floor(pos.field_1351), (int) Math.floor(pos.field_1350));
	}

	private boolean isValidPlacement(class_2338 pos) {
		class_2338 below = pos.method_10074();
		if (!mc.field_1687.method_8320(below).method_26212(mc.field_1687, below))
			return false;
		if (!mc.field_1687.method_8320(pos).method_45474() && !mc.field_1687.method_8320(pos).method_26215())
			return false;
		return mc.field_1724.method_73189().method_1028(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D) < 25.0D;
	}

	private boolean placeLava() {
		if (targetPos == null || mc.field_1724 == null || mc.field_1761 == null)
			return false;

		if (!mc.field_1724.method_6047().method_31574(class_1802.field_8187))
			return false;

		lookAt(targetPos.method_10074().method_46558().method_1031(0.0D, 0.5D, 0.0D));
		class_1269 result = mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
		if (result.method_23665()) {
			mc.field_1724.method_6104(class_1268.field_5808);
			return true;
		}
		return false;
	}

	private void pickLavaBackUp() {
		if (targetPos == null || mc.field_1724 == null || mc.field_1761 == null)
			return;

		if (!InventoryUtils.hasItemInHotbar(item -> item == class_1802.field_8550))
			return;

		lookAt(targetPos.method_46558());
		class_1269 result = mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
		if (result.method_23665())
			mc.field_1724.method_6104(class_1268.field_5808);
	}

	private void lookAt(class_243 target) {
		class_243 delta = target.method_1020(mc.field_1724.method_33571());
		double horizontal = delta.method_37267();
		mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350)));
		mc.field_1724.method_36457((float) (-Math.toDegrees(Math.atan2(delta.field_1351, horizontal))));
	}

	private void resetState() {
		targetPos = null;
		state = 0;
		delayTicks = 0;
		keyWasPressed = false;
	}
}
