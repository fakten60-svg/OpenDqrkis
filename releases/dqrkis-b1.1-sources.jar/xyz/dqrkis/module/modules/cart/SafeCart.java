package xyz.dqrkis.module.modules.cart;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1753;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.KeyUtils;

public final class SafeCart extends Module implements TickListener {
	private static final int STATE_PLACE_RAIL = 0;
	private static final int STATE_RAIL_DELAY = 1;
	private static final int STATE_PLACE_CART = 2;
	private static final int STATE_CART_DELAY = 3;
	private static final int STATE_PLACE_LOG = 4;
	private static final int STATE_LOG_DELAY = 5;
	private static final int STATE_START_CHARGE = 6;
	private static final int STATE_CHARGING = 7;

	private final KeybindSetting activateKey = new KeybindSetting("Activate Key", 1, false)
			.setDescription("Hold this button to run the macro");
	private final NumberSetting delay = new NumberSetting("Delay", 0, 10, 0, 1);
	private final NumberSetting bowCharge = new NumberSetting("Bow Charge", 3, 20, 8, 1);

	private class_2338 railPos;
	private class_2338 logPos;
	private int state = STATE_PLACE_RAIL;
	private int delayTicks;
	private int chargeTicks;

	public SafeCart() {
		super("Safe Cart",
				"Places rail, minecart, and oak log",
				-1,
				Category.CART);
		addSettings(activateKey, delay, bowCharge);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		resetState();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		if (mc.field_1690 != null) {
			mc.field_1690.field_1904.method_23481(false);
			if (mc.field_1724 != null && mc.field_1761 != null)
				mc.field_1761.method_2897(mc.field_1724);
		}
		resetState();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null)
			return;

		boolean pressed = activateKey.getKey() != -1 && KeyUtils.isKeyPressed(activateKey.getKey());

		if (!pressed && state < STATE_START_CHARGE) {
			resetState();
			return;
		}

		if (delayTicks > 0) {
			delayTicks--;
			return;
		}

		mc.execute(this::step);
	}

	private void step() {
		if (mc.field_1724 == null || mc.field_1687 == null)
			return;

		int delayValue = delay.getValueInt();

		switch (state) {
			case STATE_PLACE_RAIL -> {
				if (tryPlaceRail()) {
					if (delayValue > 0) {
						state = STATE_RAIL_DELAY;
						delayTicks = delayValue;
					} else {
						state = STATE_PLACE_CART;
					}
				}
			}
			case STATE_RAIL_DELAY -> state = STATE_PLACE_CART;
			case STATE_PLACE_CART -> {
				if (tryPlaceMinecart()) {
					if (delayValue > 0) {
						state = STATE_CART_DELAY;
						delayTicks = delayValue;
					} else {
						state = STATE_PLACE_LOG;
					}
				} else {
					resetState();
				}
			}
			case STATE_CART_DELAY -> state = STATE_PLACE_LOG;
			case STATE_PLACE_LOG -> {
				if (tryPlaceLog()) {
					if (delayValue > 0) {
						state = STATE_LOG_DELAY;
						delayTicks = delayValue;
					} else {
						state = STATE_START_CHARGE;
					}
				} else {
					resetState();
				}
			}
			case STATE_LOG_DELAY -> state = STATE_START_CHARGE;
			case STATE_START_CHARGE -> {
				if (selectBow()) {
					state = STATE_CHARGING;
					chargeTicks = 0;
					pressUse();
					aimAtCart();
				} else {
					resetState();
				}
			}
			case STATE_CHARGING -> {
				aimAtCart();
				chargeTicks++;
				if (chargeTicks >= bowCharge.getValueInt()) {
					releaseUse();
					resetState();
				}
			}
		}
	}

	private boolean tryPlaceRail() {
		if (!(mc.field_1765 instanceof class_3965 blockHit) || mc.field_1765.method_17783() != class_239.class_240.field_1332)
			return false;

		class_2338 hitPos = blockHit.method_17777();
		class_2338 placePos = hitPos.method_10093(blockHit.method_17780());

		if (logPos != null && placePos.equals(logPos))
			return false;

		if (mc.field_1687.method_8320(hitPos).method_27852(class_2246.field_10431) || mc.field_1687.method_8320(placePos).method_27852(class_2246.field_10431))
			return false;

		if (isRail(placePos)) {
			railPos = placePos;
			return true;
		}

		if (!mc.field_1687.method_8320(placePos).method_45474())
			return false;

		if (!InventoryUtils.hasItemInHotbar(item ->
				item == class_1802.field_8129 || item == class_1802.field_8848
						|| item == class_1802.field_8211 || item == class_1802.field_8655))
			return false;

		class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, blockHit);
		if (result.method_23665()) {
			mc.field_1724.method_6104(class_1268.field_5808);
			railPos = placePos;
			return true;
		}
		return false;
	}

	private boolean tryPlaceMinecart() {
		if (railPos == null || !isRail(railPos))
			return false;

		if (!InventoryUtils.selectItemFromHotbar(class_1802.field_8069))
			return false;

		class_3965 hit = new class_3965(railPos.method_46558(), class_2350.field_11036, railPos, false);
		class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
		if (result.method_23665()) {
			mc.field_1724.method_6104(class_1268.field_5808);
			return true;
		}
		return false;
	}

	private boolean tryPlaceLog() {
		if (railPos == null || mc.field_1724 == null)
			return false;

		class_243 playerPos = mc.field_1724.method_73189();
		class_243 center = railPos.method_46558();
		class_243 away = center.method_1020(playerPos).method_1029();
		double distance = playerPos.method_1022(center);
		class_2338 logTarget = new class_2338(
				(int) Math.floor(playerPos.field_1352 + away.field_1352 * Math.min(distance * 0.6D, 3.0D)),
				railPos.method_10264(),
				(int) Math.floor(playerPos.field_1350 + away.field_1350 * Math.min(distance * 0.6D, 3.0D)));

		if (logTarget.equals(railPos))
			logTarget = railPos.method_10069(-(int) Math.round(away.field_1352), 0, -(int) Math.round(away.field_1350));

		class_2338 belowLog = logTarget.method_10074();
		boolean foundSupport = mc.field_1687.method_8320(belowLog).method_26212(mc.field_1687, belowLog);

		if (!foundSupport) {
			for (class_2350 direction : class_2350.class_2353.field_11062) {
				class_2338 candidate = railPos.method_10093(direction);
				class_2338 candidateBelow = candidate.method_10074();
				if (mc.field_1687.method_8320(candidateBelow).method_26212(mc.field_1687, candidateBelow)
						&& (mc.field_1687.method_8320(candidate).method_26215() || mc.field_1687.method_8320(candidate).method_45474())) {
					logTarget = candidate;
					belowLog = candidateBelow;
					foundSupport = true;
					break;
				}
			}

			if (!foundSupport)
				return false;
		}

		if (!mc.field_1687.method_8320(logTarget).method_26215() && !mc.field_1687.method_8320(logTarget).method_45474())
			return false;

		if (!InventoryUtils.selectItemFromHotbar(class_1802.field_8583))
			return false;

		class_3965 hit = new class_3965(belowLog.method_46558().method_1031(0.0D, 0.5D, 0.0D), class_2350.field_11036, belowLog, false);
		class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
		if (result.method_23665()) {
			mc.field_1724.method_6104(class_1268.field_5808);
			logPos = logTarget;
			return true;
		}
		return false;
	}

	private boolean selectBow() {
		for (int i = 0; i < 9; i++) {
			if (mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1753) {
				InventoryUtils.setInvSlot(i);
				return true;
			}
		}
		return false;
	}

	private void aimAtCart() {
		if (railPos == null || mc.field_1724 == null)
			return;

		class_243 target = railPos.method_46558().method_1031(0.0D, 1.1D, 0.0D);
		class_243 delta = target.method_1020(mc.field_1724.method_33571());
		double horizontal = delta.method_37267();
		mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-delta.field_1352, delta.field_1350)));
		mc.field_1724.method_36457((float) (-Math.toDegrees(Math.atan2(delta.field_1351, horizontal))));
	}

	private void pressUse() {
		if (mc.field_1724 != null)
			mc.field_1690.field_1904.method_23481(true);
	}

	private void releaseUse() {
		if (mc.field_1724 != null) {
			mc.field_1690.field_1904.method_23481(false);
			if (mc.field_1761 != null)
				mc.field_1761.method_2897(mc.field_1724);
		}
	}

	private boolean isRail(class_2338 pos) {
		var state = mc.field_1687.method_8320(pos);
		return state.method_27852(class_2246.field_10167) || state.method_27852(class_2246.field_10425)
				|| state.method_27852(class_2246.field_10025) || state.method_27852(class_2246.field_10546);
	}

	private void resetState() {
		state = STATE_PLACE_RAIL;
		delayTicks = 0;
		railPos = null;
		logPos = null;
		chargeTicks = 0;
	}
}
