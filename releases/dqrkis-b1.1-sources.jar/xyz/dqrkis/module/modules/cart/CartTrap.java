package xyz.dqrkis.module.modules.cart;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1753;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import xyz.dqrkis.event.events.TickListener;
import xyz.dqrkis.module.Category;
import xyz.dqrkis.module.Module;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.KeybindSetting;
import xyz.dqrkis.module.setting.ModeSetting;
import xyz.dqrkis.module.setting.NumberSetting;
import xyz.dqrkis.utils.InventoryUtils;
import xyz.dqrkis.utils.KeyUtils;

public final class CartTrap extends Module implements TickListener {
    public enum Weapon { BOW, CROSSBOW }
    private final KeybindSetting activateKey = new KeybindSetting("Activate Key", 82, false);
    private final NumberSetting delay = new NumberSetting("Delay", 0, 10, 0, 1);
    private final BooleanSetting autoShoot = new BooleanSetting("Auto Shoot", false);
    private final ModeSetting<Weapon> weapon = new ModeSetting<>("Weapon", Weapon.BOW, Weapon.class);
    private final NumberSetting bowCharge = new NumberSetting("Bow Charge", 3, 20, 8, 1);
    private class_2338 railPos; private int state; private int delayTicks; private int chargeTicks;
    public CartTrap() {
        super("Cart Trap", "Traps players with cart", -1, Category.CART);
        addSettings(activateKey, delay, autoShoot, weapon, bowCharge);
    }
    @Override public void onEnable() { eventManager.add(TickListener.class, this); state=0; delayTicks=0; chargeTicks=0; railPos=null; super.onEnable(); }
    @Override public void onDisable() { eventManager.remove(TickListener.class, this); if(mc.field_1690!=null){mc.field_1690.field_1904.method_23481(false);} railPos=null; super.onDisable(); }
    @Override public void onTick() {
        if(mc.field_1724==null||mc.field_1687==null||mc.field_1755!=null) return;
        boolean pressed = KeyUtils.isKeyPressed(activateKey.getKey());
        if(!pressed && state<4){ state=0; delayTicks=0; return; }
        if(delayTicks>0){ delayTicks--; return; }
        mc.execute(this::step);
    }
    private void step(){
        int d=delay.getValueInt();
        switch(state){
            case 0->{ if(tryPlaceRail()){ if(d>0){state=1;delayTicks=d;} else state=2; } }
            case 1-> state=2;
            case 2->{ if(tryPlaceCart()){ if(d>0){state=3;delayTicks=d;} else state=autoShoot.getValue()?4:0; } else state=0; }
            case 3-> state=autoShoot.getValue()?4:0;
            case 4->{ if(selectWeapon()){ state=5; chargeTicks=0; mc.field_1690.field_1904.method_23481(true); aimAtCart(); } else state=0; }
            case 5->{ aimAtCart(); if(++chargeTicks>=bowCharge.getValueInt()){ mc.field_1690.field_1904.method_23481(false); if(mc.field_1761!=null) mc.field_1761.method_2897(mc.field_1724); state=0; } }
        }
    }
    private boolean tryPlaceRail(){
        if(!(mc.field_1765 instanceof class_3965 hit) || hit.method_17783()!=class_239.class_240.field_1332) return false;
        class_2338 place=hit.method_17777().method_10093(hit.method_17780());
        if(mc.field_1687.method_8320(place).method_27852(class_2246.field_10167)||mc.field_1687.method_8320(place).method_27852(class_2246.field_10425)||mc.field_1687.method_8320(place).method_27852(class_2246.field_10025)||mc.field_1687.method_8320(place).method_27852(class_2246.field_10546)){ railPos=place; return true; }
        if(!mc.field_1687.method_8320(place).method_45474()) return false;
        if(!InventoryUtils.hasItemInHotbar(i->i==class_1802.field_8129||i==class_1802.field_8848||i==class_1802.field_8211||i==class_1802.field_8655)) return false;
        class_1269 r=mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        if(r.method_23665()){ mc.field_1724.method_6104(class_1268.field_5808); railPos=place; return true; }
        return false;
    }
    private boolean tryPlaceCart(){
        if(railPos==null) return false;
        if(!InventoryUtils.selectItemFromHotbar(class_1802.field_8069) && !InventoryUtils.selectItemFromHotbar(class_1802.field_8045) && !InventoryUtils.selectItemFromHotbar(class_1802.field_8388)) return false;
        class_3965 hit=new class_3965(railPos.method_46558(), class_2350.field_11036, railPos, false);
        class_1269 r=mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        if(r.method_23665()){ mc.field_1724.method_6104(class_1268.field_5808); return true; }
        return false;
    }
    private boolean selectWeapon(){
        if(weapon.getMode()==Weapon.BOW) return selectBow();
        for(int i=0;i<9;i++){ var s=mc.field_1724.method_31548().method_5438(i); if(s.method_7909() instanceof net.minecraft.class_1764){ var comp=s.method_58694(net.minecraft.class_9334.field_49649); if(comp!=null && !comp.method_57442()){ InventoryUtils.setInvSlot(i); return true; } } }
        return selectBow();
    }
    private boolean selectBow(){
        for(int i=0;i<9;i++) if(mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1753){ InventoryUtils.setInvSlot(i); return true; }
        return false;
    }
    private void aimAtCart(){
        if(railPos==null) return;
        class_243 t=railPos.method_46558().method_1031(0,1.1,0); class_243 d=t.method_1020(mc.field_1724.method_33571()).method_1029();
        mc.field_1724.method_36456((float)Math.toDegrees(Math.atan2(-d.field_1352,d.field_1350))); mc.field_1724.method_36457((float)(-Math.toDegrees(Math.asin(d.field_1351))));
    }
}
