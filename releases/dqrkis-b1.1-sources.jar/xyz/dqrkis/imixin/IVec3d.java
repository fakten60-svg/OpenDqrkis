package xyz.dqrkis.imixin;

import net.minecraft.class_2382;
import org.joml.Vector3d;

public interface IVec3d {
	void set(double x, double y, double z);

	default void set(class_2382 vec) {
		set(vec.method_10263(), vec.method_10264(), vec.method_10260());
	}

	default void set(Vector3d vec) {
		set(vec.x, vec.y, vec.z);
	}

	void setXZ(double x, double z);

	void setY(double y);
}
