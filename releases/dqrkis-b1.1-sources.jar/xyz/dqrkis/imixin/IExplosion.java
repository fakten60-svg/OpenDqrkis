package xyz.dqrkis.imixin;

import net.minecraft.class_243;

public interface IExplosion {
	void set(class_243 pos, float power, boolean createFire);
}
