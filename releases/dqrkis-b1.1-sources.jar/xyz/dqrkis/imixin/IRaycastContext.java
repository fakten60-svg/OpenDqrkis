package xyz.dqrkis.imixin;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3959;

public interface IRaycastContext {
	void set(class_243 start, class_243 end, class_3959.class_3960 shapeType, class_3959.class_242 fluidHandling, class_1297 entity);
}
