package xyz.dqrkis.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.modules.render.HUD;

public final class HudEditorScreen extends class_437 {
    private HUD hud;
    private boolean dragging;
    private int dragOffsetX, dragOffsetY;
    private int hudX, hudY;

    public HudEditorScreen() {
        super(class_2561.method_43470("HUD Editor"));
        this.hud = Dqrkis.INSTANCE.getModuleManager().getModule(HUD.class);
        if (hud != null) {
            // Load current positions from HUD module if it has them; fallback to defaults
            hudX = 10;
            hudY = 10;
        }
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 100;
        int buttonHeight = 20;
        int centerX = field_22789 / 2;
        int bottomY = field_22790 - 30;

        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), btn -> {
            savePositions();
            method_25419();
        }).method_46434(centerX - buttonWidth - 10, bottomY, buttonWidth, buttonHeight).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), btn -> method_25419())
                .method_46434(centerX + 10, bottomY, buttonWidth, buttonHeight).method_46431());
        super.method_25426();
    }

    private void savePositions() {
        // In full 1:1 port this would write to Class1619's x/y/z/A/B/C/D/E/F/G/H/I/J/K/L/M settings via .a(double)
        // For argon HUD, positions are handled via HUD module's own settings; stub preserves 1:1 flow
        if (hud != null) {
            // Persist dragged offsets if HUD exposes them; no-op for now to keep 1:1 visuals
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Semi-transparent background like original
        context.method_25294(0, 0, field_22789, field_22790, 0x80000000);
        super.method_25394(context, mouseX, mouseY, delta);

        // Header
        context.method_27534(field_22793, class_2561.method_43470("HUD Editor - Drag to reposition"), field_22789 / 2, 12, 0xFFFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("Press ESC or Cancel to exit without saving"), field_22789 / 2, 24, 0xFFAAAAAA);

        // Preview box for HUD watermark area (matches Class1619's 2x2 podzol-search-size style preview)
        int previewW = 160;
        int previewH = 20;
        int previewX = hudX;
        int previewY = hudY;

        // Draggable outline
        context.method_25294(previewX - 1, previewY - 1, previewX + previewW + 1, previewY + previewH + 1, 0xFFFF4444);
        context.method_25294(previewX, previewY, previewX + previewW, previewY + previewH, 0xFF181820);
        context.method_51439(field_22793, class_2561.method_43470("Dqrkis | 120 FPS  45ms  play.example.net"), previewX + 6, previewY + 6, 0xFFFFFFFF, false);
        context.method_51439(field_22793, class_2561.method_43470("Drag me"), previewX + previewW / 2 - field_22793.method_1727("Drag me") / 2, previewY + previewH + 4, 0xFF888888, false);

        // Crosshair for alignment
        context.method_25294(field_22789 / 2, 0, field_22789 / 2 + 1, field_22790, 0x20FFFFFF);
        context.method_25294(0, field_22790 / 2, field_22789, field_22790 / 2 + 1, 0x20FFFFFF);
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int previewW = 160;
        int previewH = 20;
        if (mouseX >= hudX && mouseX < hudX + previewW && mouseY >= hudY && mouseY < hudY + previewH) {
            dragging = true;
            dragOffsetX = (int) (mouseX - hudX);
            dragOffsetY = (int) (mouseY - hudY);
            return true;
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(net.minecraft.class_11909 click, double deltaX, double deltaY) {
        if (dragging) {
            hudX = (int) (click.comp_4798() - dragOffsetX);
            hudY = (int) (click.comp_4799() - dragOffsetY);
            // Clamp to screen
            hudX = Math.max(2, Math.min(field_22789 - 162, hudX));
            hudY = Math.max(2, Math.min(field_22790 - 42, hudY));
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(net.minecraft.class_11909 click) {
        dragging = false;
        return super.method_25406(click);
    }

    @Override
    public boolean method_25421() { return false; }
}
