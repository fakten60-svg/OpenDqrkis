package xyz.dqrkis.gui.components.settings;

import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.setting.BooleanSetting;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.utils.ColorUtils;
import xyz.dqrkis.utils.TextRenderer;
import xyz.dqrkis.utils.Utils;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import net.minecraft.class_332;

public final class CheckBox extends RenderableSetting {
	private final BooleanSetting setting;
	private Color currentAlpha;

	public CheckBox(ModuleButton parent, Setting<?> setting, int offset) {
		super(parent, setting, offset);
		this.setting = (BooleanSetting) setting;
	}

	@Override
	public void render(class_332 context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		int nameOffset = parentX() + 31;
		CharSequence chars = setting.getName();

		TextRenderer.drawString(chars, context, nameOffset, (parentY() + parentOffset() + offset) + 9, new Color(245, 245, 245, 255).getRGB());

		context.method_25296((parentX() + 5), (parentY() + parentOffset() + offset) + 5, (parentX() + 25), (parentY() + parentOffset() + offset + parentHeight()) - 5, Utils.getMainColor(255, parent.settings.indexOf(this)).getRGB(), Utils.getMainColor(255, parent.settings.indexOf(this) + 1).getRGB());
		context.method_25294((parentX() + 7), (parentY() + parentOffset() + offset) + 7, (parentX() + 23), (parentY() + parentOffset() + offset + parentHeight()) - 7, Color.darkGray.getRGB());
		context.method_25296((parentX() + 9), (parentY() + parentOffset() + offset) + 9, (parentX() + 21), (parentY() + parentOffset() + offset + parentHeight()) - 9, setting.getValue() ? Utils.getMainColor(255, parent.settings.indexOf(this)).getRGB() : Color.darkGray.getRGB(), setting.getValue() ? Utils.getMainColor(255, parent.settings.indexOf(this) + 1).getRGB() : Color.darkGray.getRGB());

		if (!parent.parent.dragging) {
			int toHoverAlpha = isHovered(mouseX, mouseY) ? 15 : 0;

			if (currentAlpha == null)
				currentAlpha = new Color(255, 255, 255, toHoverAlpha);
			else currentAlpha = new Color(255, 255, 255, currentAlpha.getAlpha());

			if (currentAlpha.getAlpha() != toHoverAlpha)
				currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, currentAlpha);

			context.method_25294(parentX(), parentY() + parentOffset() + offset, parentX() + parentWidth(), parentY() + parentOffset() + offset + parentHeight(), currentAlpha.getRGB());
		}
	}

	@Override
	public void keyPressed(int keyCode, int scanCode, int modifiers) {
		if(mouseOver && parent.extended) {
			if(keyCode == GLFW.GLFW_KEY_BACKSPACE)
				setting.setValue(setting.getOriginalValue());
		}

		super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void mouseClicked(double mouseX, double mouseY, int button) {
		if (isHovered(mouseX, mouseY) && button == GLFW.GLFW_MOUSE_BUTTON_LEFT)
			setting.toggle();

		super.mouseClicked(mouseX, mouseY, button);
	}
}
