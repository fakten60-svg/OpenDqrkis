package xyz.dqrkis.gui.components.settings;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.modules.client.ClickGUI;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.module.setting.StringSetting;
import xyz.dqrkis.utils.*;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class StringBox extends RenderableSetting {
    private final StringSetting setting;
    private Color currentAlpha;

    public StringBox(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (StringSetting) setting;
    }

    @Override
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        TextRenderer.drawString(setting.getName() + ": " + (setting.getValue().length() <= 9 ? setting.getValue() : (setting.getValue().substring(0, 9) + "...")), context, parentX() + 9 ,(parentY() + parentOffset() + offset) + 9, new Color(245, 245, 245, 255).getRGB());

        if (!parent.parent.dragging) {
            int toHoverAlpha = isHovered(mouseX, mouseY) ? 15 : 0;

            if (currentAlpha == null)
                currentAlpha = new Color(255, 255, 255, toHoverAlpha);
            else currentAlpha = new Color(255, 255, 255, currentAlpha.getAlpha());

            if (currentAlpha.getAlpha() != toHoverAlpha)
                currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, currentAlpha);

            context.method_25294(parentX(), parentY() + parentOffset() + offset, parentX() + parentWidth(), parentY() + parentOffset() + offset + parentHeight(), currentAlpha.getRGB());
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if(isHovered(mouseX, mouseY) && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            mc.method_1507(new class_437(class_2561.method_43473()) {
                private String content = setting.getValue();

                @Override
                public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
                    RenderUtils.unscaledProjection(context);
                    mouseX *= (int) class_310.method_1551().method_22683().method_4495();
                    mouseY *= (int) class_310.method_1551().method_22683().method_4495();
                    super.method_25394(context, mouseX, mouseY, delta);

                    context.method_25294(0, 0, mc.method_22683().method_4480(), mc.method_22683().method_4507(), new Color(0, 0, 0, ClickGUI.background.getValue() ? 200 : 0).getRGB());

                    int screenMidX = mc.method_22683().method_4480() / 2;
                    int screenMidY = mc.method_22683().method_4507() / 2;

                    int contentWidth = Math.max(TextRenderer.getWidth(content), 600);
                    int width = contentWidth + 30;

                    int startX = screenMidX - (width / 2);
                    int startY = screenMidY - 30;

                    RenderUtils.renderRoundedQuad(context, new Color(0, 0, 0, ClickGUI.alphaWindow.getValueInt()), startX, startY, startX + width, screenMidY + 30, 5, 5, 0, 0, 20);
                    TextRenderer.drawCenteredString(setting.getName(), context, screenMidX, startY + 10, new Color(245, 245, 245, 255).getRGB());
                    context.method_25294(startX, screenMidY, startX + width, screenMidY + 30, new Color(0, 0, 0, 120).getRGB());

                    RenderUtils.renderRoundedOutline(context, new Color(50, 50, 50, 255), startX + 10, screenMidY + 5, startX + (width - 10), screenMidY + 25, 5, 5, 5, 5, 2, 20);

                    TextRenderer.drawString(content, context, startX + 15, screenMidY + 8, new Color(245, 245, 245, 255).getRGB());
                    context.method_25294(startX, screenMidY, startX + width, screenMidY + 1, Utils.getMainColor(255, 1).getRGB());

                    RenderUtils.scaledProjection(context);
                }

                @Override
                public boolean method_25404(class_11908 keyInput) {
                    int keyCode = keyInput.comp_4795();
                    int modifiers = keyInput.comp_4797();

                    if(keyCode == GLFW.GLFW_KEY_ESCAPE) {
                        setting.setValue(content.strip());
                        mc.method_1507(Dqrkis.INSTANCE.clickGui);
                        return true;
                    }

                    if(isPasteShortcut(keyInput)) {
                        content += mc.field_1774.method_1460();
                        return true;
                    }

                    if(isCopyShortcut(keyInput)) {
                        mc.field_1774.method_1455(content);
                        return true;
                    }

                    if(keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                        if(!content.isEmpty()) {
                            content = content.substring(0, content.length() - 1);
                        }
                        return true;
                    }

                    return super.method_25404(keyInput);
                }

                public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
                }

                @Override
                public boolean method_25400(class_11905 charInput) {
                    if (!charInput.method_74227()) {
                        return super.method_25400(charInput);
                    }

                    content += charInput.method_74226();
                    return true;
                }

                @Override
                public boolean method_25422() {
                    return false;
                }

                private boolean isCopyShortcut(class_11908 keyInput) {
                    return keyInput.comp_4795() == GLFW.GLFW_KEY_C && (keyInput.comp_4797() & GLFW.GLFW_MOD_CONTROL) != 0;
                }

                private boolean isPasteShortcut(class_11908 keyInput) {
                    return keyInput.comp_4795() == GLFW.GLFW_KEY_V && (keyInput.comp_4797() & GLFW.GLFW_MOD_CONTROL) != 0;
                }
            });
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

}
