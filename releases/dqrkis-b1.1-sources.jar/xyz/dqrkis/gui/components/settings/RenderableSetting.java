package xyz.dqrkis.gui.components.settings;

import xyz.dqrkis.gui.components.ModuleButton;
import xyz.dqrkis.module.setting.Setting;
import xyz.dqrkis.utils.ColorUtils;
import xyz.dqrkis.utils.RenderUtils;
import xyz.dqrkis.utils.TextRenderer;
import java.awt.*;
import net.minecraft.class_310;
import net.minecraft.class_332;

public abstract class RenderableSetting {
	public class_310 mc = class_310.method_1551();
	public ModuleButton parent;
	public Setting<?> setting;
	public int offset;
	public Color currentColor;
	public boolean mouseOver;
	int x;
	int y;
	int width;
	int height;

	public RenderableSetting(ModuleButton parent, Setting<?> setting, int offset) {
		this.parent = parent;
		this.setting = setting;
		this.offset = offset;

		this.x = parentX();
		this.y = parentY() + parentOffset() + offset;
		this.width = parentX() + parentWidth();
		this.height = parentY() + parentOffset() + offset + parentHeight();
	}

	public int parentX() {
		return parent.parent.getX();
	}

	public int parentY() {
		return parent.parent.getY();
	}

	public int parentWidth() {
		return parent.parent.getWidth();
	}

	public int parentHeight() {
		return parent.parent.getHeight();
	}

	public int parentOffset() {
		return parent.offset;
	}

	public void render(class_332 context, int mouseX, int mouseY, float delta) {
		updateMouseOver(mouseX, mouseY);
		this.x = parentX();
		this.y = parentY() + parentOffset() + offset;
		this.width = parentX() + parentWidth();
		this.height = parentY() + parentOffset() + offset + parentHeight();

		context.method_25294(x, y, width, height, currentColor.getRGB());
	}

	private void updateMouseOver(double mouseX, double mouseY) {
		this.mouseOver = isHovered(mouseX, mouseY);
	}

	public void renderDescription(class_332 context, int mouseX, int mouseY, float delta) {
		if (isHovered(mouseX, mouseY) && setting.getDescription() != null && !parent.parent.dragging) {
			CharSequence chars = setting.getDescription();

			int tw = TextRenderer.getWidth(chars);

			int parentCenter = mc.method_22683().method_4480() / 2;
			int textCenter = parentCenter - tw / 2;

			RenderUtils.renderRoundedQuad(
					context,
					new Color(100, 100, 100, 100),
					textCenter - 5,
					(mc.method_22683().method_4507() / 2) + 294,
					textCenter + tw + 5,
					(mc.method_22683().method_4507() / 2) + 318,
					3,
					10
			);

			TextRenderer.drawString(chars, context, textCenter, (mc.method_22683().method_4507() / 2) + 300, Color.WHITE.getRGB());
		}
	}

	public void onGuiClose() {
		this.currentColor = null;
	}

	public void keyPressed(int keyCode, int scanCode, int modifiers) {
	}

	public boolean isHovered(double mouseX, double mouseY) {
		return mouseX > parentX()
				&& mouseX < parentX() + parentWidth()
				&& mouseY > offset + parentOffset() + parentY()
				&& mouseY < offset + parentOffset() + parentY() + parentHeight();
	}

	public void onUpdate() {
		if (currentColor == null)
			currentColor = new Color(0, 0, 0, 0);
		else currentColor = new Color(0, 0, 0, currentColor.getAlpha());

		int toAlpha = 120;

		if (currentColor.getAlpha() != toAlpha)
			currentColor = ColorUtils.smoothAlphaTransition(0.05F, toAlpha, currentColor);
	}

	public void mouseClicked(double mouseX, double mouseY, int button) {
	}

	public void mouseReleased(double mouseX, double mouseY, int button) {
	}

	public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
	}
}
