package xyz.dqrkis;

import net.minecraft.class_310;
import net.minecraft.class_437;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.gui.ClickGui;
import xyz.dqrkis.gui.DqrkisClickGui;
import xyz.dqrkis.gui.TabGui;
import xyz.dqrkis.managers.FriendManager;
import xyz.dqrkis.module.ModuleManager;
import xyz.dqrkis.managers.ProfileManager;
import xyz.dqrkis.utils.rotation.RotatorManager;

@SuppressWarnings("all")
public final class Dqrkis {
	public RotatorManager rotatorManager;
	public ProfileManager profileManager;
	public ModuleManager moduleManager;
	public EventManager eventManager;
	public FriendManager friendManager;
	public static class_310 mc;
	public String version = " b1.3";
	public static boolean BETA; // unused legacy flag from the original codebase (kept for source fidelity)
	public static Dqrkis INSTANCE;
	public boolean guiInitialized;
	public ClickGui clickGui;
	public DqrkisClickGui dqrkisClickGui;
	public TabGui tabGui;
	public class_437 previousScreen = null;

	public Dqrkis() {
		INSTANCE = this;
		this.eventManager = new EventManager();
		this.moduleManager = new ModuleManager();
		this.clickGui = new ClickGui();
		this.dqrkisClickGui = new DqrkisClickGui();
		this.tabGui = new TabGui();
		this.rotatorManager = new RotatorManager();
		this.profileManager = new ProfileManager();
		this.friendManager = new FriendManager();

		this.getProfileManager().loadProfile();

		this.guiInitialized = false;
		mc = class_310.method_1551();
	}

	public ProfileManager getProfileManager() {
		return profileManager;
	}

	public ModuleManager getModuleManager() {
		return moduleManager;
	}

	public FriendManager getFriendManager() {
		return friendManager;
	}

	public EventManager getEventManager() {
		return eventManager;
	}

	public ClickGui getClickGui() {
		return clickGui;
	}

	public DqrkisClickGui getDqrkisClickGui() {
		return dqrkisClickGui;
	}

	public TabGui getTabGui() {
		return tabGui;
	}

	public String getVersion() {
		return version;
	}
}