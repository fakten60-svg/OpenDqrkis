package xyz.dqrkis.mixin;

import xyz.dqrkis.module.modules.misc.AutoReconnect;
import net.minecraft.class_2561;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_8667;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_419.class)
public abstract class DisconnectedScreenMixin extends class_437 {
	@Shadow @Final private class_8667 grid;

	@Unique
	private class_4185 dqrkis$reconnectButton;

	@Unique
	private double dqrkis$countdownTicks;

	protected DisconnectedScreenMixin(class_2561 title) {
		super(title);
	}

	@Inject(method = "init", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/gui/widget/DirectionalLayoutWidget;refreshPositions()V",
			shift = At.Shift.BEFORE))
	private void dqrkis$addReconnectButtons(CallbackInfo ci) {
		AutoReconnect autoReconnect = xyz.dqrkis.Dqrkis.INSTANCE.getModuleManager().getModule(AutoReconnect.class);
		if (autoReconnect == null || !autoReconnect.hasServer() || autoReconnect.shouldHideButtons())
			return;

		dqrkis$countdownTicks = autoReconnect.getDelaySeconds() * 20.0D;

		dqrkis$reconnectButton = class_4185.method_46430(class_2561.method_43470(dqrkis$buttonText(autoReconnect)), button -> dqrkis$tryConnecting()).method_46431();
		grid.method_52736(dqrkis$reconnectButton);
		grid.method_52736(class_4185.method_46430(
						class_2561.method_43470(dqrkis$toggleText(autoReconnect)),
						button -> {
							autoReconnect.toggle();
							button.method_25355(class_2561.method_43470(dqrkis$toggleText(autoReconnect)));
							if (dqrkis$reconnectButton != null)
								dqrkis$reconnectButton.method_25355(class_2561.method_43470(dqrkis$buttonText(autoReconnect)));
							dqrkis$countdownTicks = autoReconnect.getDelaySeconds() * 20.0D;
						})
				.method_46431());
	}

	@Override
	public void method_25393() {
		AutoReconnect autoReconnect = xyz.dqrkis.Dqrkis.INSTANCE.getModuleManager().getModule(AutoReconnect.class);
		if (autoReconnect == null || !autoReconnect.isEnabled() || !autoReconnect.hasServer())
			return;

		if (dqrkis$countdownTicks <= 0.0D) {
			dqrkis$tryConnecting();
		} else {
			dqrkis$countdownTicks--;
			if (dqrkis$reconnectButton != null)
				dqrkis$reconnectButton.method_25355(class_2561.method_43470(dqrkis$buttonText(autoReconnect)));
		}
	}

	@Unique
	private String dqrkis$buttonText(AutoReconnect autoReconnect) {
		String text = "Reconnect";
		if (autoReconnect.isEnabled())
			text += String.format(" (%.1f)", dqrkis$countdownTicks / 20.0D);
		return text;
	}

	@Unique
	private String dqrkis$toggleText(AutoReconnect autoReconnect) {
		return "Auto Reconnect: " + (autoReconnect.isEnabled() ? "§aON" : "§cOFF");
	}

	@Unique
	private void dqrkis$tryConnecting() {
		AutoReconnect autoReconnect = xyz.dqrkis.Dqrkis.INSTANCE.getModuleManager().getModule(AutoReconnect.class);
		if (autoReconnect != null && autoReconnect.hasServer())
			class_412.method_36877(new class_442(), this.field_22787, autoReconnect.serverAddress, autoReconnect.serverInfo, false, null);
	}
}
