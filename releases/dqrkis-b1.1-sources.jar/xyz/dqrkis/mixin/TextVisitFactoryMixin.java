package xyz.dqrkis.mixin;

import xyz.dqrkis.module.modules.render.NameHider;
import net.minecraft.class_5223;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_5223.class)
public class TextVisitFactoryMixin {

	@ModifyArg(method = "visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/text/TextVisitFactory;visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"),
			index = 0, require = 0)
	private static String dqrkis$modifyVisitedText(String text) {
		NameHider nameHider = NameHider.get();
		return nameHider != null && nameHider.isEnabled() ? nameHider.filter(text) : text;
	}
}
