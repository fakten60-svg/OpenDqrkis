package xyz.dqrkis.mixin;

import xyz.dqrkis.module.modules.render.NameHider;
import net.minecraft.class_2561;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_338.class)
public class ChatHudMixin {

	/**
	 * Target signature for 1.21.11:
	 * {@code ChatHud.addMessage(Text, MessageSignatureData, MessageIndicator)}.
	 *
	 * Both parameter types moved in this version. The old descriptor referenced
	 * {@code net.minecraft.message.MessageSignatureData} and {@code net.minecraft.chat.MessageIndicator},
	 * which no longer exist, so the injection target could not be resolved and the whole mixin
	 * config (required = true) failed to apply.
	 */
	@ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
			at = @At("HEAD"), ordinal = 0, argsOnly = true)
	private class_2561 dqrkis$modifyChatMessage(class_2561 message) {
		NameHider nameHider = NameHider.get();
		if (nameHider == null || !nameHider.shouldHideInChat())
			return message;

		String filtered = nameHider.filter(message.getString());
		return filtered.equals(message.getString()) ? message : class_2561.method_43470(filtered);
	}
}
