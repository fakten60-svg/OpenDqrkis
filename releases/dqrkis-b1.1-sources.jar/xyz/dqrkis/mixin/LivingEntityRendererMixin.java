package xyz.dqrkis.mixin;

import xyz.dqrkis.module.modules.render.NameHider;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_922.class)
public class LivingEntityRendererMixin {

	@Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
	private void dqrkis$onHasLabel(class_1309 entity, double cameraDistance, CallbackInfoReturnable<Boolean> cir) {
		if (!(entity instanceof class_1657))
			return;

		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || entity != client.field_1724)
			return;

		NameHider nameHider = NameHider.get();
		if (nameHider != null && nameHider.shouldHideNametag())
			cir.setReturnValue(false);
	}
}
