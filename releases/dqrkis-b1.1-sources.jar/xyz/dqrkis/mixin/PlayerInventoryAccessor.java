package xyz.dqrkis.mixin;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = {class_1661.class})
public interface PlayerInventoryAccessor {
	@Accessor("main")
	class_2371<class_1799> getMain();
}
