package xyz.dqrkis.mixin;

import xyz.dqrkis.imixin.IKeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import static xyz.dqrkis.Dqrkis.mc;

import net.minecraft.class_304;
import net.minecraft.class_3675;

@Mixin(class_304.class)
public abstract class KeyBindingMixin implements IKeyBinding {

	@Shadow
	private class_3675.class_306 boundKey;

	@Override
	public boolean isActuallyPressed() {
		int code = boundKey.method_1444();
		return class_3675.method_15987(mc.method_22683(), code);
	}

	@Override
	public void resetPressed() {
		setPressed(isActuallyPressed());
	}

	@Shadow
	public abstract void setPressed(boolean pressed);
}
