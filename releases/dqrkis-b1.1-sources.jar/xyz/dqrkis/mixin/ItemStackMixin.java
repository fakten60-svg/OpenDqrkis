package xyz.dqrkis.mixin;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.module.modules.render.NoBounce;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static xyz.dqrkis.Dqrkis.mc;

import net.minecraft.class_1799;
import net.minecraft.class_1802;

@Mixin(class_1799.class)
public class ItemStackMixin {

	@Inject(method = "getBobbingAnimationTime", at = @At("HEAD"), cancellable = true)
	private void removeBounceAnimation(CallbackInfoReturnable<Integer> cir) {
		if (mc.field_1724 == null) return;

		NoBounce noBounce = Dqrkis.INSTANCE.getModuleManager().getModule(NoBounce.class);
		if (Dqrkis.INSTANCE != null && mc.field_1724 != null && noBounce.isEnabled()) {
			class_1799 mainHandStack = mc.field_1724.method_6047();
			if (mainHandStack.method_31574(class_1802.field_8301)) {
				cir.setReturnValue(0);
			}
		}
	}
}
