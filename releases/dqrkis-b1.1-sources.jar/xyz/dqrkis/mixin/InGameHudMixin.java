package xyz.dqrkis.mixin;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.event.events.HudListener;
import xyz.dqrkis.module.modules.render.HideScoreboard;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
	@Inject(method = "render", at = @At("HEAD"))
	private void onRenderHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
		HudListener.HudEvent event = new HudListener.HudEvent(context, tickCounter.method_60637(true));

		EventManager.fire(event);
	}

	@Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"), cancellable = true)
	private void dqrkis$onRenderScoreboardSidebar(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
		HideScoreboard hideScoreboard = Dqrkis.INSTANCE.getModuleManager().getModule(HideScoreboard.class);
		if (hideScoreboard != null && hideScoreboard.isEnabled())
			ci.cancel();
	}

	@Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V", at = @At("HEAD"), cancellable = true)
	private void dqrkis$onRenderScoreboardSidebarObjective(class_332 context, net.minecraft.class_266 objective, CallbackInfo ci) {
		HideScoreboard hideScoreboard = Dqrkis.INSTANCE.getModuleManager().getModule(HideScoreboard.class);
		if (hideScoreboard != null && hideScoreboard.isEnabled())
			ci.cancel();
	}
}
