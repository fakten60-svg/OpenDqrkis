package xyz.dqrkis.mixin;

import xyz.dqrkis.module.modules.render.NameHider;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_640.class)
public class PlayerListEntryMixin {

	@Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
	private void dqrkis$onGetDisplayName(CallbackInfoReturnable<class_2561> cir) {
		NameHider nameHider = NameHider.get();
		if (nameHider == null || !nameHider.shouldHideInTab())
			return;

		class_310 client = class_310.method_1551();
		if (client.field_1724 == null)
			return;

		class_640 self = (class_640) (Object) this;
		if (!self.method_2966().name().equals(client.field_1724.method_5477().getString()))
			return;

		class_2561 current = cir.getReturnValue();
		if (current == null) {
			cir.setReturnValue(class_2561.method_43470(nameHider.getFakeName()));
			return;
		}

		String filtered = nameHider.filter(current.getString());
		if (!filtered.equals(current.getString()))
			cir.setReturnValue(class_2561.method_43470(filtered));
	}
}
