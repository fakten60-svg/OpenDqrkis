package xyz.dqrkis.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
	@Accessor
	boolean getJumping();

	@Accessor("lastDamageSource")
	class_1282 getLastDamageSource();

	@Accessor("lastDamageSource")
	void setLastDamageSource(class_1282 source);

	@Accessor("lastDamageTime")
	long getLastDamageTime();

	@Accessor("lastDamageTime")
	void setLastDamageTime(long time);

	@Accessor("lastBlockPos")
	class_2338 getLastBlockPos();

	@Accessor("lastBlockPos")
	void setLastBlockPos(class_2338 pos);

	@Accessor("attacking")
	void setAttacking(class_1309 attacking);
}
