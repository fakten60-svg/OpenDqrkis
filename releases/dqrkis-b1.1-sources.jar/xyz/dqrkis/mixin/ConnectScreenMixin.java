package xyz.dqrkis.mixin;

import xyz.dqrkis.module.modules.misc.AutoReconnect;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_412.class)
public class ConnectScreenMixin {

	@Inject(method = "connect", at = @At("HEAD"))
	private static void dqrkis$onConnect(class_437 screen, class_310 client, class_639 address, class_642 info,
	                                     boolean quickPlay, class_9112 cookieStorage, CallbackInfo ci) {
		AutoReconnect autoReconnect = xyz.dqrkis.Dqrkis.INSTANCE.getModuleManager().getModule(AutoReconnect.class);
		if (autoReconnect != null)
			autoReconnect.recordConnection(address, info);
	}
}
