package xyz.dqrkis.mixin;

import xyz.dqrkis.Dqrkis;
import xyz.dqrkis.event.EventManager;
import xyz.dqrkis.event.events.ButtonListener;
import xyz.dqrkis.module.Module;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardMixin {
	@Shadow
	@Final
	private class_310 client;

	@Inject(method = "onKey", at = @At("HEAD"))
	private void onPress(long window, int action, class_11908 input, CallbackInfo ci) {
		EventManager.fire(new ButtonListener.ButtonEvent(input.comp_4795(), window, action));
	}
}
