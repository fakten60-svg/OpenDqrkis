package xyz.dqrkis.event.events;

import xyz.dqrkis.event.Event;
import xyz.dqrkis.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_4587;

public interface GameRenderListener extends Listener {
	void onGameRender(GameRenderEvent event);

	class GameRenderEvent extends Event<GameRenderListener> {
		public class_4587 matrices;
		public float delta;

		public GameRenderEvent(class_4587 matrices, float delta) {
			this.matrices = matrices;
			this.delta = delta;
		}

		@Override
		public void fire(ArrayList<GameRenderListener> listeners) {
			listeners.forEach(e -> e.onGameRender(this));
		}

		@Override
		public Class<GameRenderListener> getListenerType() {
			return GameRenderListener.class;
		}
	}
}
