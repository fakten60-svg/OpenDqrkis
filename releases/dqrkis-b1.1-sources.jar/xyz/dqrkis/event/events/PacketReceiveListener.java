package xyz.dqrkis.event.events;

import xyz.dqrkis.event.CancellableEvent;
import xyz.dqrkis.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_2596;


public interface PacketReceiveListener extends Listener {
	void onPacketReceive(PacketReceiveEvent event);

	class PacketReceiveEvent extends CancellableEvent<PacketReceiveListener> {
		public class_2596 packet;

		public PacketReceiveEvent(class_2596 packet) {
			this.packet = packet;
		}

		@Override
		public void fire(ArrayList<PacketReceiveListener> listeners) {
			listeners.forEach(e -> e.onPacketReceive(this));
		}

		@Override
		public Class<PacketReceiveListener> getListenerType() {
			return PacketReceiveListener.class;
		}
	}
}
