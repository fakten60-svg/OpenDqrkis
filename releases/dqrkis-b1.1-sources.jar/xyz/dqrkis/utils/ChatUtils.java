package xyz.dqrkis.utils;

import net.minecraft.class_2561;
import xyz.dqrkis.Dqrkis;

public final class ChatUtils {
	private ChatUtils() {}

	public static void info(String message) {
		send("§b[Dqrkis]§f " + message);
	}

	public static void error(String message) {
		send("§c[Dqrkis]§f " + message);
	}

	private static void send(String message) {
		if (Dqrkis.mc != null && Dqrkis.mc.field_1724 != null)
			Dqrkis.mc.field_1724.method_7353(class_2561.method_43470(message), false);
	}
}
