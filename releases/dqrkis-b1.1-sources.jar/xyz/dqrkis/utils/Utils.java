package xyz.dqrkis.utils;

import xyz.dqrkis.module.modules.client.ClickGUI;
import java.awt.*;
import net.minecraft.class_1297;
import net.minecraft.class_640;

import static xyz.dqrkis.Dqrkis.mc;

public final class Utils {

	public static Color getMainColor(int alpha, int increment) {
		int red = ClickGUI.red.getValueInt();
		int green = ClickGUI.green.getValueInt();
		int blue = ClickGUI.blue.getValueInt();

		if (ClickGUI.rainbow.getValue()) {
			return ColorUtils.getBreathingRGBColor(increment, alpha);
		} else {
			if (ClickGUI.breathing.getValue()) {
				return ColorUtils.getMainColor(new Color(red, green, blue, alpha), increment, 20);
			} else {
				return new Color(red, green, blue, alpha);
			}
		}
	}

	public static int getPing(class_1297 player) {
		if (mc.method_1562().method_48296() == null) return 0;

		class_640 playerListEntry = mc.method_1562().method_2871((player.method_5667()));
		if (playerListEntry == null) return 0;
		return playerListEntry.method_2959();
	}
}
