package xyz.dqrkis.utils;

import net.minecraft.class_1799;
import net.minecraft.class_1802;

public final class ItemUtils {
	private ItemUtils() {}

	public static boolean hasEnchant(class_1799 stack, String idPart) {
		return stack.method_58657().method_57534().stream()
				.anyMatch(entry -> entry.method_55840().contains(idPart));
	}

	public static boolean isMace(class_1799 stack) {
		return stack.method_31574(class_1802.field_49814);
	}
}
