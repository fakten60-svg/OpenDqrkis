package xyz.dqrkis.managers;


import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3966;

import static xyz.dqrkis.Dqrkis.mc;

public final class FriendManager {
    private final Set<String> friends;

    public FriendManager() {
        this.friends = new HashSet<>();
    }

    public void addFriend(class_1657 player) {
        friends.add(player.method_5477().getString());
    }

    public void removeFriend(class_1657 player) {
        friends.remove(player.method_5477().getString());
    }

    public boolean isFriend(class_1657 player) {
        return friends.contains(player.method_5477().getString());
    }

    public boolean isAimingOverFriend() {
        if(mc.field_1765 instanceof class_3966 hitResult) {
            class_1297 entity = hitResult.method_17782();

            if(entity instanceof class_1657 player) {
                return isFriend(player);
            }
        }

        return false;
    }
}
